/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
function renderNav()
{
	var id = SCS.navigationRoot;

	var navLogo = $("#navbar-logo");	// assumed to be an existing <a> tag
	var linkData;

	if (navLogo) {
		linkData = SCSRenderAPI.getPageLinkData(id) || {};
		if( linkData.href ) {
			$(navLogo).attr("href", linkData.href);
		}
	}

	var navList = $("#navbar-list");	// assumed to be an empty <ul> tag

	// Home Page
	var navItem = document.createElement("li");
	$(navItem).addClass("nav-item");

	if (id == SCS.navigationCurr)
		$(navItem).addClass("active");

	var navLink = document.createElement("a");
	linkData = SCSRenderAPI.getPageLinkData(id) || {};
	if( linkData.href ) {
		$(navLink).attr("href", linkData.href);
	}
	if( linkData.target ) {
		$(navLink).attr("target", linkData.target);
	}
	$(navLink).text(SCS.structureMap[id].name);

	$(navItem).append(navLink);
	$(navList).append(navItem);

	var nodes = SCS.structureMap[id].children;

	// 1st level children - show at same navigation level as Home
	for (var n = 0; n < nodes.length; n++)
	{
		id = nodes[n];

		if( isNodeHidden( id ) )
			continue; 	// Do not emit markup for this hidden node

		navItem = document.createElement("li");
		$(navItem).addClass("nav-item");

		if (id == SCS.navigationCurr)
			$(navItem).addClass("active");

		navLink = document.createElement("a");
		linkData = SCSRenderAPI.getPageLinkData(id) || {};
		if( linkData.href ) {
			$(navLink).attr("href", linkData.href);
		}
		if( linkData.target ) {
			$(navLink).attr("target", linkData.target);
		}
		$(navLink).text(SCS.structureMap[id].name);

		$(navItem).append(navLink);
		$(navList).append(navItem);

		if ((SCS.structureMap[id].children.length > 0) && !allNodeChildrenAreHidden(id))
		{	// add downarrow top top level to activate sub-menu
			navItem = document.createElement("li");
			$(navItem).addClass("nav-item dropdown");
			$(navItem).addClass("dropdown");

			navLink = document.createElement("a");
			$(navLink).addClass("dropdown-toggle");
			$(navLink).attr("href", "#");
			$(navLink).attr("data-toggle", "dropdown");
			$(navLink).attr("data-hover",  "dropdown");
			$(navLink).attr("data-delay",  "0");
			$(navLink).attr("data-close-others", "false");

			var navLabel = document.createElement("i");
			$(navLabel).addClass("fa fa-angle-down");

			$(navLink).append(navLabel);
			$(navItem).append(navLink);

			var navSubList = document.createElement("ul");
			$(navSubList).addClass("dropdown-menu");

			var subnodes = SCS.structureMap[id].children;

			for( sub = 0; sub < subnodes.length; sub++ )
			{
				if( isNodeHidden( subnodes[sub] ) )
					continue; 	// Do not emit markup for this hidden node

				var navSubItem = document.createElement("li");

				if (subnodes[sub] == SCS.navigationCurr)
					$(navSubItem).addClass("active");

				navSubLink = document.createElement("a");
				linkData = SCSRenderAPI.getPageLinkData(subnodes[sub]) || {};
				if( linkData.href ) {
					$(navSubLink).attr("href", linkData.href);
				}
				if( linkData.target ) {
					$(navSubLink).attr("target", linkData.target);
				}
				$(navSubLink).text(SCS.structureMap[subnodes[sub]].name);

				$(navSubItem).append(navSubLink);
				$(navSubList).append(navSubItem);
			}

			$(navItem).append(navSubList);
			$(navList).append(navItem);
		}
	}
}

function isNodeHidden( id )
{
	var navNode,
		isHidden = false;

	if( SCS.structureMap )
	{
		navNode = SCS.structureMap[id];
		if( navNode )
		{
			isHidden = ( true === navNode.hideInNavigation );
		}
	}

	return isHidden;
}

function allNodeChildrenAreHidden( id )
{
	var subnodes = SCS.structureMap[id].children,
		allHidden = ( subnodes.length > 0 ) ? true: false;

	for( var sub = 0; sub < subnodes.length; sub++ )
	{
		if( !isNodeHidden( subnodes[sub] ) )
		{
			allHidden = false;
			break;
		}
	}

	return allHidden;
}

// Must wait for all our script to be ready...
if (document.addEventListener)
{
	document.addEventListener('scsrenderstart', renderNav, false);
}
else if (document.attachEvent)
{
	document.documentElement.scsrenderstart = 0;
	document.documentElement.attachEvent("onpropertychange",
		function(event)
		{
			if (event && (event.propertyName == "scsrenderstart"))
			{
				renderNav();
			}
		}
	);
}




