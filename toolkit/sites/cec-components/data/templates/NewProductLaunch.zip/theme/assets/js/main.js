/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
$(document).ready(function() {

	/* ======= FAQ accordion ======= */
	function toggleIcon(e) {
	$(e.target)
		.prev('.panel-heading')
		.find('.panel-title a')
		.toggleClass('active')
		.find("i.fa")
		.toggleClass('fa-plus-square fa-minus-square');
	}
	$('.panel').on('hidden.bs.collapse', toggleIcon);
	$('.panel').on('shown.bs.collapse', toggleIcon);


	 /* ======= Testimonial Bootstrap Carousel ======= */
	 /* Ref: http://getbootstrap.com/javascript/#carousel */
	$('#testimonials-carousel').carousel({
	  interval: 8000
	});

});
