/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */

/* globals define */

define([
	'jquery',
	'mustache',
	'text!./layout.html',
	'css!./design.css'
], function ($, Mustache, templateHtml, css) {
	'use strict';

	function ContentLayout(params) {
		this.contentItemData = params.contentItemData || {};
		this.scsData = params.scsData;
		this.contentClient = params.contentClient;
		// Backward compatibility for v1 API
		this.contentItemData.fields = this.contentClient.getInfo().contentVersion === 'v1' ? this.contentItemData.data : this.contentItemData.fields;
	}

	function dateToMDY(date) {
		var dateObj = new Date(date);

		var options = {
			year: 'numeric',
			month: 'long',
			day: 'numeric'
		};
		var formattedDate = dateObj.toLocaleDateString('en-US', options);

		return formattedDate;
	}

	// Helper function to make an additional Content REST API call to retrieve all items referenced in the data by their ID.
	function getRefItems(contentClient, ids) {
		// Calling getItems() with no ‘ids’ returns all items.
		// If no items are requested, just return a resolved Promise.
		if (ids.length === 0) {
			return Promise.resolve({});
		} else {
			return contentClient.getItems({
				"ids": ids
			});
		}
	}

	ContentLayout.prototype = {
		contentVersion: '>=1.0.0 <2.0.0',

		render: function (parentObj) {
			var template,
				contentClient = this.contentClient,
				fields = this.contentItemData.fields,
				content = {
					blogImageRenditionURL: contentClient.getRenditionURL({
						'id': fields['starter-blog-post_header_image'].id
					}),
					blogSummary: fields['starter-blog-post_summary'],
					blogTitle: fields['starter-blog-post_title'],
					blogContent: fields['starter-blog-post_content'],
					blogFormattedDate: dateToMDY(this.contentItemData.updatedDate.value)
				},
				contentType,
				secureContent = false;

			if (this.scsData) {
				content = $.extend(content, {
					'scsData': this.scsData
				});
				contentType = content.scsData.showPublishedContent === true ? 'published' : 'draft';
				secureContent = content.scsData.secureContent;
			}

			getRefItems(contentClient, [fields['starter-blog-post_author'].id]).then(function (results) {
				// get the blog author
				var author = results && results.items && results.items[0] || [];
				author.fields = contentClient.getInfo().contentVersion === 'v1' ? author.data : author.fields;

				content.blogAuthor = author.fields['starter-blog-author_name'];

				// render the cotent
				try {
					// Mustache
					template = Mustache.render(templateHtml, content);

					if (template) {
						$(parentObj).append(template);
					}
				} catch (e) {
					console.error(e.stack);
				}
			});
		}
	};

	return ContentLayout;
});
