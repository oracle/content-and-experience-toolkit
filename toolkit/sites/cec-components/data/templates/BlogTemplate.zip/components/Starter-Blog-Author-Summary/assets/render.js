/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */

/* globals define */

define([
	'jquery',
	'mustache',
	'text!./layout.html',
	'css!./design.css'
], function ($, Mustache, templateHtml, css) {
	'use strict';

	function ContentLayout(params) {
		this.contentClient = params.contentClient;
		this.contentItemData = params.contentItemData || {};
		this.scsData = params.scsData;
		// Backward compatibility for v1 API
		this.contentItemData.fields = this.contentClient.getInfo().contentVersion === 'v1' ? this.contentItemData.data : this.contentItemData.fields;
	}

	function dateToMDY(date) {
		if (!date) {
			return '';
		}

		var dateObj = new Date(date);

		var options = {
			year: 'numeric',
			month: 'long',
			day: 'numeric',
			hour: "2-digit",
			minute: "2-digit"
		};
		var formattedDate = dateObj.toLocaleDateString('en-US', options);

		return formattedDate;
	}

	ContentLayout.prototype = {
		contentVersion: '>=1.0.0 <2.0.0',

		render: function (parentObj) {
			var template,
				content = $.extend({}, this.contentItemData),
				contentClient = this.contentClient,
				contentType,
				secureContent = false;

			// Store the id
			content.fields.author_id = content.id;


			if (this.scsData) {
				content = $.extend(content, {
					'scsData': this.scsData
				});
				contentType = content.scsData.showPublishedContent === true ? 'published' : 'draft';
				secureContent = content.scsData.secureContent;
			}

			try {
				// Mustache
				template = Mustache.render(templateHtml, content);

				if (template) {
					$(parentObj).append(template);
				}
				$(".author-name").click($.proxy(function () {
					$(".author-name").removeClass('author-selected');
					$(event.target).addClass('author-selected');
				}, this));
				if (window.location.href.indexOf("default=" + this.contentItemData.id) >= 0) {
					$(".author-name").each(function() {
						if (this.innerText === content.fields['starter-blog-author_name'])
						{
							$(this).addClass('author-selected');
						}
					});
				}
			} catch (e) {
				console.error(e.stack);
			}

		}
	};

	return ContentLayout;
});
