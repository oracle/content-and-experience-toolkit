/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,alert,console,requirejs,SitesPCSUtils*/
(function () {
	'use strict';

	var taskDetailInitializedFlag = false;

	// Define a Knockout ViewModel for your template
	var PCSTaskDetailsViewModel = function () {
		// save reference
		var self = this;

		//	Attributes on PCSTaskDetailsViewModel	//
		//	===============================			//	
		//											//	

		self.appParams = self.getQueryParameters(window.location.href);
		self.isRendering = ko.observable(false);
		SitesSDK.getProperty('viewMode', function (viewMode) {
			self.isRendering(viewMode !== 'edit');
		});
		self.taskDetailsLabel = ko.observable('Task Details');
		self.pcsServerURL = ko.observable('');
		self.taskNumber = ko.observable('');
		self.isAuthed = ko.observable(false);
		self.noAuthMsg = ko.observable('The task details component can only be viewed on a secure site by users with the Documents Cloud Service User role.');
		self.isPCSModuleLoaded = ko.observable(true);
		self.noPCSModuleMsg = ko.observable('A newer version of Process Cloud Service is required to use the task details component.');
		// handle initialization
		self.customSettingsDataInitialized = ko.observable(false);



		//	Methods on PCSTaskDetailsViewModel	//
		//	===============================		//	
		//										//	

		self.initialized = ko.computed(function () {
			return self.customSettingsDataInitialized();
		}, self);

		// check if it is a logged in session
		self.checkAuth = function (callback) {
			var url = '/documents/web?IdcService=GET_USER_INFO';
			if (self.isRendering() === false) {
				// in builder
				callback(true);
			} else {
				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': url,
					'success': function (data) {
						console.log('startform: authorized');
						callback(data.LocalData.StatusCode === '0');
					},
					'error': function (xhr, status, err) {
						console.log('taskdetails: unauthorized, status: ' + status + ' error: ' + err);
						callback(false);
					}
				});
			}
		};



		self.init = function (customData) {
			self.checkAuth(function (authed) {
				self.isAuthed(authed);
				if (authed) {
					self.updateCustomSettingsData(customData);
				}
				self.customSettingsDataInitialized(true);

				//listen to the following value changes to adjust render height
				ko.computed(function () {
					var authed = self.isAuthed();

					// unauthorized message
					if (authed === false) {
						SitesSDK.setProperty('height');
					}
				});
			});
		};

		self.getToken = function (serverURL, callback) {
			var token;

			SitesPCSUtils.getAuthToken({
				'serverURL': serverURL,
				'successCallback': function (data) {
					token = data;
					callback(token);
				},
				'errorCallback': function (xhr, status, err) {
					console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
					// failed but continue anyway
					callback();
				}
			});
		};

		var fireSubmitTrigger = function (taskObject) {
			// page level trigger
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsSubmitTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				}
			});

			// auto wire
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsSubmitTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				},
				'actions': ['scsPCSTaskDetailsSubmitted']
			});
		};

		var fireApproveTrigger = function (taskObject) {

			// Raise page level trigger
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsApproveTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				}
			});

			// Autowire
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsApproveTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				},
				'actions': ['scsPCSTaskDetailsApproved']
			});
		};
		var fireRejectTrigger = function (taskObject) {
			// Page level trigger
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsRejectTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				}
			});
			// auto wire
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsRejectTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				},
				'actions': ['scsPCSTaskDetailsRejected']
			});
		};
		var fireSaveTrigger = function (taskObject) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsSaveTrigger',
				'triggerPayload': {
					taskNumber: taskObject.number
				}
			});
		};
		var fireCommentAddedTrigger = function (comment) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsTaskDetailsCommentAddedTrigger',
				'triggerPayload': {
					commentStr: comment.commentStr
				}
			});
		};


		self.loadDetails = function (taskNumber) {

			if (!self.isPCSModuleLoaded()) {
				// nothing to do if the PCS module is not loaded.
				return;
			}
			console.log(taskNumber);

			var taskdetail = $('#taskdetail');
			//                            var taskDetailDiv = $("#taskdetail");

			//if the plugin was already used  clean it up
			if (taskdetail && taskdetail.data() && !$.isEmptyObject(taskdetail.data())) {
				taskdetail.taskdetail('destroy');
			}

			ko.cleanNode(taskdetail['0']);

			var div = taskdetail.parent();
			div.html('<div id="taskdetail"></div>');

			var taskdetailDiv = $("#taskdetail");

			$("#taskdetail").taskdetail({
				taskNumber: taskNumber,
				hideActions: (!self.config.showActions),
				hideSave: (!self.config.showSave),
				hideClose: true,
				hideAttachment: (!self.config.showAttachment),
				hideComments: (!self.config.showComments),
				hideHistory: (!self.config.showHistory),
				hideMoreInfo: (!self.config.showMoreInfo),
				hideLinks: (!self.config.showLinks)
			});


			taskdetailDiv.on('taskdetail:loaded', function (event, data, action) {
				console.log("PCS Task Details: Loaded...");
				SitesSDK.setProperty('height');

				// load strings (for triggers and actions)
				if (!self.isRendering() && self.strings === undefined) {
					self.loadStrings(function (strings) {
						self.strings = strings;
						SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_ACTIONS, getAppActionsListener);
						SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getTriggers);
					});
				}
			});

			taskdetailDiv.on('taskdetail:submit', function (event, data) {
				console.log("PCS Task Details: Submit event fired...");
				console.log(data);
				fireSubmitTrigger(data);
			});

			taskdetailDiv.on('taskdetail:approve', function (event, data) {
				console.log("PCS Task Details: Aprove event fired...");
				console.log(data);
				fireApproveTrigger(data);
			});

			taskdetailDiv.on('taskdetail:reject', function (event, data) {
				console.log("PCS Task Details: Reject event fired...");
				console.log(data);
				fireRejectTrigger(data);
			});

			taskdetailDiv.on('taskdetail:save', function (event, data) {
				console.log("PCS Task Details: Save event fired...");
				console.log(data);
				fireSaveTrigger(data);
			});

			taskdetailDiv.on('taskdetail:commentAdded', function (event, data) {
				console.log("PCS Task Details: Comment Added event fired...");
				console.log(data);
				fireCommentAddedTrigger(data);
			});

			console.log("Height from JQuery : " + $('#taskdetail').outerHeight(true));
			SitesSDK.setProperty('height', $('#taskdetail').outerHeight(true) + 150);

		};

		self.initializeTaskDetail = function (serverURL, authToken, taskNumber, designCss) {

			var requireconfig = {};
			if (self.isECPCS) {
				requireconfig = {
					baseUrl: serverURL + "/ic/pub/components/js",
					urlArgs: "bust=18.2.3-sites",
					paths: {
						"knockout": "libs/knockout/knockout-3.4.0",
						"jquery": "libs/jquery/jquery-3.1.1.min",
						"jqueryui-amd": "libs/jquery/jqueryui-amd-1.12.0",
						"ojs": "libs/oj/v3.2.0/debug",
						"ojL10n": "libs/oj/v3.2.0/ojL10n",
						"ojtranslations": "libs/oj/v3.2.0/resources",
						"text": "libs/require/text",
						"promise": "libs/es6-promise/es6-promise-4.0.5.min",
						"hammerjs": "libs/hammer/hammer-2.0.8.min",
						"signals": "libs/js-signals/signals.min",
						"ojdnd": "libs/dnd-polyfill/dnd-polyfill-1.0.0.min",
						"customElements": "libs/webcomponents/CustomElements.min",
						"proj4": "libs/proj4js/dist/proj4",
						"underscore": "libs/underscore/underscore-1.8.3.min",
						"pcs": "libs/pcs/v1.1/min"
					},
					shim: {
						"jquery": {
							"exports": ["jQuery", "$"]
						}
					}
				};
			} else {
				requireconfig = {
					baseUrl: serverURL + "/bpm/components/js", //Change according to your package structure
					urlArgs: "bust=17.2.3-sites",
					paths: {
						'knockout': 'libs/knockout/knockout-3.4.0',
						'jquery': 'libs/jquery/jquery-2.1.3.min',
						'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.11.4.min',
						'promise': 'libs/es6-promise/promise-1.0.0.min',
						'hammerjs': 'libs/hammer/hammer-2.0.4.min',
						'underscore': 'libs/underscore/underscore-1.8.3.min',
						'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.0.min',
						'ojs': 'libs/oj/v2.0.0/min',
						'ojL10n': 'libs/oj/v2.0.0/ojL10n',
						'ojtranslations': 'libs/oj/v2.0.0/resources',
						'signals': 'libs/js-signals/signals.min',
						'text': 'libs/require/text',
						'pcsMsg': SitesPCSUtils.paths.pcsMsg,
						'rendererMsg': SitesPCSUtils.paths.rendererMsg,
						'pcs': SitesPCSUtils.paths.pcs
					},
					shim: {
						'jquery': {
							exports: ['jQuery', '$']
						}
					},
					config: {
						ojL10n: {
							merge: {
								'ojtranslations/nls/ojtranslations': 'libs/pcs/v1.1/resources/nls/pcsSnippetsResource'
							}
						}
					}
				};
			}
			requirejs.config(requireconfig);

			var libs = self.isECPCS ? ['jquery', 'pcs/pcs.taskdetail', 'ojs/ojvalidation-datetime'] : ['jquery', 'pcs/pcs.taskdetail'];
			require(libs,
				function ($, taskdetail) {

					console.log(serverURL);

					$('head').append('<link>');
					var css = $('head').children(':last');
					var pcsCss = serverURL + (self.isECPCS ? "/ic/pub/components/css/libs/pcs/v1.1/alta/pcs-taskdetail-min.css" : "/bpm/components/css/libs/pcs/v1.3/alta/pcs-taskdetail-min.css");
					css.attr({
						rel: 'stylesheet',
						type: 'text/css',
						href: pcsCss
					});

					$('head').append('<link>');

					css = $('head').children(':last');
					var ojCss = serverURL + (self.isECPCS ? "/ic/pub/components/css/libs/oj/v3.2.0/alta/oj-alta-min.css" : "/bpm/components/css/libs/oj/v2.0.0/alta/oj-alta-min.css");
					css.attr({
						rel: 'stylesheet',
						type: 'text/css',
						href: ojCss
					});

					// design.css
					console.log('design.css: ' + designCss);
					if (designCss) {
						$('head').append('<link>');
						css = $('head').children(':last');
						css.attr({
							rel: 'stylesheet',
							type: 'text/css',
							href: designCss
						});
					}


					// Wait for CSS to Load
					setTimeout(function () {


						console.log("PCS: " + serverURL + " " + authToken);
						console.log("TN: " + taskNumber);

						$.pcsConnection = {
							serverURL: serverURL,
							authInfo: authToken
						};

						self.loadDetails(taskNumber);

					}, 1000); // 1 second


				},
				function (err) {
					// PCS module is not loaded
					if (err.requireModules && err.requireModules.indexOf('pcs/pcs.taskdetail') >= 0) {
						self.isPCSModuleLoaded(false);
						SitesSDK.setProperty('height');
					}
				});

		};


		self.loadStrings = function (callback) {
			var locale = self.appParams.locale;
			console.log('loadStrings: locale=' + locale);
			requirejs.config({
				'baseUrl': '/_sitescloud/renderer',

				paths: {
					'scs-components': 'libs/scs-components',

					// Oracle JET
					'ojL10n': 'app/apps/js/ojL10n'
				},
				shim: {
					"jquery-ui": {
						"export": "$",
						deps: ['jquery']
					}
				},
				config: {
					ojL10n: {
						locale: locale
					}
				}
			});

			requirejs(['ojL10n!scs-components/comp/common/nls/CommonResources'],
				function (strings) {
					if (!strings) {
						console.log('loadStrings: translations not found');
					}
					callback(strings);
				});
		};

		//
		// Handle property changes
		//
		self.updateCustomSettingsData = function (customData) {
			// TODO: Why do we need this?
			//self.settingsData(customData);

			self.config = {
				showActions: customData.hasOwnProperty('showActions') ? customData.showActions : true,
				showSave: customData.hasOwnProperty('showSave') ? customData.showSave : true,
				showAttachment: customData.hasOwnProperty('showAttachment') ? customData.showAttachment : true,
				showComments: customData.hasOwnProperty('showComments') ? customData.showComments : true,
				showHistory: customData.hasOwnProperty('showHistory') ? customData.showHistory : true,
				showMoreInfo: customData.hasOwnProperty('showMoreInfo') ? customData.showMoreInfo : true,
				showLinks: customData.hasOwnProperty('showLinks') ? customData.showLinks : true
			};

			self.taskNumber(customData.taskNumber);

			self.customSettingsDataInitialized(true);

			self.getPCSServerInfo(function (pcsServerInfo) {
				if (pcsServerInfo.uri) {
					self.pcsServerURL(pcsServerInfo.uri);
				}
				if (self.pcsServerURL() && customData.taskNumber) {
					if (!taskDetailInitializedFlag) {

						self.getToken(pcsServerInfo.uri, function (authToken) {
							authToken = authToken ? authToken : "Basic " + btoa('bpmqaadmin' + ":" + 'welcome1');
							// get the design css
							SitesSDK.getSiteProperty('themeDesign', function (data) {
								var designCss = '';
								if (data.themeDesign && typeof data.themeDesign === 'string') {
									designCss = data.themeDesign;
								}
								self.initializeTaskDetail(pcsServerInfo.uri, authToken, customData.taskNumber, designCss);
								taskDetailInitializedFlag = true;
							});
						});

					} else {
						self.loadDetails(customData.taskNumber);
					}
				} else {
					if (self.strings === undefined) {
						self.loadStrings(function (strings) {
							self.strings = strings;
							if (strings) {
								if (strings.APP_PCS_TASK_DETAILS_DISPLAY_NAME) {
									self.taskDetailsLabel(strings.APP_PCS_TASK_DETAILS_DISPLAY_NAME);
								}
								if (strings.APP_PCS_TASK_DETAILS_NEW_VERSION_MSG) {
									self.noPCSModuleMsg(strings.APP_PCS_TASK_DETAILS_NEW_VERSION_MSG);
								}
								SitesSDK.setProperty('height');
							}
						});
					}
					SitesSDK.setProperty('height');
				}
			}, function (err) {
				// Error getting the PCS connection. Set the height for the watermark.
				console.log(err);
				if (self.strings === undefined) {
					self.loadStrings(function (strings) {
						self.strings = strings;
						if (strings) {
							if (strings.APP_PCS_TASK_DETAILS_DISPLAY_NAME) {
								self.taskDetailsLabel(strings.APP_PCS_TASK_DETAILS_DISPLAY_NAME);
							}
							if (strings.APP_PCS_TASK_DETAILS_NEW_VERSION_MSG) {
								self.noPCSModuleMsg(strings.APP_PCS_TASK_DETAILS_NEW_VERSION_MSG);
							}
							SitesSDK.setProperty('height');
						}
					});
				}
				SitesSDK.setProperty('height');
			});

		};


		self.updateSettings = $.proxy(function (message) {
			var settings = message.detail ? message.detail.message : message;

			if (settings.property === 'customSettingsData') {
				self.init(settings.value);

			}
		}, self);


		//
		// Execute Actions
		//
		self.executeAction = function (args) {
			var self = this;
			var payload = args.detail.message.payload,
				action = args.detail.message.action;

			if (action && (action.actionName === 'PCSTaskSelected' || action.actionName === 'scsPCSTaskDetailsShowTaskDetails')) {
				var payloadValue = $.isArray(payload) ? (payload[0].value || {}) : payload;
				self.taskNumber(payloadValue);
				self.getPCSServerInfo(function (pcsServerInfo) {
					if (pcsServerInfo.uri) {
						if (!taskDetailInitializedFlag) {
							self.getToken(pcsServerInfo.uri, function (authToken) {
								authToken = authToken ? authToken : "Basic " + btoa('bpmqaadmin' + ":" + 'welcome1');
								// get the design css
								SitesSDK.getSiteProperty('themeDesign', function (data) {
									var designCss = '';
									if (data.themeDesign && typeof data.themeDesign === 'string') {
										designCss = data.themeDesign;
									}
									self.initializeTaskDetail(pcsServerInfo.uri, authToken, payloadValue, designCss);
									taskDetailInitializedFlag = true;
								});
							});
						} else {
							self.loadDetails(payloadValue);
						}

						taskDetailInitializedFlag = true;
					} else {
						// Nothing to do
					}
				});

			}
		};



		// ACTIONS meta-data listener
		var getAppActionsListener = function (args) {
			var strings = self.strings,
				actions = [{
					'actionName': 'scsPCSTaskDetailsShowTaskDetails',
					'actionDescription': strings ? strings.APP_PCS_TASK_DETAILS_ACTION_SHOW : 'Display task details',
					'actionPayload': [{
						'name': 'taskNumber',
						'description': strings ? strings.APP_PCS_TASK_DETAILS_ACTION_PAYLOAD_TASK_NUMBER : 'Task Number',
						'type': {
							'ojComponent': {
								'component': 'ojInputText'
							}
						},
						'value': ''
					}]
				}];
			return actions;
		};


		var getTriggers = function () {
			var strings = self.strings,
				submitTrigger = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_SUBMIT_NAME : 'Task details submitted',
				approveTrigger = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_APPROVE_NAME : 'Task approved',
				rejectTrigger = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_REJECT_NAME : 'Task rejected',
				saveTrigger = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_SAVE_NAME : 'Task saved',
				commentTrigger = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_COMMENT_ADD_NAME : 'Task comment added',
				taskNumberName = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_PAYLOAD_TASK_NUMBER : 'Task Number',
				taskCommentName = strings ? strings.APP_PCS_TASK_DETAILS_TRIGGER_PAYLOAD_COMMENT : 'Comment',
				triggers = [{
					'triggerName': 'scsTaskDetailsSubmitTrigger',
					'triggerDescription': submitTrigger,
					'triggerPayload': [{
						'name': 'taskNumber',
						'displayName': taskNumberName
					}]
				}, {
					'triggerName': 'scsTaskDetailsApproveTrigger',
					'triggerDescription': approveTrigger,
					'triggerPayload': [{
						'name': 'taskNumber',
						'displayName': taskNumberName
					}]
				}, {
					'triggerName': 'scsTaskDetailsRejectTrigger',
					'triggerDescription': rejectTrigger,
					'triggerPayload': [{
						'name': 'taskNumber',
						'displayName': taskNumberName
					}]
				}, {
					'triggerName': 'scsTaskDetailsSaveTrigger',
					'triggerDescription': saveTrigger,
					'triggerPayload': [{
						'name': 'taskNumber',
						'displayName': taskNumberName
					}]
				}, {
					'triggerName': 'scsTaskDetailsCommentAddedTrigger',
					'triggerDescription': commentTrigger,
					'triggerPayload': [{
						'name': 'commentStr',
						'displayName': taskCommentName
					}]
				}];
			return triggers;
		};

		//	Logic on PCSTaskDetailsViewModel 	//
		//	===============================		//	
		//										//	

		//
		// Initialize the customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.init);

		//
		//  Listen for changes to the settings data.
		//      e.g.: When the Settings Panel changes the data
		//
		SitesSDK.subscribe('SETTINGS_UPDATED', self.updateSettings);

		//
		// Sites SDK Triggers and Actions listeners
		//
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeAction, self));

		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getTriggers);

		// listen for ACTIONS meta-data request and send actions metadata to host-site
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_ACTIONS, getAppActionsListener);


	}; // End of PCSTaskDetailsViewModel

	PCSTaskDetailsViewModel.prototype.getPCSServerInfoFromDocs = function (onSuccess, onError) {
		var self = this,
			docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=PCS',
			appInfo,
			i,
			enabled = '',
			pcsServerInfo = {};

		// get server url from docs Admin 
		$.ajax({
			'type': 'GET',
			'dataType': 'json',
			'url': docsConfigUrl,
			'success': function (data) {
				// console.log('docsConfigUrl=' + docsConfigUrl + ' data=' + JSON.stringify(data));
				appInfo = data.ResultSets.AFApplicationInfo;
				if (appInfo) {
					for (i = 0; i < appInfo.fields.length; i++) {
						if (appInfo.fields[i].name === 'dAppEndPoint') {
							pcsServerInfo.uri = appInfo.rows[appInfo.currentRow][i];
						} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
							enabled = appInfo.rows[appInfo.currentRow][i];
						}
						if (pcsServerInfo.uri && enabled) {
							break;
						}
					}
					if (enabled !== '1') {
						pcsServerInfo.uri = '';
					}
				}
				if (pcsServerInfo.uri) {
					self.isECPCS = pcsServerInfo.uri.indexOf('/ic/') >= 0;

					// Fix the URI
					var start;
					if (pcsServerInfo.uri.indexOf('//') >= 0) {
						start = pcsServerInfo.uri.indexOf('//') + 2;
					}
					if (pcsServerInfo.uri.indexOf('/', start) > 0) {
						// remove everything after /
						pcsServerInfo.uri = pcsServerInfo.uri.slice(0, pcsServerInfo.uri.indexOf('/', start));
					}
				} else {
					console.log('getPCSServerInfoFromDocs: url=' + docsConfigUrl + ' no PCS configured');
					if (typeof onError === 'function') {
						onError();
					}
				}

				console.log("PCS Server (from docs admin) is : " + pcsServerInfo.uri + " isEC: " + self.isECPCS);
				if (typeof onSuccess === 'function') {
					onSuccess(pcsServerInfo);
				}
			},
			'error': function (xhr, status, err) {
				console.log('getPCSServerInfoFromDocs: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
				if (typeof onError === 'function') {
					onError();
				}
			}
		});
	};

	PCSTaskDetailsViewModel.prototype.getPCSServerInfo = function (onSuccess, onError) {
		var self = this;

		self.getPCSServerInfoFromDocs(onSuccess, function () {
			$.ajax({
				'type': 'GET',
				'url': '/pxysvc/api/1.0/endpoint',
				'contentType': 'application/json; charset=utf-8',
				'dataType': 'json',
				'success': function (data) {
					if (typeof onSuccess === 'function') {

						var pcsServerInfo = {};
						if (data.length > 0) {
							var i;
							for (i = 0; i < data.length; i++) {

								// Path name should be 'pcs' and keyword should contain 'pcs'
								if (data[i].pathName === 'pcs' && data[i].keywords) {
									var keywords = data[i].keywords.split();
									var j;
									for (j = 0; j < keywords.length; j++) {
										if (keywords[j] === 'pcs') {
											pcsServerInfo.uri = data[i].targetUri;
											break;
										}
									}

									if (pcsServerInfo.uri) {
										// Fix the URI
										var start;
										if (pcsServerInfo.uri.indexOf('//') >= 0) {
											start = pcsServerInfo.uri.indexOf('//') + 2;
										}
										if (pcsServerInfo.uri.indexOf('/', start) > 0) {
											// remove everything after /
											pcsServerInfo.uri = pcsServerInfo.uri.slice(0, pcsServerInfo.uri.indexOf('/', start));
										}
										// Found the PCS URI - break
										break;
									}
								}
							}
						}
						console.log("PCS Server (from proxy) is : " + pcsServerInfo.uri);
						onSuccess(pcsServerInfo);
					}
				},
				'error': function (xhr, status, err) {
					if (typeof onError === 'function') {
						onError(err);
					}
				}
			});
		});

	};

	//-----------------------------------------------
	// Get render Sites SDK parameters, e.g, viewMode
	//-----------------------------------------------
	PCSTaskDetailsViewModel.prototype.getQueryParameters = function (url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	};



	var taskDetailsViewModel = new PCSTaskDetailsViewModel();
	// initialize knockout binding
	ko.applyBindings({
		'templateViewModel': taskDetailsViewModel
	});


})();
