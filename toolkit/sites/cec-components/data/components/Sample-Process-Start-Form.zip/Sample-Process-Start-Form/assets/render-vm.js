/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,requirejs,require,console,btoa,SitesPCSUtils*/
/*jslint node: true,plusplus: true */
'use strict';
var
	StartFormViewModel = function () {
		var self = this,
			temp1 = "bpmqaadmin",
			temp2 = "welcome1",
			getAppTriggersListener;

		self.appParams = self.getQueryParameters(window.location.href);
		self.height = self.appParams.height ? (parseInt(self.appParams.height.replace('px', ''), 10) < 400 ? '400px' : self.appParams.height) : '400px';

		self.initialized = ko.observable(false);

		// whether current mode is edit mode
		self.isRendering = ko.observable(false);
		SitesSDK.getProperty('viewMode', function (viewMode) {
			self.isRendering(viewMode !== 'edit');
		});

		// no selection message
		self.noFormMsg = ko.observable('No Start Form to Display');
		self.errorMsg = ko.observable('');

		// no connection message 
		self.noConnectionMsg = ko.observable('No Process Cloud Service connection');

		self.isAuthed = ko.observable(false);
		self.noAuthMsg = ko.observable('The process start form component can only be viewed on a secure site by users with the Documents Cloud Service User role.');

		// watermark label
		self.startFormLabel = ko.observable('Process Start Form');

		self.serverURL = ko.observable('');

		self.user = ko.observable({});

		self.hasVisualData = ko.observable(false);

		self.processDefId = ko.observable('');

		self.submitConfirmationMsg = ko.observable('');
		self.closeAltText = ko.observable('Close');

		// handle initialization of the viewModel
		self.init = function (config) {
			self.checkAuth(function (authed, user) {
				self.isAuthed(!self.isRendering() || authed);

				if (authed) {
					self.serverURL(self.getPCSServerUrl());
					self.user(user);
				}

				//initialize the observales with settings data
				self.initWithSettings(config);
				// now viewModel has been initialized
				self.initialized(true);

				//listen to the following value changes to adjust render height
				ko.computed(function () {
					var hasVisualData = self.hasVisualData(),
						submitMsg = self.submitConfirmationMsg(),
						errorMsg = self.errorMsg(),
						compLabel = self.startFormLabel(),
						noConnMsg = self.noConnectionMsg(),
						authed = self.isAuthed();

					// unauthorized message
					if (authed === false) {
						SitesSDK.setProperty('height');
					} else {
						// watermark
						if (self.isRendering() === false && hasVisualData === false) {
							SitesSDK.setProperty('height');
						}
						// start form in builder
						if (self.isRendering() === false && hasVisualData === true) {
							SitesSDK.setProperty('height');
						}
						// start form in rendering
						if (self.isRendering() === true && hasVisualData === true) {
							SitesSDK.setProperty('height');
						}
					}
				});
			});
		};


		// get the customSettings Data and init the viewModel
		SitesSDK.getProperty('customSettingsData', self.init);

		self.loadStrings = function (callback) {
			var locale = self.appParams.locale;
			console.log('loadStrings: locale=' + locale);
			requirejs.config({
				'baseUrl': '.',

				paths: {
					// Oracle JET
					'ojL10n': 'js/ojL10n'
				},
				shim: {
					"jquery-ui": {
						"export": "$",
						deps: ['jquery']
					}
				},
				config: {
					ojL10n: {
						locale: locale
					}
				}
			});

			requirejs(['ojL10n!nls/CommonResources'],
				function (strings) {
					if (!strings) {
						console.log('loadStrings: translations not found');
					}
					callback(strings);
				});
		};

		self.initWithSettings = function (config) {

			self.instanceConfig = {
				deployType: config.hasOwnProperty('deployType') ? config.deployType : 1,
				processDefId: config.hasOwnProperty('processDefId') ? config.processDefId : '',
				processName: config.hasOwnProperty('processName') ? config.processName : '',
				serviceName: config.hasOwnProperty('serviceName') ? config.serviceName : '',
				operation: config.hasOwnProperty('operation') ? config.operation : '',
				startType: config.hasOwnProperty('startType') ? config.startType : '',
				formName: config.hasOwnProperty('formName') ? config.formName : 'Form',
				submitButton: config.hasOwnProperty('submitButton') ? config.submitButton : 'Submit',
				submitConfirmation: config.hasOwnProperty('submitConfirmation') ? config.submitConfirmation : 'Form has been submitted successfully',
				showSubmit: config.hasOwnProperty('showSubmit') ? config.showSubmit : true,
				showSubmitConfirmation: config.hasOwnProperty('showSubmitConfirmation') ? config.showSubmitConfirmation : true,
				showSave: config.hasOwnProperty('showSave') ? config.showSave : false,
				showDiscard: config.hasOwnProperty('showDiscard') ? config.showDiscard : false,
				showAttachment: config.hasOwnProperty('showAttachment') ? config.showAttachment : false,
				data: config.hasOwnProperty('data') ? config.data : []
			};

			self.processDefId(self.instanceConfig.processDefId);
			self.formName = ko.observable(self.instanceConfig.formName);
			self.submitButton = ko.observable(self.instanceConfig.submitButton);
			self.showSubmitConfirmation = ko.observable(self.instanceConfig.showSubmitConfirmation);
			self.submitConfirmation = ko.observable(self.instanceConfig.submitConfirmation);

			self.submitConfirmationMsg('');

			self.errorMsg('');

			self.hasVisualData(self.instanceConfig.processDefId !== '');

			if (self.hasVisualData() && self.serverURL()) {
				// get the token
				self.getToken(self.serverURL(), function (token) {
					// get the design css
					SitesSDK.getSiteProperty('themeDesign', function (data) {
						var designCss = '';
						if (data.themeDesign && typeof data.themeDesign === 'string') {
							designCss = data.themeDesign;
						}
						self.initStartForm(self.instanceConfig, self.serverURL(), token, designCss);
					});
				});
			} else {
				if (self.strings === undefined) {
					self.loadStrings(function (strings) {
						self.strings = strings;
						if (strings) {
							if (strings.APP_STARTFORM_DISPLAY_NAME) {
								self.startFormLabel(strings.APP_STARTFORM_DISPLAY_NAME);
							}
							if (strings.APP_STARTFORM_NO_CONNECTION_WARNING) {
								self.noConnectionMsg(strings.APP_STARTFORM_NO_CONNECTION_WARNING);
							}
						}
					});
				}
			}
		};

		//listen for settings update
		// SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.handleUpdatedSettings, self));
		SitesSDK.subscribe('SETTINGS_UPDATED', function (event) {
			var payload;
			if (typeof event.detail.message === 'object') {
				payload = event.detail.message;
			} else if (typeof event.detail.message === 'string') {
				try {
					payload = JSON.parse(event.detail.message);
				} catch (err) {
					payload = {};
				}
			} else {
				payload = {};
			}

			if (payload.property) {
				if (payload.property === 'customSettingsData') {
					//console.log('Updated customSettingsData: ' + JSON.stringify(payload, null, 2));
					//apply update

					self.initWithSettings(payload.value);
					// window.location.reload(false);
				}
			}
		});

		self.closeSubmitConfirm = function () {
			// remove the message
			self.submitConfirmationMsg('');
		};

		// check if it is a logged in session
		self.checkAuth = function (callback) {
			var url = '/documents/web?IdcService=GET_USER_INFO',
				i,
				dLoginNameIdx,
				dNameFullNameIdx,
				userId,
				userName,
				user = {
					'id': '',
					'name': ''
				};

			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': url,
				'success': function (data) {
					if (data.LocalData.StatusCode === '0') {
						for (i = 0; i < data.ResultSets.USER_INFO.fields.length; i++) {
							if (data.ResultSets.USER_INFO.fields[i].name === 'dLoginName') {
								dLoginNameIdx = i;
							} else if (data.ResultSets.USER_INFO.fields[i].name === 'dNameFullName') {
								dNameFullNameIdx = i;
							}
						}
						userId = data.ResultSets.USER_INFO.rows[0][dLoginNameIdx];
						userName = data.ResultSets.USER_INFO.rows[0][dNameFullNameIdx];
						user = {
							'id': userId,
							'name': userName
						};
					}
					console.log('startform: authorized user=' + JSON.stringify(user));
					callback(data.LocalData.StatusCode === '0', user);
				},
				'error': function (xhr, status, err) {
					console.log('startform: unauthorized, status: ' + status + ' error: ' + err);
					callback(false, user);
				}
			});
		};

		// get server url from proxy server
		self.getPCSServerUrl = function () {
			var serverUrl = '',
				enabled = '',
				endpointUrl = '/pxysvc/api/1.0/endpoint',
				docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=PCS',
				appInfo,
				i,
				start = 0;

			// get server url from docs Admin first
			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docsConfigUrl,
				async: false,
				'success': function (data) {
					// console.log('docsConfigUrl=' + docsConfigUrl + ' data=' + JSON.stringify(data));
					appInfo = data.ResultSets.AFApplicationInfo;
					if (appInfo) {
						for (i = 0; i < appInfo.fields.length; i++) {
							if (appInfo.fields[i].name === 'dAppEndPoint') {
								serverUrl = appInfo.rows[appInfo.currentRow][i];
							} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
								enabled = appInfo.rows[appInfo.currentRow][i];
							}
							if (serverUrl && enabled) {
								break;
							}
						}
						if (enabled !== '1') {
							serverUrl = '';
						}
					}
				},
				'error': function (xhr, status, err) {
					console.log('getPCSServerUrl: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
				}
			});

			if (!serverUrl) {
				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': endpointUrl,
					async: false,
					'success': function (data) {
						// console.log('endpoints=' + JSON.stringify(data));
						if (data && data.length > 0) {
							for (i = 0; i < data.length; i++) {
								if (data[i].pathName.toLowerCase().indexOf('pcs') >= 0 && data[i].keywords.toLowerCase().indexOf('pcs') >= 0 && data[i].enabled === true) {
									serverUrl = data[i].targetUri;
									break;
								}
							}
						}
					},
					'error': function (xhr, status, err) {
						console.error('getPCSServerUrl: url=' + endpointUrl + ' status: ' + status + ' error: ' + err);
					}
				});
			}

			if (serverUrl) {
				self.isECPCS = serverUrl.indexOf('/ic/') >= 0;

				if (serverUrl.indexOf('//') >= 0) {
					start = serverUrl.indexOf('//') + 2;
				}
				if (serverUrl.indexOf('/', start) > 0) {
					// remove everything after /
					serverUrl = serverUrl.slice(0, serverUrl.indexOf('/', start));
				}
			}
			console.log('PCS server: ' + serverUrl + ' isEC: ' + self.isECPCS);
			return serverUrl;
		};

		self.getToken = function (serverURL, callback) {
			var token;

			SitesPCSUtils.getAuthToken({
				'serverURL': serverURL,
				'successCallback': function (data) {
					token = data;
					callback(token);
				},
				'errorCallback': function (xhr, status, err) {
					if (xhr && xhr.status === 200) {
						token = xhr.responseText;
					} else {
						console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
					}
					callback();
				}
			});
		};

		//
		// Sites SDK Triggers and Actions listeners
		//

		// TRIGGERS meta-data listener
		getAppTriggersListener = function (args) {
			var strings = self.strings,
				submitTriggerDesc = strings ? strings.APP_STARTFORM_TRIGGER_SUBMIT_NAME : 'Start form submitted',
				saveTriggerDesc = strings ? strings.APP_STARTFORM_TRIGGER_SAVE_NAME : 'Start form saved',
				discardTriggerDesc = strings ? strings.APP_STARTFORM_TRIGGER_DISCARD_NAME : 'Start form discarded',
				processDefId = strings ? strings.APP_STARTFORM_TRIGGER_PAYLOAD_PROCESS_DEF_ID : 'Process Definition Id',
				processId = strings ? strings.APP_STARTFORM_TRIGGER_PAYLOAD_PROCESS_ID : 'Process Id',
				processName = strings ? strings.APP_STARTFORM_TRIGGER_PAYLOAD_PROCESS_NAME : 'Process Name',
				applicationName = strings ? strings.APP_STARTFORM_TRIGGER_PAYLOAD_APPLICATION_NAME : 'Application Name',
				convoId = strings ? strings.APP_STARTFORM_TRIGGER_PAYLOAD_CONVERSATION_ID : 'Conversation Id',
				triggers = [{
						'triggerName': 'scsStartFormSubmitTrigger',
						'triggerDescription': submitTriggerDesc,
						'triggerPayload': [{
								'name': 'processDefId',
								'displayName': processDefId
							},
							{
								'name': 'processId',
								'displayName': processId
							},
							{
								'name': 'processName',
								'displayName': processName
							},
							{
								'name': 'applicationName',
								'displayName': applicationName
							},
							{
								'name': 'conversationId',
								'displayName': convoId
							}
						]
					},
					{
						'triggerName': 'scsStartFormSaveTrigger',
						'triggerDescription': saveTriggerDesc,
						'triggerPayload': [{
								'name': 'processDefId',
								'displayName': processDefId
							},
							{
								'name': 'processId',
								'displayName': processId
							},
							{
								'name': 'processName',
								'displayName': processName
							},
							{
								'name': 'applicationName',
								'displayName': applicationName
							}
						]
					},
					{
						'triggerName': 'scsStartFormDiscardTrigger',
						'triggerDescription': discardTriggerDesc,
						'triggerPayload': [{
								'name': 'processDefId',
								'displayName': processDefId
							},
							{
								'name': 'processName',
								'displayName': processId
							},
							{
								'name': 'applicationName',
								'displayName': applicationName
							}
						]
					}
				];

			return triggers;
		};

		// listen for TRIGGERS meta-data request and send trigger metadata to host-site
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getAppTriggersListener);

		// create and render the start form
		self.initStartForm = function (config, serverURL, authToken, designCss) {

			if (!config.processDefId || !config.processName || !config.serviceName) {
				console.log('initStartForm: No start form defined config=' + JSON.stringify(config));
				return;
			}

			var requireconfig = {};
			if (self.isECPCS) {
				requireconfig = {
					baseUrl: serverURL + "/ic/pub/components/js",
					urlArgs: "bust=18.2.3-sites",
					paths: {
						"knockout": "libs/knockout/knockout-3.4.0",
						"jquery": "libs/jquery/jquery-3.1.1.min",
						"jqueryui-amd": "libs/jquery/jqueryui-amd-1.12.0",
						"ojs": "libs/oj/v3.2.0/debug",
						"ojL10n": "libs/oj/v3.2.0/ojL10n",
						"ojtranslations": "libs/oj/v3.2.0/resources",
						"text": "libs/require/text",
						"promise": "libs/es6-promise/es6-promise-4.0.5.min",
						"hammerjs": "libs/hammer/hammer-2.0.8.min",
						"signals": "libs/js-signals/signals.min",
						"ojdnd": "libs/dnd-polyfill/dnd-polyfill-1.0.0.min",
						"customElements": "libs/webcomponents/CustomElements.min",
						"proj4": "libs/proj4js/dist/proj4",
						"underscore": "libs/underscore/underscore-1.8.3.min",
						"pcs": "libs/pcs/v1.1/min"
					},
					"shim": {
						"jquery": {
							"exports": ["jQuery", "$"]
						}
					}
				};


			} else {
				requireconfig = {
					baseUrl: serverURL + "/bpm/components/js",
					urlArgs: "bust=17.2.3-sites",
					paths: {
						'knockout': 'libs/knockout/knockout-3.4.0',
						'jquery': 'libs/jquery/jquery-2.1.3.min',
						'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.11.4.min',
						'promise': 'libs/es6-promise/promise-1.0.0.min',
						'hammerjs': 'libs/hammer/hammer-2.0.4.min',
						'underscore': 'libs/underscore/underscore-1.8.3.min',
						'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.0.min',
						'ojs': 'libs/oj/v2.0.0/min',
						'ojL10n': 'libs/oj/v2.0.0/ojL10n',
						'ojtranslations': 'libs/oj/v2.0.0/resources',
						'signals': 'libs/js-signals/signals.min',
						'text': 'libs/require/text',
						'pcsMsg': SitesPCSUtils.paths.pcsMsg,
						'pcs': SitesPCSUtils.paths.pcs,
						'rendererMsg': SitesPCSUtils.paths.rendererMsg
					},
					shim: {
						'jquery': {
							exports: ['jQuery', '$']
						}
					},
					config: {
						ojL10n: {
							merge: {
								'ojtranslations/nls/ojtranslations': 'libs/pcs/v1.1/resources/nls/pcsSnippetsResource'
							}
						}
					}
				};
			}
			requirejs.config(requireconfig);

			require(['jquery', 'pcs/pcs.startform'],
				function ($, startform) {
					var css,
						pcsCss,
						ojCss,
						testMode,
						authorizationEncodedString,
						div,
						startformDiv,
						i,
						value,
						payload = {};

					console.log(serverURL);

					$('head').append('<link>');
					css = $('head').children(':last');
					pcsCss = serverURL + (self.isECPCS ? "/ic/pub/components/css/libs/pcs/v1.1/alta/pcs-startform-min.css" : "/bpm/components/css/libs/pcs/v1.3/alta/pcs-startform-min.css");
					css.attr({
						rel: 'stylesheet',
						type: 'text/css',
						href: pcsCss
					});

					$('head').append('<link>');
					css = $('head').children(':last');
					ojCss = serverURL + (self.isECPCS ? "/ic/pub/components/css/libs/oj/v3.2.0/alta/oj-alta-min.css" : "/bpm/components/css/libs/oj/v2.0.0/alta/oj-alta-min.css");
					css.attr({
						rel: 'stylesheet',
						type: 'text/css',
						href: ojCss
					});

					// design.css
					console.log('design.css: ' + designCss);
					if (designCss) {
						$('head').append('<link>');
						css = $('head').children(':last');
						css.attr({
							rel: 'stylesheet',
							type: 'text/css',
							href: designCss
						});
					}


					// Wait for CSS to Load
					setTimeout(function () {
						console.log('Waiting for css to load');
						if (config.deployType === 0) {
							testMode = true;
							console.log('The start form is from Test partition');
						} else {
							testMode = false;
						}

						authorizationEncodedString = authToken ? "Bearer " + authToken : "Basic " + btoa(temp1 + ":" + temp2);
						// console.log('initStartForm: authorizationEncodedString=' + authorizationEncodedString);

						$.pcsConnection = {
							serverURL: serverURL,
							authInfo: authorizationEncodedString,
							testMode: testMode
						};

						startformDiv = $("#startform");

						//if the plugin was already used  clean it up
						if (startformDiv && startformDiv.data() && !$.isEmptyObject(startformDiv.data())) {
							console.log('clean up the plugin');
							startformDiv.startform('destroy');
						}
						ko.cleanNode(startformDiv['0']);

						div = startformDiv.parent();
						div.html('<div id="startform"></div>');

						startformDiv = $("#startform");

						for (i = 0; i < config.data.length; i++) {
							if (config.data[i].name && config.data[i].value) {
								value = config.data[i].value;
								value = value.replace('%%userid%%', self.user().id).replace('%%username%%', self.user().name);
								payload[config.data[i].name] = value;
							}
						}

						console.log('startform config: ' + JSON.stringify(config) + ' payload=' + JSON.stringify(payload));
						$("#startform").startform({
							startformData: {
								processDefId: config.processDefId,
								processName: config.processName,
								serviceName: config.serviceName,
								title: config.formName,
								operation: config.operation,
								startType: config.startType
							},
							payload: payload,
							hideStartform: false,
							hideSubmit: (!config.showSubmit),
							submitLabel: config.submitButton,
							hideSave: (!config.showSave),
							hideDiscard: (!config.showDiscard),
							hideAttachment: (!config.showAttachment)
						});

						// Defining the event listeners 
						startformDiv.on('startform:submit', function (event, data, instance) {
							self.fireSubmitEvent(data, instance);
						});

						startformDiv.on('startform:save', function (event, data, instance) {
							self.fireSaveEvent(data, instance);
						});

						startformDiv.on('startform:discard', function (event, data) {
							self.fireDiscardEvent(data);
						});

						// set the height for the forms of type START_PCS_FORM
						startformDiv.on('startform:loaded', function (event, data, action) {
							//console.log("start form loaded...");
							SitesSDK.setProperty('height');

							// load strings
							if (!self.isRendering() && self.strings === undefined) {
								self.loadStrings(function (strings) {
									self.strings = strings;
									SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getAppTriggersListener);
								});
							}
						});

						// wait to set height for forms of type START_FORM 
						window.addEventListener('message', self.receivePostMessage);

						// set the height for the component after form rendered
						// console.log('The form height: ' + $('#startform').outerHeight(true));
						SitesSDK.setProperty('height');
					}, 1000); // 1 second
				},
				function (err) {
					var failedId = err.requireModules && err.requireModules[0];
					console.log('require error: ' + JSON.stringify(err));
					if (failedId === 'pcs/pcs.startform') {
						// PCS server version not match, show error
						self.errorMsg('Newer Process Cloud Service version is required.');
					}
				});

		}; // initStartForm

		self.fireSubmitEvent = function (data, instance) {
			var processConversationId,
				tmpApplicationName,
				triggerPayload,
				authorizationEncodedString;

			self.getToken(self.serverURL(), function (authToken) {
				self.submitConfirmationMsg(self.submitConfirmation());

				authorizationEncodedString = authToken ? "Bearer " + authToken : "Basic " + btoa(temp1 + ":" + temp2);
				console.log('fireSubmitEvent: authorizationEncodedString=' + authorizationEncodedString);

				processConversationId = self.getConversationId(self.serverURL(), authorizationEncodedString, instance.processId);

				tmpApplicationName = data.processDefId.split('!')[0].split('~')[1].replace(/_/g, '');

				triggerPayload = {
					processDefId: data.processDefId,
					applicationName: tmpApplicationName,
					processName: data.processName,
					processId: instance.processId,
					creator: instance.creator,
					conversationId: processConversationId
				};

				SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
					'triggerName': 'scsStartFormSubmitTrigger',
					'triggerPayload': triggerPayload
				});

				console.log('Fired scsStartFormSubmitTrigger: ' + JSON.stringify(triggerPayload));
			});
		};

		self.fireSaveEvent = function (data, instance) {
			var tmpApplicationName,
				triggerPayload;

			self.submitConfirmationMsg('');

			tmpApplicationName = data.processDefId.split('!')[0].split('~')[1].replace(/_/g, '');

			triggerPayload = {
				processDefId: data.processDefId,
				applicationName: tmpApplicationName,
				processName: data.processName,
				processId: instance.processId,
				creator: instance.creator
			};

			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsStartFormSaveTrigger',
				'triggerPayload': triggerPayload
			});
			console.log('Fired scsStartFormSaveTrigger: ' + JSON.stringify(triggerPayload));
		};

		self.fireDiscardEvent = function (data) {
			var tmpApplicationName,
				triggerPayload;

			tmpApplicationName = data.processDefId.split('!')[0].split('~')[1].replace(/_/g, '');

			triggerPayload = {
				processDefId: data.processDefId,
				applicationName: tmpApplicationName,
				processName: data.processName
			};

			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': 'scsStartFormDiscardTrigger',
				'triggerPayload': triggerPayload
			});
			console.log('Fired scsStartFormDiscardTrigger: ' + JSON.stringify(triggerPayload));

			// re-render the form and clear the form fields
			self.initWithSettings(self.instanceConfig);
		};

		self.getConversationId = function (pcsServerURL, authorizationEncodedString, pcsInstanceId) {
			var numTries = 0,
				gap = 700,
				totalTrial = 15,
				conversationId = "";
			while (conversationId === "" && numTries < totalTrial) {
				conversationId = self.getConversationIdRestCall(pcsServerURL, authorizationEncodedString, pcsInstanceId);
				if (conversationId === "") {
					numTries++;
					if (numTries > 10) {
						gap = 2000;
					} else if (numTries > 5) {
						gap = 1500;
					}
					console.log("Attempting to retrieve conversation Id (Try = " + numTries + ")(wait = " + gap + ")");
					self.sleep(gap);
				}
			}
			return conversationId;

		};

		self.getConversationIdRestCall = function (pcsServerURL, authorizationEncodedString, pcsInstanceId) {

			// Retrieve the Conversation ID for this instance.
			var conversationId = "",
				restURL = pcsServerURL + (self.isECPCS ? "/ic/api/process/v1/processes/" : "/bpm/api/3.0/processes/") + pcsInstanceId + "/conversations";

			$.ajax({
				type: "GET",
				async: false,
				url: restURL,
				headers: {
					'Authorization': authorizationEncodedString
				},
				contentType: "application/json",
				dataType: "json",
				success: function (data) {
					if (data !== null) {
						console.log('data=' + JSON.stringify(data));
						if (data.conversationInstanceList && data.conversationInstanceList.length > 0) {
							conversationId = data.conversationInstanceList[0].conversationId;
						}
					} else {
						console.log("REST Get Call returned Data as null");
					}
				},
				failure: function (errMsg) {
					console.error(errMsg);
				},
				error: function (xhr) {
					console.log("Conversation not created yet...");
				}
			});

			return conversationId;
		};

		self.sleep = function (delay) {
			var start = new Date().getTime();
			while (true) {
				if (new Date().getTime() >= start + delay) {
					break;
				}
			}
		};

		// set height after start form rendered
		self.receivePostMessage = function (event) {
			var key,
				data;
			if (event.origin !== self.serverURL()) {
				return;
			}
			key = event.message ? "message" : "data";
			data = event[key];
			if (data.startsWith('formHeight')) {
				console.log('setting height: ' + $('#startform').outerHeight(true));
				SitesSDK.setProperty('height');
			}
		};

		// end of the view model
	};


//-----------------------------------------------
// Get render Sites SDK parameters, e.g, viewMode
//-----------------------------------------------
StartFormViewModel.prototype.getQueryParameters = function (url) {
	var anchorEle = document.createElement('a'),
		//query parameters
		parameters = {},
		queries,
		i,
		split;

	// set the URL in the anchor, which will also parse it
	anchorEle.href = url;
	// anchorEle.search returns ?x=y&a=b... part of the url string
	queries = anchorEle.search.replace(/^\?/, '').split('&');
	for (i = 0; i < queries.length; i += 1) {
		split = queries[i].split('=');
		parameters[split[0]] = decodeURIComponent(split[1]);
	}

	return parameters;
};
