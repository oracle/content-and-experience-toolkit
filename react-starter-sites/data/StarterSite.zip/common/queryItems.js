/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */

require('es6-promise').polyfill();
require('isomorphic-fetch');

export const QUERY_ITEMS_BEGIN = 'QUERY_ITEMS_BEGIN';
export const QUERY_ITEMS_SUCCESS = 'QUERY_ITEMS_SUCCESS';
export const QUERY_ITEMS_FAILURE = 'QUERY_ITEMS_FAILURE';

export const GET_ITEM_BEGIN = 'GET_ITEM_BEGIN';
export const GET_ITEM_SUCCESS = 'GET_ITEM_SUCCESS';
export const GET_ITEM_FAILURE = 'GET_ITEM_FAILURE';

export const queryItemsBegin = (namespace) => ({
	type: QUERY_ITEMS_BEGIN,
	payload: {
		namespace: namespace
	}
});

export const queryItemsSuccess = (namespace, items) => ({
	type: QUERY_ITEMS_SUCCESS,
	payload: {
		namespace: namespace,
		items: items
	}
});

export const queryItemsError = (namespace, error) => ({
	type: QUERY_ITEMS_FAILURE,
	payload: {
		namespace: namespace,
		error: error
	}
});

// Handle HTTP errors since fetch won't.
function handleErrors(response) {
	if (!response.ok) {
		throw Error(response.statusText);
	}
	return response;
}

export function queryItems(siteName, language, query) {
	var typeName = query.type;
	var searchString = query.searchString;
	var q = language ? '((type eq "' + typeName + '") and (language eq "' + language + '"))' : '((type eq "' + typeName + '"))';
	var queryString = '?fields=ALL&q=' + q;
	queryString = queryString + '&orderBy=' + (query.orderBy ? query.orderBy : 'updatedDate:des');
	queryString = queryString + '&limit=' + (query.limit ? query.limit : '10');
	if (query.offset) {
		queryString = queryString + '&offset=' + query.offset;
	}
	if (searchString) {
		queryString = queryString + '&default=' + searchString + '*';
	}
	
	// Used to retrieve data
	var namespace = JSON.stringify(query);

	return dispatch => {
		dispatch(queryItemsBegin(namespace));
		var itemsUrl = '/api/content/published/api/v1.1/items' + queryString
		// console.log(itemsUrl);
		return fetch(itemsUrl)
			.then(handleErrors)
			.then(res => res.json())
			.then(json => {
				dispatch(queryItemsSuccess(namespace, json));
				return json;
			})
			.catch(error => dispatch(queryItemsError(namespace, error)));
	};
}

export const getItemBegin = (id) => ({
	type: GET_ITEM_BEGIN,
	payload: {
		id: id
	}
});

export const getItemSuccess = (id, item) => ({
	type: GET_ITEM_SUCCESS,
	payload: {
		id: id,
		item: item
	}
});

export const getItemError = (id, error) => ({
	type: GET_ITEM_FAILURE,
	payload: {
		id: id,
		error: error
	}
});

export function getItem(siteName, language, id) {
	return dispatch => {
		dispatch(getItemBegin(id));
		var itemUrl = '/api/content/published/api/v1.1/items/' + id;
		if (language) {
			itemUrl += '/variations/language/' + language;
		}
		// Query reference items
		itemUrl += '?expand=all';
		// console.log(itemUrl);
		return fetch(itemUrl)
			.then(handleErrors)
			.then(res => res.json())
			.then(json => {
				dispatch(getItemSuccess(id, json));
				return json;
			})
			.catch(error => dispatch(getItemError(id, error)));
	};
}
