/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */
import React from 'react';
import renderHTML from 'react-render-html';
import PropTypes from 'prop-types';

import { SITE_NAME } from "../Constants";

class ItemMultiValues extends React.Component {

	render() {

		var values = this.props.values;
		var type = this.props.type;
		var rootPath = '/';	
		var list = values || [];
		const listValues = list.map((value, i) => {
			var element;
			if (!value) {
				element = <div />;
			} else if (type === 'direct') {
				element = <span key={value}> {value} </span>;
			} else if (type === 'image') {
				element = <img key={value.id} src={ '/api/content/published/api/v1.1/assets/' + value['id'] + '/native' } />
			} else if (type === 'richtext') {
				element = <div key={value.id}>{renderHTML(value)}</div>
			} else if (type === 'reference') {
				element = <span key={value.id}><a href={ rootPath + value['type'] + '/' + value['id'] }>{value['type']}{value['name'] ? ':' + value['name'] : ''}</a></span>
			} else {
				element = <div key={value.id}> </div>;
			}
		return (
				element
			);
		});
		
		return (
			<div>
				<div>{listValues}</div>
			</div>
		);
	}
}

ItemMultiValues.propTypes = {
	values: PropTypes.array.isRequired,
	type: PropTypes.string.isRequired
};

export default ItemMultiValues;
