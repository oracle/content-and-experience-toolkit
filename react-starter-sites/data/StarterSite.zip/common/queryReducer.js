/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */

import {
	QUERY_ITEMS_BEGIN,
	QUERY_ITEMS_SUCCESS,
	QUERY_ITEMS_FAILURE,
	GET_ITEM_BEGIN,
	GET_ITEM_SUCCESS,
	GET_ITEM_FAILURE
} from './queryItems';

const initialState = {
	itemsQueryResult: {},
	itemQueryResult: {}
};

export default function queryReducer(state = initialState, action) {
	switch (action.type) {
		case QUERY_ITEMS_BEGIN:
			// Mark the state as "loading" so we can show a spinner or something
			// Also, reset any errors. We're starting fresh.
			var result = {
				...state
			};
			if (action.payload.namespace) {
				result['itemsQueryResult'][action.payload.namespace] = {
					loading: true,
					error: null,
					items: []
				};
			}
			return result;

		case QUERY_ITEMS_SUCCESS:
			// All done: set loading "false".
			// Also, replace the items with the ones from the server
			var result = {
				...state
			};
			if (action.payload.namespace) {
				result['itemsQueryResult'][action.payload.namespace] = {
					loading: false,
					error: null,
					items: action.payload.items.items
				};
			}

			return result;

		case QUERY_ITEMS_FAILURE:
			// The request failed, but it did stop, so set loading to "false".
			// Save the error, and we can display it somewhere
			// Since it failed, we don't have items to display anymore, so set it empty.
			// This is up to you and your app though: maybe you want to keep the items
			// around! Do whatever seems right.
			var result = {
				...state
			};
			if (action.payload.namespace) {
				result['itemsQueryResult'][action.payload.namespace] = {
					loading: false,
					error: action.payload.error,
					items: []
				};
			}
			return result;

		case GET_ITEM_BEGIN:
			var result = {
				...state
			};

			if (action.payload.id) {
				result['itemQueryResult'][action.payload.id] = {
					loading: true,
					error: null,
					item: undefined
				};
			}
			return result;

		case GET_ITEM_SUCCESS:
			var result = {
				...state
			};

			if (action.payload.id) {
				result['itemQueryResult'][action.payload.id] = {
					loading: false,
					error: null,
					item: action.payload.item
				};
			}
			return result;

		case GET_ITEM_FAILURE:
			var result = {
				...state
			};

			if (action.payload.id) {
				result['itemQueryResult'][action.payload.id] = {
					loading: false,
					error: action.payload.error,
					item: undefined
				};
			}
			return result;

		default:
			// ALWAYS have a default case in a reducer
			return state;
	}
}
