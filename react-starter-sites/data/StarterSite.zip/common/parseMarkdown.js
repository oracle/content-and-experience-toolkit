/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */

import Marked from 'marked';

export default function parseMarkdown(mdText) {
	if (mdText && /^<!---mde-->\n\r/i.test(mdText)) {
		mdText = mdText.replace("<!---mde-->\n\r", "");
		mdText = Marked(mdText);
	}

	return mdText;
}

