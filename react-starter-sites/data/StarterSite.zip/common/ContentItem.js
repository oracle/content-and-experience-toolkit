/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */
import React from 'react';
import { connect } from "react-redux";
import PropTypes from 'prop-types';

import { getItem } from './queryItems';

class ContentItem extends React.Component {

	componentDidMount() {
		this.props.dispatch(getItem(this.props.site, this.props.language, this.props.id));
	}

	render() {

		const { error, loading, item } = this.props;
		if (error) {
			return <div>Error! {error.message}</div>;
		}
		if (loading) {
			return <div>Loading...</div>;
		}
		
		const element = <this.props.contentLayout  {...this.props} item={item} />;
		
		return (
			<div className="ContentItem">
				{element}
			</div>
		);
	}

}

function mapStateToProps(state, ownProps) {
	
	var id = ownProps.id;
	var result = state.itemQueryResult[id];

	return {
		item: result ? result.item : undefined,
		loading: result ? result.loading : false,
		error: result ? result.error : ''
	};
};

ContentItem.propTypes = {
	site: PropTypes.string.isRequired,
	id: PropTypes.string.isRequired,
	contentLayout: PropTypes.func.isRequired
};

export default connect(mapStateToProps)(ContentItem);

