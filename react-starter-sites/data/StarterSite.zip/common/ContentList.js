/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals console */
/* jshint esversion: 6 */
import React from 'react';
import { connect } from "react-redux";
import PropTypes from 'prop-types';

import { queryItems } from './queryItems';

class ContentList extends React.Component {

	componentDidMount() {
		this.props.dispatch(queryItems(this.props.site, this.props.language, this.props.query));
	}

	render() {
		const { error, loading, items } = this.props;
		if (error) {
			return <div>Error! {error.message}</div>;
		}
		if (loading) {
			return <div>Loading...</div>;
		}
		var list = items || [];
		const listItems = list.map((item, i) => {
			// console.log(item);
			const element = <this.props.contentLayout {...this.props} key={item.id} item={item} />;
		return (
				element
			);
		});
		
		return (
			<div className="ContentList">
				<div>{listItems}</div>
			</div>
		);
	}

}

function mapStateToProps(state, ownProps) {
	
	var namespace = JSON.stringify(ownProps.query);
	var result = state.itemsQueryResult[namespace];
	
	return {
		items: result ? result.items : [],
		loading: result ? result.loading : false,
		error: result ? result.error : ''
	};
};

ContentList.propTypes = {
	site: PropTypes.string.isRequired,
	query: PropTypes.object.isRequired,
	contentLayout: PropTypes.func.isRequired
};

export default connect(mapStateToProps)(ContentList);
