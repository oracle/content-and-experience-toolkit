/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* jshint esversion: 6 */

import React from 'react';
import renderHTML from 'react-render-html';

import { SITE_NAME } from "../Constants";
import ContentList from '../common/ContentList.js';
import ContentItem from '../common/ContentItem.js';
import ItemMultiValues from '../common/ItemMultiValues.js';
import Searchbar from '../common/Searchbar.js';
import parseMarkdown from '../common/parseMarkdown.js';

var rootPath = '/';

class {{component}} extends React.Component {
	render() {
		var id, search, limit, offset, orderBy;
		if (this.props.match && this.props.match.params) {
			id = this.props.match.params.id;
			search = this.props.match.params.search;
			limit = this.props.match.params.limit;
			offset = this.props.match.params.offset;
			orderBy = this.props.match.params.orderBy;
		}
		if (id) {
			return (
				<ContentItem site={SITE_NAME} language={this.props.language} id={id} contentLayout={ {{component}}Detail} />
			);
		} else if (search) {
			//
			// You can also set orderBy, limit and offset, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			//  offset: 10
			// If not set, the default value for orderBy is updatedDate:des, the default value for limit is 10
			// and the default value for offset is 0
			var queryParam = {
				type: '{{type}}',
				searchString: search
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (offset) {
				queryParam['offset'] = offset;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
			return (
				<div>
				<h2 className="type-title">{{type}}</h2>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ {{component}}Summary} />
				</div>
			);
		} else {
			//
			// You can also set orderBy, limit and offset, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			//  offset: 10
			// If not set, the default value for orderBy is updatedDate:des, the default value for limit is 10
			// and the default value for offset is 0
			var queryParam = {
				type: '{{type}}'
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (offset) {
				queryParam['offset'] = offset;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
			return (
				<div>
				<h2 className="type-title">{{type}}</h2>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ {{component}}Summary} />
				</div>
			);
		}
   	}
}

class {{component}}Summary extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id || !item.fields) {
			return (
				<div />
			);
		}
		var detailUrl = (this.props.language ? '/' + this.props.language  : '') + '/{{type}}/' + item.id;
		return (
			<div className="{{type}}"> 
			<hr/>
			{{#fields}}
                        {{#__render.forsummary}}
			{{#__render.direct}}
			<span>{item.fields['{{name}}']}</span>
			{{/__render.direct}}
			{{#__render.image}}
			{item.fields['{{name}}'] ? <img src={ '/api/content/published/api/v1.1/assets/' + item.fields['{{name}}']['id'] + '/native' } /> : <span />}
			{{/__render.image}}
                        {{/__render.forsummary}}
			{{/fields}}
			<span><a href={ detailUrl }>Details</a></span>
			</div>
		);
	}
}

class {{component}}Detail extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id || !item.fields) {
			return (
				<div />
			);
		}
		return (
			<div className="{{type}}">

			{{#fields}}
			{{#__render.single}}
			{{#__render.direct}}
			<span>{item.fields['{{name}}']}</span>
			{{/__render.direct}}
			{{#__render.image}}
			{item.fields['{{name}}'] ? <img src={ '/api/content/published/api/v1.1/assets/' + item.fields['{{name}}']['id'] + '/native' } /> : <span />}
			{{/__render.image}}
			{{#__render.datetime}}
			{item.fields['{{name}}'] ? <span>{item.fields['{{name}}']['value']}</span> : <span />}
			{{/__render.datetime}}
			{{#__render.richtext}}
			{item.fields['{{name}}'] ? <div>{renderHTML(item.fields['{{name}}'])}</div> : <div />}
			{{/__render.richtext}}
			{{#__render.markdown}}
			{item.fields['{{name}}'] ? <div>{renderHTML(parseMarkdown(item.fields['{{name}}']))}</div> : <div />}
			{{/__render.markdown}}
			{{#__render.reference}}
			{{#langugeEnabled}}
			{item.fields['{{name}}'] ? <span><a href={ rootPath + item.fields['{{name}}']['language'] + '/' + item.fields['{{name}}']['type'] + '/' + item.fields['{{name}}']['id'] }>{item.fields['{{name}}']['type']}{item.fields['{{name}}']['name'] ? ':' + item.fields['{{name}}']['name'] : ''}</a></span> : <span />}
			{{/langugeEnabled}}
			{{^langugeEnabled}}
			{item.fields['{{name}}'] ? <span><a href={ rootPath + item.fields['{{name}}']['type'] + '/' + item.fields['{{name}}']['id'] }>{item.fields['{{name}}']['type']}{item.fields['{{name}}']['name'] ? ':' + item.fields['{{name}}']['name'] : ''}</a></span> : <span />}
			{{/langugeEnabled}}
			{{/__render.reference}}
			{{/__render.single}}
			{{#__render.multiple}}
			{{#__render.direct}}
			<ItemMultiValues type='direct' values={item.fields['{{name}}']}/>
			{{/__render.direct}}
			{{#__render.image}}
			<ItemMultiValues type='image' values={item.fields['{{name}}']}/>
			{{/__render.image}}
			{{#__render.richtext}}
			<ItemMultiValues type='richtext' values={item.fields['{{name}}']}/>
			{{/__render.richtext}}
			{{#__render.reference}}
			<ItemMultiValues type='reference' values={item.fields['{{name}}']}/>
			{{/__render.reference}}
			{{/__render.multiple}}
			{{/fields}}

			</div>
		);
	}
}      

export default {{component}};

