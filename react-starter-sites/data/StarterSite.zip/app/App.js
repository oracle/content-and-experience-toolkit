/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* jshint esversion: 6 */

import React from 'react'
import { Route, Switch } from 'react-router'
import { Redirect } from 'react-router'
import PropTypes from 'prop-types'
import { ConnectedRouter } from 'connected-react-router'
{{#types}}
import {{component}} from '../{{name}}/{{name}}'
{{/types}}
import { SITE_NAME } from '../Constants.js'
import Searchbar from '../common/Searchbar.js'
import LocaleSwitcher from '../common/LocaleSwitcher.js'
import PageNotFound from '../assets/PageNotFound.png';
import '../assets/app.css';

var rootPath = '/';

const App = ({ history }) => {
	return (
		<ConnectedRouter history={history}>
		<div>
		<Switch>
		{{^locales}}
		{{#types}}
		{{#first}}
		<Route exact path={rootPath} render={props =><ContentSwitcher {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}'/>} />
		{{/first}}
		<Route exact path={rootPath + '{{name}}'} render={props =><ContentSwitcher {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}'/>} />
		<Route path={rootPath + '{{name}}/search/:search'} render={props =><ContentSwitcher {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}'/>} />
		<Route path={rootPath + '{{name}}/:id'} render={props =><ContentSwitcher {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}'/>} />
		{{/types}}
		{{/locales}}
		{{#locales}}
		{{#firstLocale}}
		<Route exact path={rootPath} render={() => (<Redirect to={rootPath + '{{localeName}}/'}/> )}/>

		{{#types}}
		<Route exact path={rootPath + '{{name}}'} render={() => (<Redirect to={rootPath + '{{localeName}}/{{name}}'}/> )}/>
		<Redirect from={rootPath + '{{name}}/search/:search'} to={rootPath + '{{localeName}}/search/:search'} />
		<Redirect from={rootPath + '{{name}}/:id'} to={rootPath + '{{localeName}}/{{name}}/:id'} />
		{{/types}}
		{{/firstLocale}}	

		{{#types}}
		{{#first}}
		<Route exact path={rootPath + '{{localeName}}'} render={props =><Page{{localeCompName}} {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}' language='{{localeName}}'/>} />
		{{/first}}
		<Route exact path={rootPath + '{{localeName}}/{{name}}'} render={props =><Page{{localeCompName}} {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}' language='{{localeName}}'/>} />
		<Route path={rootPath + '{{localeName}}/{{name}}/search/:search'} render={props =><Page{{localeCompName}} {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}' language='{{localeName}}'/>} />
		<Route path={rootPath + '{{localeName}}/{{name}}/:id'} render={props =><Page{{localeCompName}} {...props} ContentComp={ {{component}} } site={SITE_NAME} contentType='{{name}}' language='{{localeName}}'/>} />
		{{/types}}
		{{/locales}}

		<Route component={NotFound} />
		</Switch>
		</div>
		</ConnectedRouter>
 	 )
}

const Header = (props) => {
	var language = props.language;
	var typePath = language ? rootPath + language + '/' : rootPath;
	if (props.match.params.search) {
		return (
			<div className="Splash">
				<div className="Header">
				{{#navtypes}}
					<a href={ typePath + '{{name}}' }>{{name}}</a> 
				{{/navtypes}}
					<div className="RightContainer">
						<LocaleSwitcher {...props}  />
					</div>
				</div>
				<h1 className="SiteName">{SITE_NAME}</h1>
			</div>
		)
	} else {
		return (
			<div className="Splash">
				<div className="Header">
				{{#navtypes}}
					<a href={ typePath + '{{name}}' }>{{name}}</a> 
				{{/navtypes}}
					<div className="RightContainer">
						<LocaleSwitcher {...props}  />
						<Searchbar {...props}  />
					</div>
				</div>
				<h1 className="SiteName">{SITE_NAME}</h1>
			</div>
		)
	}
}

class ContentSwitcher extends React.Component {
	render() {
		if (this.props.match.params.search) {
			return (
				<div className="SearchResult">
				<Header {...this.props}/>
				<Searchbar {...this.props}  />
				<this.props.ContentComp {...this.props}/>
				</div>
			);
		} else {
			return (
				<div>
				<Header {...this.props}/>
				<this.props.ContentComp {...this.props}/>
				</div>
			);
		}
	}
}

{{#locales}}
class Page{{localeCompName}} extends React.Component {
        render() {
                if (this.props.match.params.search) {
                        return (
                                <div className="SearchResult">
                                <Header {...this.props}/>
                                <Searchbar {...this.props}  />
                                <this.props.ContentComp {...this.props}/>
                                </div>
                        );
                } else {
                        return (
                                <div>
                                <Header {...this.props}/>
                                <this.props.ContentComp {...this.props}/>
                                </div>
                        );
                }
        }
}
{{/locales}}

const NotFound = () => (
<div>
<center><img src={PageNotFound}  /></center>
<center><a href={rootPath}>Return to Home Page</a></center>
</div>
);

App.propTypes = {
  history: PropTypes.object,
}

export default App
