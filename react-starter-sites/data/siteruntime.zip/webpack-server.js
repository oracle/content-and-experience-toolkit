/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console, process, __dirname */
/* jshint esversion: 6 */

const path = require('path')
const webpack = require('webpack')
const webpackDevMiddleware = require('webpack-dev-middleware')
const webpackHotMiddleware = require('webpack-hot-middleware')
const express = require('express')
const config = require('./webpack.config')
const fs = require('fs');
var request = require('request');
var cors = require('cors');

const app = express();
const compiler = webpack(config);

const webpackPort = process.env.CECSS_WEBPACK_PORT || 9090;
const nodePort = process.env.CECSS_PORT || 8080;

var projectDir = path.join(__dirname);
var sitesDir = path.join(projectDir, 'src');

const instance = webpackDevMiddleware(compiler, {
	noInfo: true,
	logLevel: "warn",
	publicPath: config.output.publicPath,
	historyApiFallback: true,
});

app.use(instance);

app.use(webpackHotMiddleware(compiler));

// allow cross-origin requests for all
app.use(cors());

// enable cookies
request = request.defaults({
	jar: true,
	proxy: null
});

app.get('/api*', (req, res) => {
	console.log('^^^ webpack API: path=' + req.url);
	var url = req.url.replace(/\/api\//, '').replace(/\/$/, ''),
		filePathSuffix = url.replace(/\/sites\//, '').replace(/\/$/, '');

	var host = req.headers && req.headers.host || 'localhost';
	if (host.indexOf(':') > 0) {
		host = host.substring(0, host.indexOf(':'));
	}
	var serverUrl = 'http://' + host + ':' + nodePort + '/' + url;
	console.log(' - server url ' + serverUrl);
	if (url.indexOf('/assets/') > 0) {
		res.redirect(serverUrl);
		res.end();
		return;
	}
	request(serverUrl, function (err, response, body) {
		var data = {};
		if (response && response.statusCode === 200) {
			if (body) {
				data = JSON.parse(body);
			}
		} else {
			console.log(' status=' + (response ? response.statusCode : '') + ' err=' + err);
		}

		res.write(JSON.stringify(data));
		res.end();
	});
})

app.get('/content/*', (req, res) => {
	console.log('^^^ webpack Content: path=' + req.url);
	var host = req.headers && req.headers.host || 'localhost';
	if (host.indexOf(':') > 0) {
		host = host.substring(0, host.indexOf(':'));
	}
	var serverUrl = 'http://' + host + ':' + nodePort + '/' + url;
	console.log(' - server url ' + serverUrl);
	if (serverUrl.indexOf('/assets/') > 0) {
		res.redirect(serverUrl);
		res.end();
		return;
	}
	request(serverUrl, function (err, response, body) {
		var data = {};
		if (response && response.statusCode === 200) {
			if (body) {
				data = JSON.parse(body);
			}
		} else {
			console.log(' status=' + (response ? response.statusCode : '') + ' err=' + err);
		}

		res.write(JSON.stringify(data));
		res.end();
	});
})

app.get('*', (req, res) => {
	console.log('^^^ webpack: path=' + req.url);

	var filePath = path.join(sitesDir, 'index.html');
	console.log(' - use filePath=' + filePath);
	if (existsAndIsFile(filePath)) {
		res.sendFile(filePath);
	} else {
		console.log('404: ' + filePath);
		res.writeHead(404, {});
		res.end();
	}
})


app.listen(webpackPort, (err) => {
	if (err) {
		return console.error(err);
	}
	console.log('Listening at http://localhost:' + webpackPort);
})

var existsAndIsFile = function (filePath) {
	var ok = false;
	if (fs.existsSync(filePath)) {
		var statInfo = fs.statSync(filePath);
		ok = statInfo && statInfo.isFile();
	}
	return ok;
};
