/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console, process, __dirname */
/* jshint esversion: 6 */

/**
 * Test SCS site.
 */

var express = require('express'),
	app = express(),
	os = require('os'),
	fs = require('fs'),
	path = require('path'),
	url = require('url'),
	argv = require('yargs').argv,
	request = require('request'),
	http = require('http'),
	cors = require('cors'),
	puppeteer = require('puppeteer'),
	serverUtils = require('./server/serverUtils.js'),
	contentRouter = require('./server/contentRouter.js');

// project root is the current dir
var projectDir = path.join(__dirname);
var sitesDir = path.join(projectDir, 'src');

// read remote CEC server config from ~/.gradle/gradle.properties
var server = serverUtils.getConfiguredServer();
console.log('Configured server=' + JSON.stringify(server));

console.log('Node env: ' + process.argv[2]);

// Store these in the app locals to be shared by routers
app.locals.nodeMode = process.argv[2] || 'production';
app.locals.server = server;
app.locals.serverURL = app.locals.server.url && app.locals.server.username && app.locals.server.password ? app.locals.server.url : '';
app.locals.connectToServer = false;

app.locals.currentSite = '';

var port = process.env.CECSS_PORT || 8080;

// allow cross-origin requests for all
app.use(cors());

// enable cookies
request = request.defaults({
	jar: true,
	proxy: null
});
app.locals.request = request;

app.use('/node_modules', express.static(path.join(projectDir, 'node_modules')));

// All /content requests are handled by contentRouter
app.get('/content*', contentRouter);
app.post('/content*', contentRouter);
app.get('/api/content*', contentRouter);
app.post('/api/content*', contentRouter);


// starter site request
app.get('*', (req, res) => {
        console.log('@@@ node: path=' + req.url);
	if (app.locals.nodeMode !== 'production') {
		console.log(' - path ' + req.url + ' not supported not support in ' + app.locals.nodeMode + ' mode');
		res.writeHead(404, {});
        	res.end();
		return;
	}

	var filePathSuffix = req.path;
	if (filePathSuffix.indexOf('/') === 0) {
		filePathSuffix = filePathSuffix.substring(1);
	}

        var filePath = path.join(sitesDir, filePathSuffix);
        if (!existsAndIsFile(filePath)) {
		console.log(' - file not exist: ' + filePath);
		filePath = path.join(sitesDir, 'index.html');
	}

        console.log(' - use filePath=' + filePath);
        if (existsAndIsFile(filePath)) {
                res.sendFile(filePath);
        } else {
                console.log('404: ' + filePath);
                res.writeHead(404, {});
                res.end();
        }
})

// Handle startup errors
process.on('uncaughtException', function (err) {
	'use strict';
	if (err.code === 'EADDRINUSE' || err.errno === 'EADDRINUSE') {
		console.log('======================================');
		console.error(`Another server is using port ${err.port}. Stop that process and try to start the server again.`);
		console.log('======================================');
	} else {
		console.error(err);
	}
});


if (!app.locals.serverURL) {
	// start the server without remote server
	app.listen(port, function () {
		"use strict";
		console.log('NodeJS running...:');
		console.log('Site page: http://localhost:' + port);
	});
} else {
	// open a user session using the given credentials
	authenticateUser(
		server.env, {
			username: server.username,
			password: server.password,
			onsuccess: function () {
				app.locals.connectToServer = true;
				var wait = server.env === 'pod_ec' ? 15000 : 1000;
				app.listen(port, function () {
					"use strict";
					setTimeout(function () {
						console.log('Server is listening on port: ' + port);
						console.log('NodeJS running...:');
						console.log('Site page: http://localhost:' + port);
					}, wait);
				});
			},
			onfailure: function (error, resp) {
				console.log('Login to server failed - unexpected response from server');
				process.exit(-1);
			}
		});
}

function authenticateUser(env, params) {
	var authFn = {
		pod: authenticateUserOnPod,
		dev: authenticateUserOnDevInstance,
		dev_ec: authenticateUserOnDevECInstance,
		pod_ec: authenticateUserOnPodEC
	};

	if (authFn[env]) {
		authFn[env].call(null, params);
	} else {
		console.log('Unknown env type: ' + env);
	}
}


function authenticateUserOnDevInstance(params) {
	// open user session
	request.post(app.locals.serverURL + '/cs/login/j_security_check', {
		form: {
			j_character_encoding: 'UTF-8',
			j_username: params.username,
			j_password: params.password
		}
	}, function (err, resp, body) {

		if (err) {
			params.onfailure.call(null, err, resp);
			return;
		}

		// we expect a 302 response
		if (resp && resp.statusCode === 302) {
			var location = app.locals.serverURL + '/adfAuthentication?login=true';

			request.get(location, function (err, response, body) {
				if (err) {
					params.onfailure.call(null, err);
					return;
				}

				console.log('Logged in to remote server: ' + app.locals.serverURL);
				params.onsuccess.apply();
			});
		} else {
			params.onfailure.call(null, resp);
		}
	});
}

function authenticateUserOnDevECInstance(params) {
	// open user session
	request.post(app.locals.serverURL + '/cs/login/j_security_check', {
		form: {
			j_character_encoding: 'UTF-8',
			j_username: params.username,
			j_password: params.password
		}
	}, function (err, resp, body) {

		if (err) {
			params.onfailure.call(null, err, resp);
			return;
		}

		// we expect a 303 response
		if (resp && resp.statusCode === 303) {
			var location = app.locals.serverURL + '/adfAuthentication?login=true';

			request.get(location, function (err, response, body) {
				if (err) {
					params.onfailure.call(null, err);
					return;
				}

				console.log('Logged in to remote server: ' + app.locals.serverURL);
				params.onsuccess.apply();
			});
		} else {
			params.onfailure.call(null, resp);
		}
	});
}

function authenticateUserOnPod(params) {
	function getFormData(resp) {
		var body = resp.body,
			regexp = /input type="hidden" name="(\w*)" value="([!-~]*)"/gi,
			match,
			formData = {
				username: params.username,
				password: params.password,
				userid: params.username,
				cloud: 'null',
				buttonAction: 'local'
			};

		while ((match = regexp.exec(body)) !== null) {
			if (match.length !== 3) {
				console.log('ignored invalid match for regexp:', match);
				continue;
			}

			formData[match[1]] = match[2];
		}

		return formData;
	}

	// open user session
	request.get(app.locals.serverURL + '/sites', function (err, resp, body) {
		if (err) {
			console.log('Unable to connect to server ' + app.locals.serverURL + '\nconnection failed with error:' + err.code);
			process.exit(-1);
		}

		// get form data for cloud login
		// we need the current response to extract a bunch of form data
		var formData = getFormData(resp);

		// get OAM server URL
		var OAM_Server_URL = 'https://' + resp.request.host + ':' + resp.request.port + '/oam/server/auth_cred_submit';

		// post form data
		request.post(OAM_Server_URL, {
			form: formData
		}, function (err, resp, body) {
			// expecting 302
			if (resp.statusCode === 302) {
				// TODO this might not be necessary
				request.get(resp.headers.location, function (err, resp, body) {
					if (err) {
						params.onfailure.apply(null, err);
						return;
					}

					console.log('Logged in to remote server: ' + app.locals.serverURL);
					params.onsuccess.apply();
				});
			} else {
				params.onfailure.apply(null, resp);
			}
		});
	});
}

function authenticateUserOnPodEC(params) {
	var url = app.locals.serverURL + '/documents',
		usernameid = '#idcs-signin-basic-signin-form-username',
		passwordid = '#idcs-signin-basic-signin-form-password',
		submitid = '#idcs-signin-basic-signin-form-submit',
		username = app.locals.server.username,
		password = app.locals.server.password;
	/* jshint ignore:start */
	async function loginServer() {
		try {
			const browser = await puppeteer.launch({
				ignoreHTTPSErrors: true,
				headless: false
			});
			const page = await browser.newPage();
			await page.setViewport({
				width: 960,
				height: 768
			});

			await page.goto(url);

			await page.waitForSelector(usernameid);
			console.log('Enter username ' + username);
			await page.type(usernameid, username);

			await page.waitForSelector(passwordid);
			console.log('Enter password');
			await page.type(passwordid, password);

			var button = await page.waitForSelector(submitid);
			console.log('Click Login');
			await button.click();

			try {
				await page.waitForSelector('#content-wrapper', {
					timeout: 8000
				});
			} catch (err) {
				// will continue, in headleass mode, after login redirect does not occur
			}

			var tokenurl = app.locals.serverURL + '/documents/web?IdcService=GET_OAUTH_TOKEN';
			console.log('Go to ' + tokenurl);
			await page.goto(tokenurl);
			try {
				await page.waitForSelector('pre');
			} catch (err) {
				console.log('Failed to connect to the server to get the OAuth token');
				await browser.close();
				params.onfailure.apply(null, null);
			}

			//await page.screenshot({path: '/tmp/puppeteer.png'});

			const result = await page.evaluate(() => document.querySelector('pre').textContent);
			var token = '';
			var status = '';
			if (result) {
				var localdata = JSON.parse(result);
				token = localdata && localdata.LocalData && localdata.LocalData.tokenValue;
				status = localdata && localdata.LocalData && localdata.LocalData.StatusCode;
			}
			// console.log(token);

			await browser.close();

			if (status && status === '0' && token) {
				app.locals.server.oauthtoken = token;
				console.log('The OAuth token recieved');
				params.onsuccess.apply();
			} else {
				console.log('Failed to get the OAuth token: status=' + status + ' token=' + token);
				params.onfailure.apply(null, null);
			}

		} catch (err) {
			console.log('ERROR!', err);
			params.onfailure.apply(null, null);
		}
	}
	loginServer();
	/* jshint ignore:end */
}

var existsAndIsFile = function (filePath) {
        var ok = false;
        if (fs.existsSync(filePath)) {
                var statInfo = fs.statSync(filePath);
                ok = statInfo && statInfo.isFile();
        }
        return ok;
};

