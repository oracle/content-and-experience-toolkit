/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global module, process */
/* jshint esversion: 6 */

/**
 * Utilities for Local Server
 */

var express = require('express'),
	app = express(),
	os = require('os'),
	fs = require('fs'),
	path = require('path'),
	puppeteer = require('puppeteer');

var projectDir = path.join(__dirname, '../');


/**
 * Get server and credentials from gradle properties
 */
module.exports.getConfiguredServer = function () {
	var server = _getConfiguredServer(path.join(projectDir, '.cec_properties'));
	return server;

	// var configFile = process.env.CEC_PROPERTIES || path.join(os.homedir(), '.cec_properties');
	// return _getConfiguredServer(configFile);
};
var _getConfiguredServer = function (configFile) {
	console.log('CEC configure file: ' + configFile);
	var server = {
		url: '',
		username: '',
		password: '',
		oauthtoken: '',
		env: '',
		content: 'local',
		contentStatus: '',
		channelToken: ''
	};
	if (!fs.existsSync(configFile)) {
		console.log(' - file ' + configFile + ' does not exist');
		return server;
	}
	try {
		var cecurl,
			username,
			password,
			env,
			content,
			contentStatus,
			channelToken;
		fs.readFileSync(configFile).toString().split('\n').forEach(function (line) {
			if (line.indexOf('cec_url=') === 0) {
				cecurl = line.substring('cec_url='.length);
				cecurl = cecurl.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_username=') === 0) {
				username = line.substring('cec_username='.length);
				username = username.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_password=') === 0) {
				password = line.substring('cec_password='.length);
				password = password.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_env=') === 0) {
				env = line.substring('cec_env='.length);
				env = env.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_content=') === 0) {
				content = line.substring('cec_content='.length);
				content = content.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_content_status=') === 0) {
				contentStatus = line.substring('cec_content_status='.length);
				contentStatus = contentStatus.replace(/(\r\n|\n|\r)/gm, '').trim();
			} else if (line.indexOf('cec_channel_token=') === 0) {
				channelToken = line.substring('cec_channel_token='.length);
				channelToken = channelToken.replace(/(\r\n|\n|\r)/gm, '').trim();
			}
		});
		server.url = cecurl;
		server.username = username || server.username;
		server.password = password || server.password;
		server.env = env || 'pod_ec';
		server.oauthtoken = '';
		server.content = content || server.content;
		server.contentStatus = contentStatus || server.contentStatus;
		server.channelToken = channelToken;
		// console.log('configured server=' + JSON.stringify(server));
	} catch (e) {
		console.log('Failed to read config: ' + e);
	}
	return server;
};


/**
 * Utility check if a string ends with 
 */
module.exports.endsWith = (str, end) => {
	return str.lastIndexOf(end) === str.length - end.length;
};

/**
 * Utility replace all occurrences of a string
 */
module.exports.replaceAll = (str, search, replacement) => {
	var re = new RegExp(search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
	return str.replace(re, replacement || '');
};

module.exports.fixHeaders = (origResponse, response) => {
	_fixHeaders(origResponse, response);
};
var _fixHeaders = function (origResponse, response) {
	var headers = origResponse.rawHeaders, // array [name1, value1, name2, value2, ...]
		i = 0,
		headerNames = [],
		headerName;

	for (i = 0; i < headers.length; i = i + 2) {
		headerName = headers[i];
		// collect header name
		headerNames.push(headerName);

		// regarding capitalization, we're only taking care of SCS 'ETag-something' headers
		if (headerName.indexOf('ETag-') === 0) {
			// remove the corresponding lower case header from the proxied response object
			// (it otherwise takes precedence when piped to the actual response)
			delete origResponse.headers[headerName.toLowerCase()];
			// set the capitalized header name in the new response object
			response.setHeader(headerName, headers[i + 1]);
		}
	}

	// explicitly declare headers for cross-domain requests
	response.setHeader('Access-Control-Expose-Headers', headerNames.join(','));
};

module.exports.getURLParameters = function (queryString) {
	var params = {};

	if (!queryString || queryString.indexOf('=') < 0) {
		console.log(' queryString ' + queryString + ' is empty or not valid');
		return params;
	}
	parts = queryString.split('&');
	for (var i = 0; i < parts.length; i++) {
		var nameval = parts[i].split('='),
			name = nameval[0],
			val = nameval[1] || '';
		params[name] = decodeURIComponent(val);
	}
	// console.log(params);
	return params;
};
