/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console,  __dirname */
/* jshint esversion: 6 */

const path = require("path");
const webpack = require('webpack');
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CleanWebpackPlugin = require("clean-webpack-plugin");

const outputDirectory = "src";
const projectDir = path.join(__dirname);

module.exports = {
	entry: {
                app: ['event-source-polyfill', 'webpack-hot-middleware/client?reload=true&noInfo=true', path.resolve('./src/index.js')]
        },
	output: {
		path: path.join(projectDir, outputDirectory),
		filename: "bundle.js",
		publicPath: '/',
	},
	mode: 'development',
	module: {
		rules: [{
				test: /\.js$/,
				exclude: /node_modules/,
				use: {
					loader: "babel-loader"
				}
			},
			{
				test: /\.css$/,
				use: ["style-loader", "css-loader"]
			},
			{
				test: /\.(png|woff|woff2|eot|ttf|svg|jpg)$/,
				loader: "url-loader?limit=100000"
			}
		]
	},
	
	plugins: [
		new HtmlWebpackPlugin({
			template: path.resolve("./src/index.html")
		  }),
		new webpack.HotModuleReplacementPlugin(),
                new webpack.NoEmitOnErrorsPlugin()
	]
};
