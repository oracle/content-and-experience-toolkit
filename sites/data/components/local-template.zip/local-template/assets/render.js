/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 * This unpublished work by Oracle is protected by the laws
 * of the United States and other countries. If publication
 * of this computer program should occur, the following notice
 * shall apply:
 *
 * @preserve Copyright (c) 2015, 2021, Oracle and/or its affiliates.
 */

define([
	'jquery',
	'mustache',
	'./common',
	'text!./template.html',
	'css!./styles/design.css'
], function ($, Mustache, common, sampleComponentTemplate, css) {
	'use strict';

	var SitesSDK;
	var SampleComponentImpl = function (args) {
		// store the args
		this.mode = args.viewMode;
		this.id = args.id;
		SitesSDK = args.SitesSDK;

		// add in the event listeners
		this.addEventListeners();
	};

	// add in the listeners for the triggers/actions and whenever the settings values change
	// in this case, we want to re-render the component on the screen
	SampleComponentImpl.prototype.addEventListeners = function () {
		var self = this;

		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, function (props) {
			if (props.property === 'customSettingsData') {
				self.renderComponent({
					customSettingsData: props.value
				});
			} else if (props.property === 'componentLayout') {
				self.renderComponent({
					componentLayout: props.value
				});
			}
		});

		// listen for actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;

			// handle 'setImageWidth' actions
			if (action && action.actionName === 'setImageWidth') {
				$.each(payload, function (index, data) {
					if (data.name === 'imageWidth') {
						self.renderComponent({
							imageWidth: data.value
						});
					}
				});
			}
		});
	};

	// inserts the component's HTML into the page 
	// after it has added the component, it applies any clickHandlers to elements that were added to the page
	SampleComponentImpl.prototype.renderComponent = function (args) {

		// use the common code to generate the HTML for this component based on the componentLayout and customSettingsData
		var componentHTML = common.createHTML({
			Mustache: Mustache,
			componentLayout: SitesSDK.getProperty('componentLayout'),
			customSettingsData: SitesSDK.getProperty('customSettingsData'),
			id: this.id,
			template: sampleComponentTemplate
		}, args);

		// replace the content of the container with the rendered HTML
		this.$container.html(componentHTML);

		// add in the click handlers
		this.addClickHandlers(this.$container);
	};

	SampleComponentImpl.prototype.addClickHandlers = function (container) {
		var self = this;

		// Raise the given trigger.
		self.raiseTrigger = function (triggerName) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'payloadData': 'some data here'
				}
			});
		};
		$('#image' + self.id).on('click', function (data, event) {
			self.raiseTrigger("imageClicked"); // matches appinfo.json
		});
	};

	// the hydrate function is called when a component has been compiled into the page at runtime 
	// this gives the opportunity to add any event handlers to the HTML that has been inserted into the page
	SampleComponentImpl.prototype.hydrate = function (container) {
		this.$container = $(container);
		this.addClickHandlers(container);
	};

	// the render function is called to render the component dynamically onto the page 
	SampleComponentImpl.prototype.render = function (container) {
		this.$container = $(container);
		this.renderComponent();
	};

	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var sampleComponentFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new SampleComponentImpl(args));
		}
	};
	return sampleComponentFactory;
});