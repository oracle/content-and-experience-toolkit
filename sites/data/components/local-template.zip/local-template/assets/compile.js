/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 * This unpublished work by Oracle is protected by the laws
 * of the United States and other countries. If publication
 * of this computer program should occur, the following notice
 * shall apply:
 *
 * @preserve Copyright (c) 2015, 2021, Oracle and/or its affiliates.
 */

var fs = require('fs'),
    path = require('path'),
    common = require('./common'),
    Mustache = require('mustache');


// create an object to compile the component
var SampleComponentImpl = function (args) {
    this.componentId = args.componentId;
    this.componentInstanceObject = args.componentInstanceObject;
    this.componentsFolder = args.componentsFolder;
    this.SCSCompileAPI = args.SCSCompileAPI;

    this.compData = this.componentInstanceObject.data;
};

// implement the compile() API to generate the HTML for the component
SampleComponentImpl.prototype.compile = function (args) {
    var self = this;
    return new Promise(function (resolve, reject) {
        try {
            // load up the template file
            var dir = __dirname,
                templateFile = path.join(dir, 'template.html'),
                template = fs.readFileSync(templateFile, 'utf8');


            // use the common code to generate the HTML for this component based on the componentLayout and customSettingsData
            var componentHTML = common.createHTML({
                Mustache: Mustache,
                componentLayout: self.compData.componentLayout,
                customSettingsData: self.compData.customSettingsData,
                id: self.componentId,
                template: template
            });

            // It is up to the developer to ensure the output from the compile.js:compile() function remains in sync with the render.js:render() function.
            // To see what the default output would be, switch the following to true
            if (false) {
                // return the generated HTML and use hydrate in the render.js file to add any event handlers at runtime
                return resolve({
                    hydrate: true,
                    content: componentHTML
                });
            } else {
                // warn the user that the compile function hasn't been implemented
                console.log('Warning: custom compile() function has not been implemented in: ' + __filename);

                // If the compile() function doesn't return any content, then the component will execute dynamically at runtime
                return resolve({});
            }
        } catch (e) {
            console.log('Error: Failed to expand mustache template in: ' + __filename, e);
            return resolve({});
        }
    });
};


module.exports = SampleComponentImpl;