/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 * This unpublished work by Oracle is protected by the laws
 * of the United States and other countries. If publication
 * of this computer program should occur, the following notice
 * shall apply:
 *
 * @preserve Copyright (c) 2021, Oracle and/or its affiliates.
 */

(function defineSampleComponent(scope, factory) {
	// configure to run in various JS environments
	if (typeof define === 'function' && define.amd) {
		// RequireJS, pass in the factory and use the 'exports' empty object
		define(['exports'], factory);
	} else if (typeof exports === 'object' && exports && typeof exports.nodeName !== 'string') {
		// NodeJS (CommonJS), pass in the exports object and populate it
		factory(exports);
	} else {
		// Standard JS - add the contentSDK object to scope and populate it
		scope.contentSDK = {};
		factory(scope.contentSDK);
	}
}(this, function sampleComponentFactory(sampleComponent) {
	'use strict';

	// create a generic function to generate the HTML that can be used when the component
	// is both rendered dynamically in the builder or the component is compiled into the page at runtime
	sampleComponent.createHTML = function (context, args) {
		// extract all the required parameters from the context
		var Mustache = context.Mustache,
			componentLayout = context.componentLayout,
			customSettingsData = context.customSettingsData,
			id = context.id,
			template = context.template;

		// apply overrides from the optional "args" values
		var layout = (args && args.componentLayout) || componentLayout || 'default',
			imageWidth = (args && args.imageWidth) || '',
			customData = (args && args.customSettingsData) || customSettingsData || {};
		customData.nls = customData.nls || {};

		// create the model
		var model = {
			imageId: 'image' + id,
			linkURL: customData.linkURL || '',
			linkText: customData.nls.linkText || '',
			titleText: customData.nls.titleText || 'Template Component',
			paragraphText: customData.nls.paragraphText || '',
			layout: layout,
			alignImageRight: layout === 'right',
			showTopLayout: layout === 'top',
			showStoryLayout: (layout === 'default' || layout === 'right')
		};

		// set imageWidth if not showing image above text
		if (!model.showTopLayout) {
			model.imageWidth = imageWidth || (customData.hasOwnProperty('width') ? customData.width : customData.width || '200px');
		}

		// Style on left- or right-aligned image
		var imageStyle = function () {
			var style;
			if (model.showTopLayout) {
				style = '';
			} else {
				style = 'flex-shrink:0;width:' + model.imageWidth + ';';
			}
			return style;
		};
		model.imageStyle = imageStyle();

		// Style around paragraph component
		var paragraphStyle = function () {
			var style;
			if (model.showTopLayout) {
				style = '';
			} else {
				style = 'flex-grow:1;';
			}
			return style;
		};
		model.paragraphStyle = paragraphStyle();

		// render the component
		try {
			return Mustache.render(template, model);
		} catch (e) {
			console.log('Failed to expand Mustache template.', e);
			return '';
		}
	};

	return sampleComponent;
}));