/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global require,requirejs,baseTagObj,SitesSDK,alert,define,oj*/
/*jslint plusplus: true */
define(['jquery', 'knockout', 'ojL10n!nls/CommonResources', 'app-utils', 'settings-dependencies'], function ($, ko, strings, appUtils) {
	'use strict';
	var settingsViewModel,
		MyViewModel = function () {
			var self = this;
			self.strings = strings;
			self.initialized = ko.observable(false);
			self.saveData = false;

			// By default, no task number is selected. Watermark is displayed.
			self.taskNumber = ko.observable('');
			self.showActions = ko.observable(true);
			self.showSave = ko.observable(true);
			self.showAttachment = ko.observable(true);
			self.showComments = ko.observable(true);
			self.showHistory = ko.observable(true);
			self.showMoreInfo = ko.observable(true);
			self.showLinks = ko.observable(true);

			// handle initialization of the viewModel
			self.init = function (customData) {

				self.config = {
					taskNumber: customData.hasOwnProperty('taskNumber') ? customData.taskNumber : '',
					showActions: customData.hasOwnProperty('showActions') ? customData.showActions : true,
					showSave: customData.hasOwnProperty('showSave') ? customData.showSave : true,
					showAttachment: customData.hasOwnProperty('showAttachment') ? customData.showAttachment : true,
					showComments: customData.hasOwnProperty('showComments') ? customData.showComments : true,
					showHistory: customData.hasOwnProperty('showHistory') ? customData.showHistory : true,
					showMoreInfo: customData.hasOwnProperty('showMoreInfo') ? customData.showMoreInfo : true,
					showLinks: customData.hasOwnProperty('showLinks') ? customData.showLinks : true
				};

				self.taskNumber(self.config.taskNumber);
				self.showActions(self.config.showActions);
				self.showSave(self.config.showSave);
				self.showAttachment(self.config.showAttachment);
				self.showComments(self.config.showComments);
				self.showHistory(self.config.showHistory);
				self.showMoreInfo(self.config.showMoreInfo);
				self.showLinks(self.config.showLinks);

				// now viewModel has been initialized
				self.initialized(true);
				self.saveData = true;
			};

			self.save = ko.computed(function () {
				//save
				var saveconfig = {
					'taskNumber': self.taskNumber(),
					'showActions': self.showActions(),
					'showSave': self.showSave(),
					'showAttachment': self.showAttachment(),
					'showComments': self.showComments(),
					'showHistory': self.showHistory(),
					'showMoreInfo': self.showMoreInfo(),
					'showLinks': self.showLinks()
				};


				//dispatch config to app
				if (self.saveData) {
					// Save the assets and settings
					// Assets are managed by the framework and
					// settings are managed by the apps.
					SitesSDK.setProperty('componentAssets', self.assets);
					SitesSDK.setProperty('customSettingsData', saveconfig);
				}
			});

			SitesSDK.getProperty('componentAssets', function (assets) {
				// Assets should be obtained before customSettings.
				self.assets = assets;
				if (assets.length > 0) {
					// console.log("Hybrid link to be read is (source): " + assets[0].source);
				}
				// get the customSettings Data and init the viewModel
				SitesSDK.getProperty('customSettingsData', self.init);
			});

		};

	settingsViewModel = new MyViewModel();

	// Return the module
	return settingsViewModel;
});
