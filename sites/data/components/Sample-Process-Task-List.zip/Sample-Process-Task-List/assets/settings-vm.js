/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global SitesSDK,define,oj,SitesPCSUtils*/
/*jslint plusplus: true */
define([
	'jquery',
	'knockout',
	'ojL10n!nls/CommonResources',
	'app-utils',
	'js/IdentityController',
	'ojs/ojarraydataprovider',
	'ojs/ojconverter-datetime',
	'settings-dependencies',
	'js/ojidentity'
], function ($, ko, strings, appUtils, IdentityController, ArrayDataProvider, converterDatetime) {
	'use strict';

	var settingsViewModel,
		MyViewModel = function () {
			var self = this;
			self.strings = strings;
			self.initialized = ko.observable(false);
			self.saveData = false;


			//number of pages displayed
			self.pageSize = ko.observable(10);
			//the min value of the files displayed
			self.minPageSize = ko.observable(1);
			self.maxPageSize = ko.observable(100);
			self.stepPageSize = ko.observable(1);

			self.showDetails = ko.observable(false);
			self.showSearch = ko.observable(false);
			self.showFilter = ko.observable(false);
			self.showSelectAll = ko.observable(false);

			self.status = ko.observable('ASSIGNED');
			self.statusValues = ko.observableArray([{
				value: 'ASSIGNED',
				label: strings.APP_PCS_TASK_LIST_STATUS_ASSIGNED
			},
			{
				value: 'INFO_REQUESTED',
				label: strings.APP_PCS_TASK_LIST_STATUS_INFO_REQUESTED
			},
			{
				value: 'WITHDRAWN',
				label: strings.APP_PCS_TASK_LIST_STATUS_WITHDRAWN
			},
			{
				value: 'SUSPENDED',
				label: strings.APP_PCS_TASK_LIST_STATUS_SUSPENDED
			},
			{
				value: 'ALERTED',
				label: strings.APP_PCS_TASK_LIST_STATUS_ALERTED
			},
			{
				value: 'ERRORED',
				label: strings.APP_PCS_TASK_LIST_STATUS_ERRORED
			},
			{
				value: 'EXPIRED',
				label: strings.APP_PCS_TASK_LIST_STATUS_EXPIRED
			},
			{
				value: 'COMPLETED',
				label: strings.APP_PCS_TASK_LIST_STATUS_COMPLETED
			}
			]);
			self.statusValuesDP = new ArrayDataProvider(self.statusValues, {
				keyAttributes: 'value'
			});

			self.assignee = ko.observable('MY_AND_GROUP_ALL');
			self.assigneeValues = ko.observableArray([{
				value: 'MY',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_MY
			},
			{
				value: 'MY_AND_GROUP',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_MY_AND_GROUP
			},
			{
				value: 'MY_AND_GROUP_ALL',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_MY_AND_GROUP_ALL
			},
			{
				value: 'CREATOR',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_CREATOR
			},
			{
				value: 'REPORTEES',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_REPORTEES
			},
			{
				value: 'REVIEWER',
				label: strings.APP_PCS_TASK_LIST_ASSIGNEE_REVIEWER
			}
			]);
			self.assigneeValuesDP = new ArrayDataProvider(self.assigneeValues, {
				keyAttributes: 'value'
			});

			self.application = ko.observableArray([]);
			self.processValues = ko.observableArray([]);
			// if application was stored as string, convert to array
			self.applicationWrapper = ko.computed({
				read: function () {
					var application = this.application();
					return (typeof application === 'string') ? [application] : application;
				},
				write: function (value) {
					this.application(value);
				},
				owner: self
			});

			self.userValues = ko.observableArray([]);
			self.keyword = ko.observable('');

			self.fromdate = ko.observable();
			self.todate = ko.observable();
			self.dateConverter = ko.observable(new converterDatetime.IntlDateTimeConverter({
				pattern: "MM/dd/yy"
			}));

			self.duedateOption = ko.observable('on');
			self.duedateOptions = ko.observableArray([{
				value: 'on',
				label: strings.APP_PCS_TASK_LIST_DUEDAY_ON
			},
			{
				value: 'before',
				label: strings.APP_PCS_TASK_LIST_DUEDAY_BEFORE
			},
			{
				value: 'after',
				label: strings.APP_PCS_TASK_LIST_DUEDAY_AFTER
			},
			{
				value: 'between',
				label: strings.APP_PCS_TASK_LIST_DUEDAY_BETWEEN
			}
			]);
			self.duedateOptionsDP = new ArrayDataProvider(self.duedateOptions, {
				keyAttributes: 'value'
			});

			self.showFromdate = ko.computed(function () {
				return self.duedateOption() !== 'before';
			}, self);

			self.showTodate = ko.computed(function () {
				if (self.duedateOption() === 'on' || self.duedateOption() === 'after') {
					return false;
				}
				return true;
			}, self);

			//controller and users used for ojidentity pcs custom components to display pcs users
			self._controller = new IdentityController();

			self.users = ko.observableArray([]);

			self.users.subscribe(function (value) {
				self._controller.setSelectedIdentities(value);
			});

			self.showSearch.subscribe(function (value) {
				if (!value) {
					self.showFilter(false);
				}
			});

			// handle initialization of the viewModel
			self.init = function (customData) {

				self.config = {
					pageSize: customData.hasOwnProperty('pageSize') ? customData.pageSize : 10,
					showDetails: customData.hasOwnProperty('showDetails') ? customData.showDetails : false,
					showSearch: customData.hasOwnProperty('showSearch') ? customData.showSearch : false,
					showFilter: customData.hasOwnProperty('showFilter') ? customData.showFilter : false,
					showSelectAll: customData.hasOwnProperty('showSelectAll') ? customData.showSelectAll : false,
					status: customData.hasOwnProperty('status') ? customData.status : 'ASSIGNED',
					assignee: customData.hasOwnProperty('assignee') ? customData.assignee : 'MY_AND_GROUP_ALL',
					application: customData.hasOwnProperty('application') ? customData.application : '',
					keyword: customData.hasOwnProperty('keyword') ? customData.keyword : '',
					duedateOption: customData.hasOwnProperty('duedateOption') ? customData.duedateOption : 'on',
					fromdate: customData.hasOwnProperty('fromdate') ? customData.fromdate : '',
					todate: customData.hasOwnProperty('todate') ? customData.todate : '',
					users: customData.hasOwnProperty('users') ? customData.users : []
				};

				self.pageSize(self.config.pageSize);
				self.showDetails(self.config.showDetails);
				self.showSearch(self.config.showSearch);
				self.showFilter(self.config.showFilter);
				self.showSelectAll(self.config.showSelectAll);
				self.status(self.config.status);
				self.assignee(self.config.assignee);
				self.application(self.config.application);
				self.keyword(self.config.keyword);
				self.duedateOption(self.config.duedateOption);
				self.fromdate(self.config.fromdate);
				self.todate(self.config.todate);
				self.users(self.config.users);

				self.serverURL = ko.observable(self.getPCSServerUrl());
				self.token = ko.observable('');

				self.isECPCS = false;
				if (self.serverURL()) {
					self.getToken(self.serverURL());
				}

				//get pcs users, called each time user type something in the search from user input
				self.getIdentities = function (params) {
					return self._controller.restCall(params, self.serverURL(), self.token());
				};

				// now viewModel has been initialized
				self.initialized(true);
				self.saveData = true;
			};

			// Auto save when a property changes
			self.save = ko.computed(function () {
				//save
				var saveconfig = {
					'pageSize': self.pageSize(),
					'showDetails': self.showDetails(),
					'showSearch': self.showSearch(),
					'showFilter': self.showFilter(),
					'showSelectAll': self.showSelectAll(),
					'status': self.status(),
					'assignee': self.assignee(),
					'application': self.application(),
					'keyword': self.keyword(),
					'duedateOption': self.duedateOption(),
					'fromdate': self.fromdate(),
					'todate': self.todate(),
					'users': self.users()
				};


				//dispatch config to app
				if (self.saveData) {
					// Save the assets and settings
					// Assets are managed by the framework and
					// settings are managed by the apps.
					SitesSDK.setProperty('componentAssets', self.assets);
					SitesSDK.setProperty('customSettingsData', saveconfig);
				}
			});


			SitesSDK.getProperty('componentAssets', function (assets) {
				// Assets should be obtained before customSettings.
				self.assets = assets;
				if (assets.length > 0) {
					// console.log("Hybrid link to be read is (source): " + assets[0].source);
				}
				// get the customSettings Data and init the viewModel
				SitesSDK.getProperty('customSettingsData', self.init);
			});

			//if the due date selection is "on", the todate data should be set the same as fromdate
			self.fromdate.subscribe(function (newValue) {
				if (self.duedateOption() === 'on') {
					self.todate(newValue);
				}
			});

			// get PCS server URL
			self.getPCSServerUrl = function () {
				var serverUrl = '',
					enabled = '',
					endpointUrl = '/pxysvc/api/1.0/endpoint',
					docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=PCS',
					appInfo,
					i,
					start = 0;

				// get server url from docs Admin first
				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': docsConfigUrl,
					async: false,
					'success': function (data) {
						// console.log('docsConfigUrl=' + docsConfigUrl + ' data=' + JSON.stringify(data));
						appInfo = data.ResultSets.AFApplicationInfo;
						if (appInfo) {
							for (i = 0; i < appInfo.fields.length; i++) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}

								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
					},
					'error': function (xhr, status, err) {
						console.log('getPCSServerUrl: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
					}
				});

				if (!serverUrl) {
					// get server url from proxy server
					$.ajax({
						'type': 'GET',
						'dataType': 'json',
						'url': endpointUrl,
						async: false,
						'success': function (data) {
							// console.log('endpoints=' + JSON.stringify(data));
							if (data && data.length > 0) {
								for (i = 0; i < data.length; i++) {
									if (data[i].pathName.toLowerCase().indexOf('pcs') >= 0 && data[i].keywords.toLowerCase().indexOf('pcs') >= 0 && data[i].enabled === true) {
										serverUrl = data[i].targetUri;
										break;
									}
								}
							}
						},
						'error': function (xhr, status, err) {
							console.error('getPCSServerUrl: url=' + endpointUrl + ' status: ' + status + ' error: ' + err);
						}
					});
				}

				if (serverUrl) {
					self.isECPCS = serverUrl.indexOf('/ic/') >= 0;

					if (serverUrl.indexOf('//') >= 0) {
						start = serverUrl.indexOf('//') + 2;
					}
					if (serverUrl.indexOf('/', start) > 0) {
						// remove everything after /
						serverUrl = serverUrl.slice(0, serverUrl.indexOf('/', start));
					}
				}
				console.log('PCS server: ' + serverUrl + ' isEC: ' + self.isECPCS);
				return serverUrl;
			};

			self.getToken = function (serverURL) {
				var token;

				SitesPCSUtils.getAuthToken({
					'serverURL': serverURL,
					'successCallback': function (data) {
						token = data;
						self.getProcesses(serverURL, token);
						self.token(token);
					},
					'errorCallback': function (xhr, status, err) {
						console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
						// failed but try to get the processes in any case
						self.getProcesses(serverURL);
					}
				});
			};

			// REST call to get processes, this is used for the list of applications for filter options
			self.getProcesses = function (serverUrl, authToken) {
				var token,
					processUrl = serverUrl + (self.isECPCS ? "/ic/api/process/v1/process-definitions" : "/bpm/api/4.0/process-definitions"),
					i,
					buffer = [],
					obj,
					item;

				// auth token only available on POD 
				token = authToken ? 'Bearer ' + authToken : "Basic " + btoa("bpmqaadmin:welcome1");

				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': processUrl,
					beforeSend: function (xhr) {
						xhr.setRequestHeader('Authorization', token);
					},
					xhrFields: {
						withCredentials: true
					},
					'success': function (data) {
						if (data.items) {
							for (i = 0; i < data.items.length; i++) {
								item = data.items[i];
								buffer.push({
									value: item.processName,
									label: item.processName
								});
							}
							self.processValues(buffer);
							//console.log('processes=' + JSON.stringify(self.processValues()));

						} else {
							console.info('no process found');
						}
					},
					'error': function (xhr, status, err) {
						console.error('process-definitions: xhr: ' + xhr + ' status: ' + status + ' error: ' + err);
					}
				});


			};
		};

	settingsViewModel = new MyViewModel();

	// Return the module
	return settingsViewModel;
});