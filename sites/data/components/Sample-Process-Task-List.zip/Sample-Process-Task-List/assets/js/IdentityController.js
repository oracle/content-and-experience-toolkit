/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define(['js/Identity', 'js/Identities'], function (Identity, Identities) {

	function IdentityController() {
		this._identities = new Identities();
	}

	IdentityController.prototype = {
		getIdentity: function (index) {
			this._identities.getIdentities[index];
		},

		setIdentities: function (identities) {
			this._identities.setIdentities(this.parseIdentity(identities));
		},

		getIdentities: function () {
			return [].concat(this._identities.getIdentities());
		},

		setSelectedIdentities: function (identities) {
			this._identities.setSelectedIdentities(this.parseIdentity(identities));
		},

		getSelectedIdentities: function () {
			return this._identities.getSelectedIdentities();
		},

		parseIdentity: function (identities) {
			var _identities = [];
			if (identities && Array.isArray(identities)) {
				for (var i = 0, len = identities.length; i < len; i++) {
					_identities.push(new Identity(identities[i]));
				}
			}

			return _identities;
		},
		restCall: function (params, serverUrl, authToken) {
			var _this = this,
				// auth token only available on POD 
				token = authToken ? 'Bearer ' + authToken : "Basic " + btoa("bpmqaadmin:welcome1");
			return new Promise(function (fulfill, reject) {
				jQuery.ajax({
					url: serverUrl + '/bpm/api/3.0/identities',
					type: 'GET',
					data: params,
					beforeSend: function (xhr) {
						xhr.setRequestHeader("content-type", "application/json; charset=utf-8");
						xhr.setRequestHeader("Authorization", token);
					},
					success: function (response) {
						_this.setIdentities(response.items || []);
						fulfill(_this.getIdentities());
					},
					error: function (response) {
						//return the cache
						reject("Failed to get the data from REST API");
					}
				});

			});
		}

	};

	return IdentityController;


});
