/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console, process, __dirname*/
var gulp = require('gulp'),
	requirejs = require('requirejs'),
	replace = require('gulp-replace'),
	path = require('path');

var folders = __dirname.split(path.sep),
	componentName = folders[folders.length-1];

var requirejsOptimizeConfigSettings = {
	baseUrl: 'assets',
	mainConfigFile: 'assets/settings-main.js',
	name: 'settings-main',
	out: '../../../build/components/' + componentName + '/assets/settings-main.js',
	optimizeCss: 'standard.keepLines.keepWhitespace',
	include: ["ojtranslations/nls/en/localeElements"],
	uglify2: {
		output: {
			"max_line_len": false
		}
	}
};

gulp.task('optimizeSettings', function(done) {
	"use strict";
	return requirejs.optimize(requirejsOptimizeConfigSettings, function(buildResponse) {
		// console.log('Settings: Optimized the following files:');
		// console.log(buildResponse);
		// replace the alta resource paths
		return gulp.src('../../../build/components/' + componentName + '/assets/settings-main.js', { base: "./" }).
		pipe(replace(
			'../../../node_modules/oraclejet/dist/css/alta', './alta'
		)).pipe(gulp.dest('./'))
		.on("end", done);
	}, function(err) {
		// Exit with non zero status if there is an error
		console.log('Error optimizing...');
		console.log(err);
		process.exit(1);
	});
});

gulp.task('default', gulp.parallel('optimizeSettings', function(done) {
	"use strict";
	done();
}));
