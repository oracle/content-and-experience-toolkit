/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global require,requirejs,baseTagObj,SitesSDK,define,oj,console,btoa,SitesPCSUtils*/
/*jslint plusplus: true */
define(['jquery', 'knockout', 'ojL10n!nls/CommonResources', 'ojs/ojasyncvalidator-regexp', 'ojs/ojvalidation-number', 'settings-dependencies'],
	function ($, ko, strings, AsyncRegExpValidator) {
		'use strict';

		var
			settingsViewModel,
			usedNames = [],
			noSelection = 'noselection',
			proxyServicePathPrefix = '/pxysvc/proxy/',
			processRevisionRegEx = /\!([0-9,\.]+)\~/,
			noselectionObj = {
				value: 'noselection',
				label: strings.APP_STARTFORM_DEFAULT_SELECTION
			},
			processesData = [],
			formsData = [];

		var MyViewModel = function () {
			var self = this;

			var nlsProperties = ['formName', 'submitButton', 'submitConfirmation'];

			self.strings = strings;
			self.initialized = ko.observable(false);
			self.saveData = ko.observable(false);

			self.errorMessage = ko.observable('');

			// The default is Production
			self.deployType = ko.observable(1);
			self.processDefId = ko.observable('noselection');
			self.operation = ko.observable('start');
			self.processes = ko.observableArray([]);

			self.allowAddData = ko.observable(true);
			self.data = ko.observableArray([]);

			self.messages = ko.observableArray(['Name should be unique']);

			self.deployValues = ko.observableArray([{
					value: 'production',
					label: strings.APP_STARTFORM_DEPLOY_PRODUCTION
				},
				{
					value: 'test',
					label: strings.APP_STARTFORM_DEPLOY_TEST
				}
			]);
			self.deployValue = ko.computed({
				read: function () {
					return [self.deployType() === 1 ? 'production' : 'test'];
				},
				write: function (value) {
					self.deployType(value[0] === 'production' ? 1 : 0);
					// requery after deploy partition changes
					self.processDefId('noselection');
					if (self.serverURL() && !self.useProxyService()) {
						self.getToken(self.serverURL());
					}
					self.saveData(true);
				},
				owner: self
			});

			// Handle process selection
			self.processeValues = ko.observableArray([]);
			self.processValue = ko.computed({
				read: function () {
					return [self.processDefId()];
				},
				write: function (value) {
					self.processDefId(value[0]);
					self.updateForms(processesData);
					// after select process, clear form selection
					self.formValue(['noselection']);
				},
				owner: self
			});

			// Handle form selection
			self.formsValues = ko.observableArray([]);
			self.formValue = ko.computed({
				read: function () {
					return [self.processDefId() === 'noselection' ? self.processDefId() : self.processDefId() + ':' + self.operation()];
				},
				write: function (value) {
					var values = value[0].split(':');
					self.operation(values[1]);
					// reset data
					self.data([]);
					self.saveData(true);
				},
				owner: self
			});

			// TODO: Flag for CCS-50548. Default is on in Sample-Process-Start-Form.
			self.showProxies = true;
			self.proxyPathName = ko.observable('');
			self.useProxyService = function () {
				return self.showProxies && self.proxyPathName();
			};
			self.proxies = ko.observableArray([]);
			self.proxyValue = ko.computed({
				read: function () {
					return [self.proxyPathName() === '' ? noSelection : self.proxyPathName()];
				},
				write: function (value) {
					if (value[0] === noSelection) {
						self.proxyPathName('');
					} else {
						self.proxyPathName(value[0]);
					}
					// Depending on whether proxy service is used or not:
					// - serveURL is set accordingly
					// - bypass auth check if true
					if (self.proxyPathName()) {
						self.serverURL(proxyServicePathPrefix + self.proxyPathName());
						self.getProcesses(self.serverURL());
					} else {
						self.serverURL(self.getPCSServerUrl());
						if (self.serverURL()) {
							self.getToken(self.serverURL());
						}
					}
				},
				owner: self
			});

			// handle initialization of the viewModel
			self.init = function (customData) {
				// handle 'nls' data
				if (customData && customData.nls) {
					// promote the NLS properties to the base object for backwards compatibility
					nlsProperties.forEach(function (nlsProp) {
						customData[nlsProp] = customData.nls[nlsProp] || customData[nlsProp];
					});
				}

				var i,
					validData = [];

				self.config = {
					proxyPathName: customData.hasOwnProperty('proxyPathName') ? customData.proxyPathName : '',
					deployType: customData.hasOwnProperty('deployType') ? customData.deployType : 1,
					useDefaultProcessVersion: customData.hasOwnProperty('useDefaultProcessVersion') ? customData.useDefaultProcessVersion : false,
					processDefId: customData.hasOwnProperty('processDefId') ? customData.processDefId : 'noselection',
					operation: customData.hasOwnProperty('operation') ? customData.operation : 'start',
					formName: customData.hasOwnProperty('formName') ? customData.formName : '',
					submitButton: customData.hasOwnProperty('submitButton') ? customData.submitButton : '',
					showSubmit: customData.hasOwnProperty('showSubmit') ? customData.showSubmit : true,
					showSubmitConfirmation: customData.hasOwnProperty('showSubmitConfirmation') ? customData.showSubmitConfirmation : true,
					showSave: customData.hasOwnProperty('showSave') ? customData.showSave : false,
					showDiscard: customData.hasOwnProperty('showDiscard') ? customData.showDiscard : false,
					showAttachment: customData.hasOwnProperty('showAttachment') ? customData.showAttachment : false,
					submitConfirmation: customData.hasOwnProperty('submitConfirmation') ? customData.submitConfirmation : '',
					data: customData.hasOwnProperty('data') ? customData.data : []
				};

				self.useDefaultProcessVersion = ko.observable(self.config.useDefaultProcessVersion);

				self.useDefaultProcessVersion.subscribe(function (newValue) {
					updateProcesses(processesData);
					self.updateForms(processesData);
				});

				self.processDefId(self.config.processDefId);

				if (!self.processDefId() || self.processDefId() === 'noselection') {
					self.deployType(1);
				} else {
					self.deployType(self.config.deployType);
				}

				self.operation(self.config.operation);
				self.formName = ko.observable(self.config.formName);
				self.submitButton = ko.observable(self.config.submitButton);
				self.submitConfirmation = ko.observable(self.config.submitConfirmation);
				self.showSubmit = ko.observable(self.config.showSubmit);
				self.showSubmitConfirmation = ko.observable(self.config.showSubmitConfirmation);
				self.showSave = ko.observable(self.config.showSave);
				self.showDiscard = ko.observable(self.config.showDiscard);
				self.showAttachment = ko.observable(self.config.showAttachment);

				// remove those without a name
				for (i = 0; i < self.config.data.length; i++) {
					if (self.config.data[i].name !== '') {
						validData.push(self.config.data[i]);
					}
				}
				self.data(validData);

				self.isECPCS = false;
				self.serverURL = ko.observable();
				self.proxyPathName(self.config.proxyPathName);

				if (self.showProxies) {
					self.getProxies(self.getPCSServerUrl());
				}

				// Depending on whether proxy service is used or not:
				// - serveURL is set accordingly
				// - bypass auth check if true
				if (self.useProxyService()) {
					self.serverURL(proxyServicePathPrefix + self.proxyPathName());
					self.getProcesses(self.serverURL());
				} else {
					self.serverURL(self.getPCSServerUrl());
					if (self.serverURL()) {
						self.getToken(self.serverURL());
					}
				}

				self.save = ko.computed(function () {
					var processDefId = '',
						processName = '',
						serviceName = '',
						operation = '',
						startType = '',
						i,
						saveconfig,
						saveData = self.saveData();

					if (self.processDefId() && self.processDefId() !== 'noselection') {
						for (i = 0; i < self.processes().length; i++) {
							if (self.processDefId() === self.processes()[i].processDefId && self.operation() === self.processes()[i].operation) {
								processDefId = self.processes()[i].processDefId;
								processName = self.processes()[i].processName;
								serviceName = self.processes()[i].serviceName;
								operation = self.processes()[i].operation;
								startType = self.processes()[i].startType;
								break;
							}
						}
					}
					//save
					saveconfig = {
						'proxyPathName': self.proxyPathName(),
						'useDefaultProcessVersion': self.useDefaultProcessVersion(),
						'processDefId': processDefId,
						'formName': self.formName() || 'Form',
						'submitButton': self.submitButton() || 'Submit',
						'submitConfirmation': self.submitConfirmation() || 'Form has been submitted successfully',
						'processName': processName,
						'serviceName': serviceName,
						'operation': operation,
						'startType': startType,
						'showSubmit': self.showSubmit(),
						'showSubmitConfirmation': self.showSubmitConfirmation(),
						'showSave': self.showSave(),
						'showDiscard': self.showDiscard(),
						'showAttachment': self.showAttachment(),
						'deployType': self.deployType(),
						'data': self.data()
					};

					// move the NLS properties for translation
					saveconfig.nls = {};
					nlsProperties.forEach(function (nlsProp) {
						saveconfig.nls[nlsProp] = saveconfig[nlsProp];
						delete saveconfig[nlsProp];
					});

					//dispatch config to app
					if (saveData) {
						SitesSDK.setProperty('customSettingsData', saveconfig);
						self.saveData(false);
					}
				});

				self.deployType.subscribe(function (newValue) {
					self.deployType(newValue ? 1 : 0);
					self.processDefId('noselection');
					if (self.serverURL() && !self.useProxyService()) {
						self.getToken(self.serverURL());
					}
				});

				// save after value changes
				self.proxyPathName.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.formName.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.submitButton.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.showSubmit.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.submitConfirmation.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.showSubmitConfirmation.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.showSave.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.showDiscard.subscribe(function (newValue) {
					self.saveData(true);
				});
				self.showAttachment.subscribe(function (newValue) {
					self.saveData(true);
				});

				// Enable/Disable Add button after data changes
				self.data.subscribe(function (newValue) {
					var i,
						foundEmpty = false;

					if (newValue) {
						for (i = 0; i < newValue.length; i++) {
							if (newValue[i].name === '') {
								foundEmpty = true;
								break;
							}
						}
					}
					//console.log('data changed: ' + JSON.stringify(newValue) + ' foundEmpty=' + foundEmpty);
					self.allowAddData(!foundEmpty);
				});

				self.setNames = ko.computed(function () {
					var i;
					usedNames = [];
					for (i = 0; i < self.data().length; i++) {
						if (self.data()[i].name) {
							usedNames.push(self.data()[i].name);
						}
					}
					//console.log('setNames: used names=' + usedNames);
				});

				// now viewModel has been initialized
				self.initialized(true);

			};

			// get the customSettings Data and init the viewModel
			SitesSDK.getProperty('customSettingsData', self.init);

			// get proxy services
			self.getProxies = function (PCSServerURL) {
				var endpointUrl = '/pxysvc/api/1.0/endpoint',
					values = [];

				values.push({
					value: noSelection,
					label: strings.APP_STARTFORM_DEFAULT_SELECTION
				});

				// Include only entries with the PCS Server URL as target URI.
				if (PCSServerURL) {
					$.ajax({
						'type': 'GET',
						'dataType': 'json',
						'url': endpointUrl,
						async: false,
						'success': function (data) {
							if (data) {
								data.forEach(function (entry) {
									var uri = entry.targetUri.trim();

									uri = uri.replace(/\/*$/, '');

									if (uri === PCSServerURL) {
										values.push({
											value: entry.pathName,
											label: entry.name
										});
									}
								});
								self.proxies(values);
							}
						},
						'error': function (xhr, status, err) {
							console.error('getProxies: url=' + endpointUrl + ' status: ' + status + ' error: ' + err);
						}
					});
				} else {
					self.proxies(values);
				}
			};

			// get PCS server URL
			self.getPCSServerUrl = function () {
				var serverUrl = '',
					enabled = '',
					endpointUrl = '/pxysvc/api/1.0/endpoint',
					docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=PCS',
					appInfo,
					i,
					start = 0;

				// get server url from docs Admin first
				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': docsConfigUrl,
					async: false,
					'success': function (data) {
						// console.log('docsConfigUrl=' + docsConfigUrl + ' data=' + JSON.stringify(data));
						appInfo = data.ResultSets.AFApplicationInfo;
						if (appInfo) {
							for (i = 0; i < appInfo.fields.length; i++) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}

								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
					},
					'error': function (xhr, status, err) {
						console.log('getPCSServerUrl: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
					}
				});

				if (serverUrl) {
					self.isECPCS = serverUrl.indexOf('/ic/') >= 0;

					if (serverUrl.indexOf('//') >= 0) {
						start = serverUrl.indexOf('//') + 2;
					}
					if (serverUrl.indexOf('/', start) > 0) {
						// remove everything after /
						serverUrl = serverUrl.slice(0, serverUrl.indexOf('/', start));
					}
				}
				console.log('PCS server: ' + serverUrl + ' isEC=' + self.isECPCS);
				return serverUrl;
			};

			self.getToken = function (serverURL) {
				var token;

				SitesPCSUtils.getAuthToken({
					'serverURL': serverURL,
					'successCallback': function (data) {
						token = data;
						self.getProcesses(serverURL, token);
					},
					'errorCallback': function (xhr, status, err) {
						if (xhr && xhr.status === 200) {
							token = xhr.responseText;
						} else {
							console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
						}
						self.getProcesses(serverURL);
					}
				});
			};

			// Re-create the processes array.
			var updateProcesses = function (data) {
				var processDefId,
					title,
					buffer = [];

				if (data.items) {
					// Reset
					formsData = [];

					data.items.forEach(function (item, i) {

						if (!self.useDefaultProcessVersion() || item.defaultVersion) {
							// Include process if there is one interface of forms type
							var typeMatch = item.interfaces.filter(function (e) {
								return e.startType === 'START_PCS_FORM';
							});

							if (typeMatch.length > 0) {

								if (self.useDefaultProcessVersion()) {
									// Remove version. E.g.
									// 	Original: oracleinternalpcs~BasicApproval!19.3.1~CheckoutBook
									//  New:      oracleinternalpcs~BasicApproval~CheckoutBook
									processDefId = item.processDefId.replace(processRevisionRegEx, '~');
									title = item.applicationDisplayName + ':' + item.processDisplayName;
								} else {
									processDefId = item.processDefId;
									title = item.applicationDisplayName + ':' + item.processDisplayName + ' (' + item.revision + ')';
								}
								buffer.push({
									value: processDefId,
									label: title
								});

								// updateForms uses the following object.
								formsData.push({
									processDefId: processDefId,
									processName: item.processName,
									revision: item.revision,
									interfaces: item.interfaces
								});
							}
						}
					});

					buffer.sort(function (a, b) {
						return a.label.localeCompare(b.label);
					});
					buffer.unshift(noselectionObj);
					self.processeValues(buffer);
					//console.log('processes=' + JSON.stringify(self.processes()));
					//self.processes.valueHasMutated();

				} else {
					buffer.unshift(noselectionObj);
					self.processeValues(buffer);
				}
			};

			// Re-create the forms array.
			self.updateForms = function (data) {
				var processSelected,
					processMatch,
					item,
					obj,
					formsBuffer = [],
					buffer2 = [];

				if (data.items) {
					processSelected = self.processValue()[0];

					processMatch = formsData.filter(function (e) {
						return e.processDefId === processSelected;
					});

					if (processMatch.length > 0) {
						item = processMatch[0];

						item.interfaces.forEach(function (form) {
							// only show this type of forms
							if (form.startType === 'START_PCS_FORM') {

								formsBuffer.push({
									value: item.processDefId + ':' + form.operation,
									label: form.title.replace('(' + item.revision + ')', '')
								});
								obj = {
									'processDefId': item.processDefId,
									'processName': item.processName,
									'serviceName': form.serviceName,
									'operation': form.operation,
									'startType': form.startType
								};
								buffer2.push(obj);
							}
						});
					}

					formsBuffer.sort(function (a, b) {
						return a.label.localeCompare(b.label);
					});
					formsBuffer.unshift(noselectionObj);
					self.processes(buffer2);
					self.formsValues(formsBuffer);
				}
			};

			// REST call to get processes
			self.getProcesses = function (serverUrl, authToken) {
				var token,
					processUrl = serverUrl + (self.isECPCS ? "/ic/api/process/v1/process-definitions" : "/bpm/api/4.0/process-definitions?interfaceFilter=form"),
					i,
					j,
					title,
					buffer = [{
						value: 'noselection',
						label: strings.APP_STARTFORM_DEFAULT_SELECTION
					}],
					buffer2 = [],
					obj,
					item;

				// auth token only available on POD 
				token = authToken ? 'Bearer ' + authToken : "Basic " + btoa("bpmqaadmin:welcome1");
				//console.log('getProcesses: deployType=' + self.deployType() + ' token=' + token);

				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': processUrl,
					beforeSend: function (xhr) {
						if (self.useProxyService()) {
							xhr.withCredentials = false;
						} else {
							xhr.withCredentials = true;
							xhr.setRequestHeader('Authorization', token);
						}
						xhr.setRequestHeader('pcs_mode', self.deployType() === 0 ? 'dev' : '');
					},
					async: false,
					'success': function (data) {
						processesData = data;
						updateProcesses(processesData);
						self.updateForms(processesData);
					},
					'error': function (xhr, status, err) {
						console.error('process-definitions: xhr: ' + xhr + ' status: ' + status + ' error: ' + err);
					}
				});
			};


			self.addData = function () {
				var obj = {
					'name': '',
					'value': ''
				};

				self.data.push(obj);
				self.allowAddData(false);
			};

			self.removeData = function (selected) {
				self.data.remove(selected);
				self.data.valueHasMutated();
				self.saveData(true);
			};

			self.nameChange = function (event, ui) {
				// don't save if the name is empty
				if (ui.value) {
					self.data.valueHasMutated();
					self.saveData(true);
				} else {
					self.allowAddData(false);
				}
			};

			self.valueChange = function (event, ui) {
				self.data.valueHasMutated();
				self.saveData(true);
			};

			self.uniquenessValidator = {
				validate: function (value) {
					if (usedNames.includes(value)) {
						throw new Error(strings.APP_STARTFORM_DATA_DUPLICATE_NAME_MESSAGE);
					}
				}
			};

			self.dataNameValidators = [
				self.uniquenessValidator,
				new AsyncRegExpValidator({
					pattern: "[A-Za-z0-9\-_]{1,}",
					messageDetail: strings.APP_STARTFORM_DATA_NAME_HINT,
				})
			];

		}; //end of view model

		settingsViewModel = new MyViewModel();

		// Return the module
		return settingsViewModel;
	});