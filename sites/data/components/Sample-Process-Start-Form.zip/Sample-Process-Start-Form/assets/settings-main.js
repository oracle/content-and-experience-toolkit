/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs */
var JET_CDN = 'https://static.oracle.com/cdn/jet/14.0.4';
requirejs.config({
	baseUrl: '.',
	paths: {
		'knockout': JET_CDN + '/3rdparty/knockout/knockout-3.5.1',
		'preact': JET_CDN + '/3rdparty/preact/dist/preact.umd',
		'preact/hooks': JET_CDN + '/3rdparty/preact/hooks/dist/hooks.umd',
		'preact/compat': JET_CDN + '/3rdparty/preact/compat/dist/compat.umd',
		'preact/jsx-runtime': JET_CDN + '/3rdparty/preact/jsx-runtime/dist/jsxRuntime.umd',
		'@oracle/oraclejet-preact': JET_CDN + '/3rdparty/oraclejet-preact/amd',
		'jquery': JET_CDN + '/3rdparty/jquery/jquery-3.6.1.min',
		'jqueryui-amd': JET_CDN + '/3rdparty/jquery/jqueryui-amd-1.13.2.min',
		'ojs': JET_CDN + '/default/js/min',
		'ojL10n': JET_CDN + '/default/js/ojL10n',
		'ojtranslations': JET_CDN + '/default/js/resources',
		'signals': JET_CDN + '/3rdparty/js-signals/signals.min',
		'text': JET_CDN + '/3rdparty/require/text',
		'hammerjs': JET_CDN + '/3rdparty/hammer/hammer-2.0.8.min',
		'ojdnd': JET_CDN + '/3rdparty/dnd-polyfill/dnd-polyfill-1.0.2.min',
		'touchr': JET_CDN + '/3rdparty/touchr/touchr'
	}
});

requirejs(['jquery', 'knockout', './settings-vm'], function ($, ko, vm) {
	'use strict';
	ko.applyBindings(vm);
});
