/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs */
requirejs.config({
	'baseUrl': '.',

	paths: {

		'knockout': '../../../../node_modules/knockout/build/output/knockout-latest',
		'jquery': '../../../../node_modules/jquery/dist/jquery',
		// Oracle JET dependencies
		'preact':                   '../../../../node_modules/preact/dist/preact.umd',
        'preact/hooks':             '../../../../node_modules/preact/hooks/dist/hooks.umd',
        'preact/compat':            '../../../../node_modules/preact/compat/dist/compat.umd',
        'preact/jsx-runtime':       '../../../../node_modules/preact/jsx-runtime/dist/jsxRuntime.umd',
        '@oracle/oraclejet-preact': '../../../../node_modules/oraclejet-preact/amd',
		'ojs':                '../../../../node_modules/oraclejet/dist/js/libs/oj/min',
		'ojL10n':             '../../../../node_modules/oraclejet/dist/js/libs/oj/ojL10n',
		'ojtranslations':     '../../../../node_modules/oraclejet/dist/js/libs/oj/resources',
		'ojalta-css':         '../../../../node_modules/oraclejet/dist/css/alta/oj-alta-min',
		'ojalta-css-notag':   '../../../../node_modules/oraclejet/dist/css/alta/oj-alta-notag-min',
		'jquery-ui':          '../../../../node_modules/jquery-ui/ui',
		'jquery-ui-css':      '../../../../node_modules/jquery-ui/themes/ui-lightness/jquery-ui.min',
		'css':                '../../../../node_modules/require-css/css.min',
		'customElements':     '../../../../node_modules/custom-elements/custom-elements.min',
		'promise':            '../../../../node_modules/es6-promise/dist/es6-promise.min',
		'hammerjs':           '../../../../node_modules/hammerjs/hammer.min',
		'scrollbar':          '../../../../node_modules/simplebar/dist/simplebar.min',
		'scrollbar-css':      '../../../../node_modules/simplebar/dist/simplebar'
	},
	shim: {
		"jquery-ui": {
			"export": "$",
			deps: ['jquery']
		}
	},
	config: {
		ojL10n: {
			// APPS.languageCodes
		}
	},
	map: {
		'*': {
			// https://github.com/rniemeyer/knockout-sortable/issues/175
			'jquery-ui/sortable': 'jquery-ui/widgets/sortable',
			'jquery-ui/draggable': 'jquery-ui/widgets/draggable',

			'css': '../../../../node_modules/require-css/css.min',
			'jqueryui-amd': 'jquery-ui'
		}
	},
	waitSeconds: 0
});

requirejs(['jquery', 'knockout', './settings-vm'], function($, ko, vm) {
	'use strict';
	 ko.applyBindings(vm);
});
