/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,define,alert*/
/*jslint plusplus: true */
define(['jquery', 'knockout'], function ($, ko) {
	'use strict';


	return {
		/**
		 * Copied from ojcore.js. ojcore.js min is 28kb. This file min is 1kb.
		 * Hence, this util function is copied to keep the file size minimum.
		 *
		 * Applies parameters to a format pattern
		 * @param {string} pattern. Tokens ike {0}, {1}, {name} within the pattern 
		 * will be used to define string keys for retrieving values from the parameters
		 * object. Token strings should not contain comma (') 
		 * or space characters, since they are reserved for future format type enhancements. 
		 * The reserved characters within a pattern are:
		 * $ { } [ ]  
		 * These characters will not appear in the formatted output unless they are escaped
		 * with a dollar character ('$').
		 * 
		 * @param {Object|Array} parameters to be inserted into the string. Both arrays and
		 * Javascript objects with string keys are accepted.
		 * 
		 * @return formatted message or null if the pattern argument was null
		 * @export
		 */
		applyParameters: function (pattern, parameters) {
			return (pattern === null) ? null : this._format(pattern, parameters);
		},
		_format: function (formatString, parameters) {
			var formatLength = formatString.length;

			// Use the javascript StringBuffer technique.
			var buffer = [];

			var token = null;


			var escaped = false;
			var isToken = false;
			var isGroup = false;
			var isExcluded = false;

			var tokenTerminated; // this will be set to true when a comma or space is 
			// encountered in teh token
			var i;

			for (i = 0; i < formatLength; i++) {
				var ch = formatString.charAt(i);

				var accumulate = false;

				if (!escaped) {
					switch (ch) {
					case '$':
						escaped = true;
						break;

					case '{':
						if (!isExcluded) {
							if (!isToken) {
								tokenTerminated = false;
								token = [];
							}
							isToken = true;
						}
						break;

					case '}':
						if (isToken && token.length > 0) {
							var val = parameters[token.join('')];
							buffer.push((val === undefined) ? "null" : val);
						}
						isToken = false;
						break;

					case '[':
						if (!isToken) {
							if (isGroup) {
								isExcluded = true;
							} else {
								isGroup = true;
							}
						}
						break;

					case ']':
						if (isExcluded) {
							isExcluded = false;
						} else {
							isGroup = false;
						}
						break;

					default:
						accumulate = true;
					}
				} else {
					accumulate = true;
					escaped = false;
				}

				if (accumulate) {
					if (isToken) {
						if (ch == ',' || ch == ' ') {
							tokenTerminated = true;
						} else if (!tokenTerminated) {
							token.push(ch);
						}
					} else if (!isExcluded) {
						buffer.push(ch);
					}
				}
			}

			// Use the javascript StringBuffer technique for toString()
			return buffer.join("");
		},
		// API to create hybrid link for the folder
		// If hybrid link is created, link id is returned.
		createHybridLink: function (siteGUID, pageId, siteVariantGUID, folderGUID, idcToken, onSuccess, onFailure, roleName) {
			var self = this,
				createHybridLinkUrl = '/documents/link/web?IdcService=CREATE_HYBRID_LINK&IsJson=1';

			// Default role name is 'downloader'. 
			// If a different role name is passed, it takes precedence
			roleName = roleName || 'downloader';

			var postData = {
				LocalData: {
					IdcService: 'CREATE_HYBRID_LINK',
					IsJson: '1',
					idcToken: idcToken,
					item: 'fFolderGUID:' + folderGUID,
					dAssignedUsers: '#SitesDynamic:' + siteGUID + ':' + pageId + ':' + siteVariantGUID,
					dRoleName: roleName
				}
			};

			// create hybrid link
			$.ajax({
				'type': 'POST',
				'dataType': 'json',
				'url': createHybridLinkUrl,
				data: JSON.stringify(postData),
				contentType: 'application/json; charset=utf-8',
				'success': function (data) {
					// Hybrid link is available at data.LocalData.dLinkID.
					// Passing the entire response data to the callback,
					// in case the caller needs more information.
					if (typeof onSuccess === 'function') {
						onSuccess(data);
					}
				},
				'error': function (xhr, status, err) {
					// Passing the error to the callback
					if (typeof onFailure === 'function') {
						onFailure(err);
					}
				}
			});
		},
		// Create hybrid link with OSN APIs
		createConvoHybridLink: function (siteid, pageId, updateId, idcToken, convoId, onSuccess, onFailure) {
			var self = this,
				serverInfoUrl = '/documents/web?IdcService=GET_SERVER_INFO',
				osnRestUrl = '',
				i,
				index,
				connUrl = '/connections',
				connData = {
					'name': '',
					'password': ''
				},
				hybridLinkUrl = '/conversations/' + convoId + '/hybridlinks',
				linkData = {
					'applicationInstanceID': siteid
				};

			// get the OSN REST URL first
			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': serverInfoUrl,
				'success': function (data) {
					if (data.ResultSets && data.ResultSets.ClientURLs && data.ResultSets.ClientURLs.rows) {
						for (i = 0; i < data.ResultSets.ClientURLs.rows.length; i++) {
							if (data.ResultSets.ClientURLs.rows[i][0] === 'OSNRestURL') {
								osnRestUrl = data.ResultSets.ClientURLs.rows[i][1];
								break;
							}
						}
					}
					//alert('osnRestUrl=' + osnRestUrl);
					if (osnRestUrl) {
						index = osnRestUrl.lastIndexOf('/v1');
						if (index < 0 || index + 3 < osnRestUrl.length) {
							osnRestUrl = osnRestUrl + '/v1';
						}
						// post to connections to get the apiRandomID
						$.ajax({
							'type': 'POST',
							'dataType': 'json',
							'url': osnRestUrl + connUrl,
							data: JSON.stringify(connData),
							contentType: 'application/json; charset=utf-8',
							xhrFields: {
								withCredentials: true
							},
							'success': function (data) {
								// use the id to create a new hybrid link
								if (data.apiRandomID) {
									$.ajax({
										'type': 'POST',
										'dataType': 'json',
										'url': osnRestUrl + hybridLinkUrl,
										'headers': {
											'X-Waggle-RandomID': data.apiRandomID
										},
										data: JSON.stringify(linkData),
										contentType: 'application/json; charset=utf-8',
										xhrFields: {
											withCredentials: true
										},
										'success': function (data) {
											if (data && data.hybridLinkID) {
												self.setConvoHybridLinkMetadata(data.hybridLinkID, siteid, pageId, updateId, idcToken, onSuccess, onFailure);
											} else {
												onFailure('failed to create hybrid link');
											}
										},
										'error': function (xhr, status, err) {
											onFailure(err);
										}
									});
								}
							},
							'error': function (xhr, status, err) {
								onFailure(err);
							}
						});
					} else {
						onFailure('failed to get OSN REST url');
					}
				},
				'error': function (xhr, status, err) {
					onFailure(err);
				}
			});
		},
		// call SET_METADATA to add the link to xScsLinkPageMap for the base site with value
		// OSN/dLinkID/pageID/updateGUID
		setConvoHybridLinkMetadata: function (linkId, siteId, pageId, updateId, idcToken, onSuccess, onFailure) {
			var scsLink = 'OSN/' + linkId + '/' + pageId + '/' + updateId,
				setMetadataUrl = '/documents/web?IdcService=SET_METADATA&idcToken=' + idcToken + '&items=fFolderGUID:' + siteId + '&xScsLinkPageMap%2B=' + scsLink;

			$.ajax({
				'type': 'POST',
				'url': setMetadataUrl,
				contentType: 'application/json; charset=utf-8',
				'success': function () {
					onSuccess(linkId);
				},
				'error': function (xhr, status, err) {
					console.warning('status=' + status + ' err=' + err);
					onFailure(err);
				}
			});
		}
	};

});
