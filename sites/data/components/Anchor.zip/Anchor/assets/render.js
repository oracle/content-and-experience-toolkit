/* globals define, SCSRenderAPI */

define([
	'jquery',
	'css!./layout.css'
], function ($) {
	'use strict';

	function SectionLayout(params) {
		this.sectionLayoutData = params.sectionLayoutData || {};
		this.renderMode = params.renderMode || SCSRenderAPI.getRenderMode();
	}

	SectionLayout.prototype = {

		createComponentDiv: function (componentId) {
			return '<div id="' + componentId + '"></div>';
		},
		render: function (parentObj) {
			var self = this;
			var html = '';
			var anchorName;
			var emptyClass;
			var components = self.sectionLayoutData.components || [];

			if (self.sectionLayoutData.customSettingsData) {
				anchorName = self.sectionLayoutData.customSettingsData.anchorName;
				if (anchorName) {
					html += '<a name="' + anchorName + '"></a>';
				}
			}

			try {
				// Add the child components to the section layout.  For each of the child 
				// components, add a <div> to the page.  The child components will be 
				// rendered into these <div>s.
				$.each(components, function (index, value) {
					html += self.createComponentDiv(value);
				});

				// Add a drop zone to the section layout in edit mode, if applicable
				if (self.renderMode === SCSRenderAPI.RENDER_MODE_EDIT) {
					emptyClass = components.length > 0 ? '' : 'sl-empty';
					$(parentObj).append('<div class="sl-list-drop-zone ' + emptyClass + '">Add Item</div>');
				}

				if (html) {
					$(parentObj).append(html);
				}

				// Check if anchorName matches the hash in the URL
				if (window.location.hash === '#' + anchorName) {
					$(document).on('scsrendercomplete', function(){
						parentObj.scrollIntoView();
					});
				}
			} catch (e) {
				console.error(e);
			}
		},
		// dynamic API for adding additional components through "load more" when used in a Content List
		addComponent: function (parentObj, component) {
			// create the component div and add it to the parent object
			$(parentObj).append(this.createComponentDiv(component));
		}
	};

	return SectionLayout;
});