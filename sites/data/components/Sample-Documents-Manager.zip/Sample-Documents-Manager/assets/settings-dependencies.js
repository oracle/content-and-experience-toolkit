/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define([	
	//************************************************
	// "Settings" component specific dependencies
	//************************************************

	// JET depenencies
	'ojs/ojknockout', // what is this and how is it different to 'knockout'? 
	'ojs/ojinputtext',
	'ojs/ojbutton',
	'ojs/ojselectcombobox',
	'ojs/ojcore',
	'css!ojalta-css',

	//************************************************
	// Common dependencies
	//************************************************
	
	//Style definitions
	'css!styles/settings.css',

	// simplebar
	'scrollbar',
	'css!scrollbar-css'
],
	function () {
		//***************************************************
		// This simply defines in all the required dependency files
		// for the components. 
		//	
		// Individual components require in specific classes they use
		// but the core set of dependencies are defined here
		//***************************************************
	});
