/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global ko, $, SitesSDK, alert,console, define */
define(['jquery', 'knockout'], function ($, ko) {
	'use strict';
	var browsingUrl = '/documents/embed/[folder]/[sort]/lyt=[lyt]?hide=[hide]&[options]',
		browsingUrlPublic = '/documents/embed/link/[linkid]/[folder]/[sort]/lyt=[lyt]?hide=[hide]&[options]',
		templateViewModel,
		docsHost = location.host,
		defaultFolder = window.location.hostname === 'localhost' ? 'home' : '',
		MyViewModel = function () {
			var self = this,
				browsing = true,
				server,
				linkId,
				folderId,
				urlStr,
				options = 'wide',
				hide = 'sidebar,pin',
				getAppActionsListener,
				executeActionListener,
				tmpArray;

			// get the documents host
			tmpArray = docsHost.split('.');
			if (tmpArray.length > 1 && tmpArray[1].indexOf('sites') >= 0) {
				tmpArray[1] = tmpArray[1].replace('sites', 'documents');
				docsHost = tmpArray.join('.');
			}

			self.displayName = 'Document Manager';

			self.appParams = self.getQueryParameters(window.location.href);
			self.isRendering = ko.observable(false);
			self.height = self.appParams.height ? (parseInt(self.appParams.height.replace('px', ''), 10) < 600 ? '600px' : self.appParams.height) : '600px';
			self.style = ko.observable('display: block; border: 0; width: 100%; min-width: 400px; min-height: 600px; max-height: 100%; height:' + self.height);
			self.url = ko.observable('');
			self.locale = '';

			self.initialized = ko.observable(false);

			SitesSDK.getProperty('viewMode', function(viewMode) {
				self.isRendering(viewMode!== 'edit');
			});

			// handle initialization of the viewModel
			self.init = function (config) {
				//initialize the observales with settings data
				self.initWithSettings(config);
				// now viewModel has been initialized
				self.initialized(true);
			};

			SitesSDK.getProperties(['componentAssets', 'locale'], function (props) {
				var assets = props.componentAssets;

				self.locale = props.locale || '';

				// Assets should be obtained before customSettings.
				// The hybrid link is stored in the source attribute.
				// At present, we are storing only one asset, so it is okay to 
				// get it from index 0, rather than checking for id of the asset.
				self.assets = assets;
				if (assets.length > 0) {
					self.hybridLinkURL = assets[0].source;
				}
				// get the customSettings Data and init the viewModel
				SitesSDK.getProperty('customSettingsData', self.init);
			});

			self.initWithSettings = function (config) {
				self.instanceConfig = {
					// When Docs Manager is dropped on the page, no folder is selected.
					// Hence, by default folderGuid should be empty.
					folder: config.hasOwnProperty('folderGuid') ? config.folderGuid : defaultFolder,
					linkid: config.hasOwnProperty('linkid') ? config.linkid : '',
					linkPerm: config.hasOwnProperty('linkPerm') ? config.linkPerm : 'downloader',
					layout: config.hasOwnProperty('layout') ? config.layout : 'compact',
					color: config.hasOwnProperty('color') ? config.color : 'light',
					sortBy: config.hasOwnProperty('sortBy') ? config.sortBy : 'nameasc',
					showDownload: config.hasOwnProperty('showDownload') ? config.showDownload : true,
					showUpload: config.hasOwnProperty('showUpload') ? config.showUpload : true,
					showShare: config.hasOwnProperty('showShare') ? config.showShare : true,
					showCopy: config.hasOwnProperty('showCopy') ? config.showCopy : true,
					showMove: config.hasOwnProperty('showMove') ? config.showMove : true,
					showDelete: config.hasOwnProperty('showDelete') ? config.showDelete : true,
					showEdit: config.hasOwnProperty('showEdit') ? config.showEdit : true,
					showConvoPane: config.hasOwnProperty('showConvoPane') ? config.showConvoPane : true,
					enableViewer: config.hasOwnProperty('enableViewer') ? config.enableViewer : true,
					viewerZoom: config.hasOwnProperty('viewerZoom') ? config.viewerZoom : 'all',
					viewerFitMode: config.hasOwnProperty('viewerFitMode') ? config.viewerFitMode : 'sfp',
					viewerEmbedded: config.hasOwnProperty('viewerEmbedded') ? config.viewerEmbedded : true,
					viewerThumbnail: config.hasOwnProperty('viewerThumbnail') ? config.viewerThumbnail : true,
					viewerVideo: config.hasOwnProperty('viewerVideo') ? config.viewerVideo : true,
					autowiring: config.hasOwnProperty('autowiring') ? config.autowiring : true
				};

				//
				// Browsing Config
				//
				if (self.instanceConfig.showDownload === false) {
					hide = hide + ',dnload';
				}
				if (self.instanceConfig.showUpload === false) {
					hide = hide + ',upload';
				}
				if (self.instanceConfig.showShare === false) {
					hide = hide + ',share';
				}
				if (self.instanceConfig.showCopy === false) {
					hide = hide + ',copy';
				}
				if (self.instanceConfig.showMove === false) {
					hide = hide + ',move';
				}
				if (self.instanceConfig.showDelete === false) {
					hide = hide + ',delete';
				}
				if (self.instanceConfig.showEdit === false) {
					hide = hide + ',edit';
				}

				// Viewer Config set in Browsing Config
				if (self.instanceConfig.enableViewer === false) {
					options = options + '&noview';
				} else {
					if (self.instanceConfig.viewerEmbedded === false) {
						options = options + '&launch';
					}
				}

				//
				// Viewer Config
				//
				options = options + '&' + self.instanceConfig.viewerFitMode;

				if (self.instanceConfig.viewerZoom !== 'all') {
					options = options + '&' + self.instanceConfig.viewerZoom;
				}
				if (self.instanceConfig.viewerThumbnail === false) {
					hide = hide + ',thumbs';
				}
				if (self.instanceConfig.viewerVideo === false) {
					options = options + '&novidctls';
				}
				// TODO - video has multiple mode
				// Let's wait for UX design
				// vap Video should auto play when the page loads
				// vlp Video should loop when it finishes playing.
				// vmt Video should be muted.

				if (self.instanceConfig.linkPerm !== 'member' && self.hybridLinkURL) {
					// Hybrid link is an URL. Only append the other options
					urlStr = self.hybridLinkURL + '/[sort]/lyt=[lyt]?hide=[hide]&[options]';
				} else if (self.instanceConfig.linkid !== '') {
					urlStr = browsingUrlPublic;
					folderId = self.instanceConfig.folder;
					linkId = self.instanceConfig.linkid;

				} else if (self.instanceConfig.folder) {
					urlStr = browsingUrl;
					folderId = self.instanceConfig.folder === 'home' ? 'folder/home' : self.instanceConfig.folder;
					linkId = '';
				} else {
					// When there is no selection, let the url to be empty, so that watermark is displayed.
					urlStr = '';
				}

				if (urlStr) {
					urlStr = urlStr.replace('[linkid]', linkId);
					urlStr = urlStr.replace('[folder]', folderId);
					urlStr = urlStr.replace('[sort]', self.instanceConfig.sortBy);
					urlStr = urlStr.replace('[lyt]', self.instanceConfig.layout);
					urlStr = urlStr.replace('[hide]', hide);
					urlStr = urlStr.replace('[options]', options);

					urlStr = urlStr + '&scheme=' + self.instanceConfig.color;

					if (self.instanceConfig.linkPerm === 'member' && self.instanceConfig.showConvoPane) {
						urlStr = urlStr.replace('sidebar,pin', '');
						urlStr = urlStr + '&embedEnterHive';
					}

					// If user is sign-in, use /ssoembed instead of /embed
					$.ajax({
						'url': '/documents/web?IdcService=GET_SERVER_INFO',
						async: false,
						success: function (data) {
							urlStr = urlStr.replace('\/embed\/', '\/ssoembed\/');
						},
						complete: function () {
							//console.log('embed URL: ' + urlStr);
						}
					});

					// Prefix the host only if it is not already there 
					if (urlStr.indexOf(location.protocol + "//" + docsHost) < 0) {
						// use full url
						urlStr = location.protocol + "//" + docsHost + urlStr;

						if (self.locale) {
							urlStr += '&locale=' + self.locale; 
						}
					}

				}
				console.log('docs-mgr: url=' + urlStr);
				//create the observables
				self.url(urlStr);
				if (!self.url()) {
					if (!self.isRendering()) {
						// Watermark 
						SitesSDK.setProperty('height', '182px');
					} else {
						SitesSDK.setProperty('height');
					}
				} else {
					SitesSDK.setProperty('height', '600px');
				}
			};

			// ACTIONS meta-data listener
			getAppActionsListener = function (args) {
				var actions = [
					{
						'actionName': 'scsDocsMgrViewFolderDetails',
						'actionDescription': 'Display Documents',
						'actionPayload': [{
							'name': 'folderId',
							'description': 'Folder Id or URL',
							'type': {
								'ojComponent': {
									'component': 'ojInputText'
								}
							},
							'value': ''
						}]
					}
				];
				return actions;
			};

			// Execute Action listener

			executeActionListener = function (args) {
				var payload = args.detail.message.payload,
					action = args.detail.message.action,
					actionName = action && action.actionName,
					triggerName = action && action.triggerName,
					payloadValue,
					folderId = '',
					folderLink = '',
					color = '',
					showConvoPane = false,
					isPublic,
					newurl,
					index;

				//console.log('docs-mgr: action=' + actionName + ' trigger=' + triggerName + ' payload=' + JSON.stringify(payload));
				if (self.instanceConfig.autowiring === false && actionName === 'scsViewFolder') {
					// no auto wiring
					return;
				}

				if ((actionName === 'scsDocsMgrViewFolderDetails' || actionName === 'scsViewFolder') && payload) {
					// handle array based payload
					payloadValue = $.isArray(payload) ? (payload[0].value || {}) : payload;

					if (typeof payloadValue === 'string') {
						// payloadValue contains the folder id or URL.
						if (payloadValue.indexOf('/folder/') > 0) {
							folderLink = payloadValue;
							// payloadValue is an URL. Extract the Folder Id.
							payloadValue = payloadValue.substr(payloadValue.indexOf('/folder/') + 8);
							if (payloadValue.indexOf('/') > 0) {
								payloadValue = payloadValue.slice(0, payloadValue.indexOf('/'));
							}
						} else if (action && action.triggerName && action.triggerName === 'scsFileViewerFileSelectedTrigger') {
							// Special handling for the trigger from File List
							if (payloadValue.indexOf('/fileview/') > 0) {
								folderLink = payloadValue;
								// File Preview URL. Extract the File Id.
								payloadValue = payloadValue.substr(payloadValue.indexOf('/fileview/') + 10);
								if (payloadValue.indexOf('/') > 0) {
									payloadValue = payloadValue.slice(0, payloadValue.indexOf('/'));
								}
							} else if (payloadValue.indexOf('IdcService=GET_FILE') > 0 && payloadValue.indexOf('FileGUID:') > 0) {
								// File Link. Extract the File Id.
								payloadValue = payloadValue.substr(payloadValue.indexOf('FileGUID:') + 9);
								if (payloadValue.indexOf('/') > 0) {
									payloadValue = payloadValue.slice(0, payloadValue.indexOf('/'));
								}
							} else if (payloadValue.indexOf('/file/') > 0) {
								folderLink = payloadValue;
								// Public File Link. Extract the File Id.
								payloadValue = payloadValue.substr(payloadValue.indexOf('/file/') + 6);
								if (payloadValue.indexOf('/') > 0) {
									payloadValue = payloadValue.slice(0, payloadValue.indexOf('/'));
								}
							}
						}
						folderId = payloadValue;
					} else {
						// payload is an folder object
						folderId = payloadValue.id;
						folderLink = payloadValue.link;
						color = payloadValue.color;
						showConvoPane = payloadValue.showConvoPane;
					}


					// update the folder id and link id(if public link) and refresh
					if (action && action.triggerName && action.triggerName === 'scsFileViewerFileSelectedTrigger') {
						// If the trigger is from File List, preview the file.
						self.instanceConfig.folder = 'fileview/' + folderId;
					} else {
						self.instanceConfig.folder = 'folder/' + folderId;
					}

					index = folderLink.indexOf('/link/');
					isPublic = (folderLink !== '' && index > 0);
					if (isPublic) {
						linkId = folderLink.substring(folderLink.indexOf('/link/') + 6);
						if (linkId.indexOf('/') > 0) {
							linkId = linkId.substring(0, linkId.indexOf('/'));
						}
						newurl = browsingUrlPublic;
						newurl = newurl.replace('[linkid]', linkId);
					} else {
						newurl = browsingUrl;
					}
					newurl = newurl.replace('[folder]', self.instanceConfig.folder);
					newurl = newurl.replace('[sort]', self.instanceConfig.sortBy);
					newurl = newurl.replace('[lyt]', self.instanceConfig.layout);

					if (!isPublic && showConvoPane) {
						// member access, show conversation pane
						newurl = newurl.replace('[hide]', hide.replace('sidebar,pin', ''));
						newurl = newurl + '&embedEnterHive';
					} else {
						newurl = newurl.replace('[hide]', hide);
					}

					newurl = newurl.replace('[options]', options);

					newurl = newurl + '&scheme=' + (color || self.instanceConfig.color);

					// If user is sign-in, use /ssoembed instead of /embed
					$.ajax({
						'url': '/documents/web?IdcService=GET_SERVER_INFO',
						async: false,
						success: function (data) {
							newurl = newurl.replace('\/embed\/', '\/ssoembed\/');
						},
						complete: function () {
							//console.log('embed URL: ' + urlStr);
						}
					});

					// use full url
					newurl = location.protocol + "//" + docsHost + newurl;	

					if (self.locale) {
						urlStr += '&locale=' + self.locale; 
					}

					console.log('docs-mgr: actionListener url=' + newurl);

					self.url(newurl);

					if (!self.url()) {
						if (!self.isRendering()) {
							// Watermark 
							SitesSDK.setProperty('height', '182px');
						} else {
							SitesSDK.setProperty('height');
						}
					} else {
						SitesSDK.setProperty('height', '600px');
					}
				}
			};

			// listen for ACTIONS meta-data request and send actions metadata to host-site
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_ACTIONS, getAppActionsListener);

			// listen for the EXECUTE ACTION request to handle custom actions
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(executeActionListener, self));

			//listen for settings update
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.handleUpdatedSettings, self));

		};

	MyViewModel.prototype.encodeURL = function (val) {
		// encode all special characters, except: , / ? : @ & = + $ 
		var origVal = val ? (typeof val === 'function' ? val().toString() : val.toString()) : '',
			encodeVal = encodeURI(origVal);
		encodeVal = encodeVal.replace(/javascript:/ig, 'java-script:');
		encodeVal = encodeVal.replace(/vbscript:/ig, 'vb-script:');
		return encodeVal;
	};

	MyViewModel.prototype.afterRender = function (elements) {
		//SitesSDK.setProperty('height', '600px');
	};

	//-----------------------------------------------
	// Get render Sites SDK parameters, e.g, viewMode
	//-----------------------------------------------
	MyViewModel.prototype.getQueryParameters = function (url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	};

	// handle changedSettings event from settings panel
	MyViewModel.prototype.handleUpdatedSettings = function (event) {

		//get the event payload
		var self = this,
			payload;
		if (typeof event.detail.message === 'object') {
			payload = event.detail.message;
		} else if (typeof event.detail.message === 'string') {
			try {
				payload = JSON.parse(event.detail.message);
			} catch (err) {
				payload = {};
			}
		} else {
			payload = {};
		}
		if (payload.property) {
			if (payload.property === 'customSettingsData') {
				//console.log('Updated customSettingsData !!!' + JSON.stringify(payload,null,2));
				//apply update

				SitesSDK.getProperties(['componentAssets', 'locale'], function (props) {
					var assets = props.componentAssets;

					self.locale = props.locale || '';

					// Assets should be obtained before customSettings.
					// The hybrid link is stored in the source attribute.
					// At present, we are storing only one asset, so it is okay to 
					// get it from index 0, rather than checking for id of the asset.
					self.assets = assets;
					if (assets.length > 0) {
						self.hybridLinkURL = assets[0].source;
					}
					self.initWithSettings(payload.value);
				});

			}
		}

	};


	//-----------------------------------------------
	// Create the view model and initialize knockout
	//-----------------------------------------------
	templateViewModel = new MyViewModel();

	// Return the module
	return {
		'templateViewModel': templateViewModel,
		'afterRender': templateViewModel.afterRender
	};
});
