// Common Utilities Class
export default class {
    constructor(contentClient, noPermissionToView) {
        this.contentClient = contentClient;
        this.noPermissionToView = noPermissionToView || "You do not have permission to view this asset";
        this.libs = this.contentClient.getLibs() || {};

        this.marked = this.libs.marked || window.marked;
    }

    // Helper method to make an additional Content REST API call to retrieve all items referenced in the data by their ID.
    getRefItems(ids) {
        // Calling getItems() with no ‘ids’ returns all items.
        // If no items are requested, just return a resolved Promise.
        if (ids.length === 0) {
            return Promise.resolve({});
        } else {
            return this.contentClient.getItems({
                "ids": ids
            });
        }
    }

    //
    // Helper Methods to handle specific field types
    //

    findReferenceFieldIds(referencedItems, fields) {
        const referencedIds = [];

        referencedItems.forEach((referencedItem) => {
            if (fields[referencedItem]) {

                // handle multiple or single value content fields
                (Array.isArray(fields[referencedItem]) ? fields[referencedItem] : [fields[referencedItem]]).forEach((entry) => {
                    if (entry) {
                        // if asset is accessible, add it
                        if (!entry.reference || entry.reference.isAccessible) {
                            referencedIds.push(entry.id);
                        } else {
                            // asset is not accessible, store the message against the entry
                            entry.referenceInaccessible = this.noPermissionToView;
                        }
                    }
                });
            }
        });

        return referencedIds;
    }

    augmentFieldData(fieldItem, referencedItem) {
        if (referencedItem) {
            // add a pointer to the retreived referenced item
            fieldItem.contentItem = referencedItem;

            // make sure that this item is accessible by the user
            if (!fieldItem.reference || fieldItem.reference.isAccessible) {
                // augment the referenced item's field values
                const fields = referencedItem.fields || {};

                // add the URL to the digital asset
                referencedItem.url = this.contentClient.getRenditionURL({
                    "id": referencedItem.id
                });

                // add in render value based on mimetype
                const fileType = fields.mimeType || fields.type || 'document/';
                if (fileType.toLowerCase().startsWith("video/")) {
                    referencedItem.renderAsVideo = true;
                } else if (fileType.toLowerCase().startsWith("image/")) {
                    referencedItem.renderAsImage = true;
                } else {
                    referencedItem.renderAsDownload = true;
                }

                // also generate URLs for any digital assets in the referencedItem
                Object.keys(fields).forEach(key => {
                    const field = fields[key];
                    if (typeof field === 'object' && field.typeCategory === 'DigitalAssetType') {
                        field.url = this.contentClient.getRenditionURL({
                            "id": fields.id
                        });
                    }
                });
            } else {
                // asset is not accessible, store the message against the entry
                referencedItem.referenceInaccessible = this.noPermissionToView;
            }
        }
    }

    updateDigitalAssetURLs(digitalAssetFields, fields) {
        for (const fieldName of digitalAssetFields) {
            const field = fields[fieldName];
            if (field) {
                for (const digitalAssetField of Array.isArray(field) ? field : [field]) {
                    if (!digitalAssetField.reference || digitalAssetField.reference.isAccessible) {
                        // get the URL to the digital asset
                        digitalAssetField.url = this.contentClient.getRenditionURL({
                            "id": digitalAssetField.id
                        });
                    } else {
                        // asset is not accessible, store the message against the entry
                        digitalAssetField.referenceInaccessible = this.noPermissionToView;
                    }
                }
            }
        }
    }

    updateMarkdownFields(markdownFields, fields) {
        const parseMarkdown = (mdText) => {
            if (mdText && /^<!---mde-->\n\r/i.test(mdText)) {
                mdText = mdText.replace("<!---mde-->\n\r", "");

                mdText = this.marked(mdText);
            }

            return mdText;
        };

        markdownFields.forEach((markdownField) => {
            if (fields[markdownField]) {

                // handle multiple or single value content fields
                if (Array.isArray(fields[markdownField])) {
                    fields[markdownField] = fields[markdownField].map((entry) => {
                        return parseMarkdown(this.contentClient.expandMacros(entry));
                    });
                } else {
                    fields[markdownField] = parseMarkdown(this.contentClient.expandMacros(fields[markdownField]));
                }
            }
        });
    }

    updateRichTextFields(richTextFields, fields) {
        richTextFields.forEach((richTextField) => {
            if (fields[richTextField]) {

                // handle multiple or single value content fields
                if (Array.isArray(fields[richTextField])) {
                    fields[richTextField] = fields[richTextField].map((entry) => {
                        return this.contentClient.expandMacros(entry);
                    });
                } else {
                    fields[richTextField] = this.contentClient.expandMacros(fields[richTextField]);
                }
            }
        });
    }

    updateDateTimeFields(dateTimeFields, fields) {
        const dateToMDY = (date) => {
            if (!date) {
                return "";
            }

            const dateObj = new Date(date);

            const options = {
                year: "numeric",
                month: "long",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            };
            const formattedDate = dateObj.toLocaleDateString("en-US", options);

            return formattedDate;
        }

        dateTimeFields.forEach((dateTimeField) => {
            if (fields[dateTimeField]) {

                // handle multiple or single value content fields
                if (Array.isArray(fields[dateTimeField])) {
                    fields[dateTimeField] = fields[dateTimeField].map((entry) => {
                        return entry.formatted = dateToMDY(entry.value);
                    });
                } else {
                    fields[dateTimeField].formatted = dateToMDY(fields[dateTimeField].value);
                }
            }
        });
    }

    addReferencedItems(referencedItems, results, fields) {
        // loop through all the expected referenced field names
        for (const fieldName of referencedItems) {
            const field = fields[fieldName];

            // handle both single and array versions of the field entry
            for (const referencedField of Array.isArray(field) ? field : [field]) {
                if (referencedField) {
                    // find the matching retreived item
                    const item = (results && results.items || []).find(entry => entry.id === referencedField.id);

                    // augment the field data based on the retreived referenced item
                    this.augmentFieldData(referencedField, item);
                }
            }
        }
    }
}