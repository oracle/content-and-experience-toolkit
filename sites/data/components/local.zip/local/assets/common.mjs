/**
 * Copyright (c) 2022 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
// Common Utilities Class
export default class {
	constructor() {}

	static createHTML(context, args) {
		// extract all the required dependencies from the context
		const Mustache = context.Mustache,
			componentLayout = context.componentLayout,
			customSettingsData = context.customSettingsData,
			nestedComponents = context.nestedComponents || {},
			id = context.id,
			template = context.template;

		// extract the original values (or apply deafult values)
		const layout = (args && args.componentLayout) || componentLayout || 'default',
			customData = (args && args.customSettingsData) || customSettingsData || {},
			imageWidth = (args && args.imageWidth) || (customData.hasOwnProperty('width') ? customData.width : '');

		customData.nls = customData.nls || {};

		// create the model
		const model = {
			linkURL: customData.linkURL || '',
			linkText: customData.nls.linkText || '',
			titleText: customData.nls.titleText || 'Template Component',
			paragraphText: customData.nls.paragraphText || '',
			layout: layout,
			alignImageRight: layout === 'right',
			showTopLayout: layout === 'top',
			showStoryLayout: (layout === 'default' || layout === 'right'),
			imageContainerId: 'imageContainer' + id,
			imageWidth: imageWidth || '200px',
			imageStyle: '',
			paragraphStyle: '',
			nestedComponents: nestedComponents
		};

		if (!model.showTopLayout) {
			// Style on left- or right-aligned image
			model.imageStyle = 'flex-shrink:0;width:' + model.imageWidth + ';';

			// Style around paragraph component
			model.paragraphStyle = 'flex-grow:1;';
		}

		// render the component
		try {
			return Mustache.render(template, model);
		} catch (e) {
			console.log('Failed to expand Mustache template.', e);
			return '';
		}
	}
}