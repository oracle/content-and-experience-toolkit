/**
 * Copyright (c) 2022 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
import CommonUtils from './common.mjs';

// The Custom Component class will be the "default" export from the module
export default class {

	constructor(args) {
		// store the args
		this.mode = args.viewMode;
		this.id = args.id;

		// store the path to the <component>/assets folder
		this.assetsPath =
			import.meta.url.replace('/render.mjs', '');

		// get the OCM environment resources 
		this.sitesSDK = args.SitesSDK;
		this.Mustache = SCSRenderAPI.getMustache();

		// add in the nested components
		this.createNestedComponents();

		// add in the event listeners
		this.addEventListeners();
	}

	// create the nested component definitions to be used when expanding the template and instantiating the nested components
	createNestedComponents() {
		// id: of the component - (matches data-compid) used to store nested component settings in the page data 
		// value: nested component entry inserted into the template
		this.nestedComponents = {
			image: {
				id: 'imageId', 
				value: `<scs-image data-compid="imageId" params="{ scsComponent: { 'renderMode': renderMode, 'parentId': parentId, 'id': id, 'data': data } }"></scs-image>`
			},
			title: {
				id: 'titleId', 
				value: `<scs-title data-compid="titleId" params="{ scsComponent: { 'renderMode': renderMode, 'parentId': parentId, 'id': id, 'data': data } }"></scs-title>`
			},
			paragraph: {
				id: 'paragraphId',
				value: `<scs-paragraph data-compid="paragraphId" params="{ scsComponent: { 'renderMode': renderMode, 'parentId': parentId, 'id': id, 'data': data } }"></scs-paragraph>`
			}
		};
	}

	// add in the listeners for the triggers/actions and whenever the settings values change
	// in this case, we want to re-render the component on the screen
	addEventListeners() {
		// listen for settings update
		this.sitesSDK.subscribe(this.sitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, (props) => {
			if (props.property === 'customSettingsData') {
				this.renderComponent({
					customSettingsData: props.value
				});
			} else if (props.property === 'componentLayout') {
				this.renderComponent({
					componentLayout: props.value
				});
			}
		});

		// listen for actions
		this.sitesSDK.subscribe(this.sitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, (args) => {
			// get action and payload
			var payload = Array.isArray(args.payload) ? args.payload : [],
				action = args.action;

			// handle 'setImageWidth' actions
			if (action && action.actionName === 'setImageWidth') {
				payload.forEach((data) => {
					if (data.name === 'imageWidth') {
						this.renderComponent({
							imageWidth: data.value
						});
					}
				});
			}
		});
	}

	addClickHandlers(container) {
		// when the image is clicked
		const img = document.getElementById('imageContainer' + this.id);

		if (img) {
			img.addEventListener('click', (event) => {
				this.sitesSDK.publish(this.sitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
					'triggerName': 'imageClicked', // 'imageClicked' matches value in appinfo.json
					'triggerPayload': {
						'payloadData': 'some data here' // customize with data you want pass
					}
				});
			});
		}
	}

	// instantiate each of the nested components in the expanded view so they take the OCM behavior
	instantiateNestedComponents() {
		for (const key of Object.keys(this.nestedComponents)) {
			const nestedComp = this.nestedComponents[key];
			// construct any custom model for the nested component
			const ncViewModel = {
				'renderMode': this.mode || '', // tell the nested component in which state to render
				'parentId': this.id, // this custom component ID and is used to scope all nested components
				'id': nestedComp.id, // nested component ID used to store instance data 
				'data': {} // override any default data for the nested component
			};

			// find the nested component element on the page - matches the data-compid in the nestedComp "value" field 
			const ncElement = this.container.querySelector(`[data-compid='${nestedComp.id}']`)
			if (ncElement) {
				// now instantiate the nested component so that it renders correctly
				this.sitesSDK.instantiateNestedComponent(ncViewModel, ncElement);
			} else {
				console.log('unable to locate nested component: ', nestedComp);
			}
		};
	}

	// insert the component's HTML into the page 
	// after it has added the component, it applies any clickHandlers to elements that were added to the page
	renderComponent(args) {
		Promise.all([SCSRenderAPI.importText(this.assetsPath + '/template.html'),
			SCSRenderAPI.importCSS(this.assetsPath + '/styles/design.css')
		]).then((componentResources) => {
			const componentTemplate = componentResources[0];

			// use the common code to generate the HTML for this component based on the componentLayout and customSettingsData
			const componentHTML = CommonUtils.createHTML({
					Mustache: this.Mustache,
					componentLayout: this.sitesSDK.getProperty('componentLayout'),
					customSettingsData: this.sitesSDK.getProperty('customSettingsData'),
					id: this.id,
					template: componentTemplate,
					nestedComponents: this.nestedComponents // include any nested component definitions
				},
				args);


			// replace the content of the container with the rendered HTML
			this.container.innerHTML = componentHTML;

			// instantiate any nested components in the expanded view
			this.instantiateNestedComponents();

			// add in the click handlers
			this.addClickHandlers(this.container);
		});
	}

	// the hydrate method is called when a component has been compiled into the page at runtime 
	// this gives the opportunity to add any event handlers to the HTML that has been inserted into the page
	hydrate(container) {
		this.container = container;
		this.addClickHandlers(container);
	}

	// the render method is called to render the component dynamically onto the page 
	render(container) {
		this.container = container;
		this.renderComponent();
	}
}

