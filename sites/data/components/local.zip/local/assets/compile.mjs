/**
 * Copyright (c) 2022 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
 import fs from 'fs';
 import path from 'path';
 import { URL } from 'url';
 import CommonUtils from './common.mjs';
 import Mustache from 'mustache';
 
 
 // Custom Component Class
 export default class {
     constructor(args) {
         // Store the context information
         this.id = args.componentId;
         this.componentInstanceObject = args.componentInstanceObject;
         this.componentsFolder = args.componentsFolder;
         this.SCSCompileAPI = args.SCSCompileAPI;
 
         // store the data for the component
         this.compData = this.componentInstanceObject.data;
 
         // add in the nested components
         this.createNestedComponents();
     }
 
     // create the nested component definitions to be used when expanding the template and instantiating the nested components
     createNestedComponents() {
         // id: of the component - used to store nested component settings in the page data (referenced in 'value' property)
         // value: nested component entry inserted into the template, this will be expanded when the nested components are compiled
         this.nestedComponents = {
             image: {
                 id: 'imageId',  
                 value: '{{{imageId}}}' 
             },
             title: {
                 id: 'titleId',
                 value: '{{{titleId}}}'
             },
             paragraph: {
                 id: 'paragraphId',
                 value: '{{{paragraphId}}}'
             }
         };
     }
 
     // implement the compile() API to generate the HTML for the component
     compile(args) {
         return new Promise((resolve, reject) => {
             try {
                 // load up the template file
                 const dir = (new URL('.', import.meta.url)).pathname,
                     templateFile = path.join(dir, 'template.html'),
                     template = fs.readFileSync(templateFile, 'utf8');
 
                 // use the common code to generate the HTML for this component based on the componentLayout and customSettingsData
                 const componentHTML = CommonUtils.createHTML({
                     Mustache: Mustache,
                     componentLayout: this.compData.componentLayout,
                     customSettingsData: this.compData.customSettingsData,
                     id: this.id,
                     nestedComponents: this.nestedComponents,
                     template: template
                 });
 
                 // It is up to the developer to ensure the output from the compile.js:compile() function remains in sync with the render.js:render() function.
                 // To see what the default output would be, switch the following to true
                 if (true) {
                     // get all the nested component IDs
                     const nesetedCompIds = Object.keys(this.nestedComponents).map(key => this.nestedComponents[key].id);
 
                     // return the generated HTML and use hydrate in the render.js file to add any event handlers at runtime
                     return resolve({
                         hydrate: true,
                         content: componentHTML,
                         nestedIDs: nesetedCompIds // include nested component IDs so they can be compiled into the page
                     });
                 } else {
                     // warn the user that the compile function hasn't been implemented
                     console.log('Warning: the custom compile() function has not been implemented in: ' + import.meta.url);
 
                     // If the compile() function doesn't return any content, then the component will execute dynamically at runtime
                     return resolve({});
                 }
             } catch (e) {
                 console.log('Error: Failed to expand mustache template in: ' + import.meta.url, e);
                 return resolve({});
             }
         });
     }
 }