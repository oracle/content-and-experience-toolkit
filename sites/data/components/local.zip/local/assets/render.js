/**
 * Copyright (c) 2022 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
 define(['require'], function (require) {
	/**
	 * Component Factory for creating instances of the custom component
	 * 
	 * This is a generic AMD wrapper module for backwards compatibility. 
	 * It enables RequireJS dyanmic loading of JavaScript Module based custom components.
	 */
	return {
		createComponent: function (args, callback) {
			// import the module component
			import(require.toUrl('./render.mjs')).then(({
				default: ModuleComponent
			}) => {
				// return a new instance of the component
				callback(new ModuleComponent(args));
			}).catch((e) => {
				// typically this will be caused by syntax errors in the render.mjs file
				// make sure the render.mjs file can be imported directly
				console.error(e);
			});
		}
	};
});