/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global require, requirejs, baseTagObj,SitesSDK,define,alert,console,oj*/
/*jslint plusplus: true */
define([
	'jquery',
	'knockout',
	'CommonResources',
	'app-utils',
	'ojs/ojarraydataprovider',
	'settings-dependencies'
], function ($, ko, strings, appUtils, ArrayDataProvider) {
	'use strict';

	var devcsServer = window.location.hostname === 'localhost',
		defaultFolder = devcsServer ? 'home' : '',
		defaultFolderName = devcsServer ? 'Home' : '';

	var vm, SettingsViewModel,
		idcFolderItemsUri = devcsServer ? '/documents/web?IdcService=FLD_BROWSE_PERSONAL&IsJson=1&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]' : '/documents/web?IdcService=FLD_BROWSE&IsJson=1&items=fFolderGUID:[folder]&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]';

	SettingsViewModel = function () {
		var self = this,
			idcToken,
			siteGuid,
			pageId,
			siteVariantGUID;

		SitesSDK.getSiteProperty('siteInfo', function (propertyData) {
			var siteinfo = propertyData.siteInfo;
			JSON.stringify(siteinfo);
			idcToken = siteinfo.idcToken;
			siteGuid = siteinfo.siteGUID;
			pageId = siteinfo.pageId;
			siteVariantGUID = siteinfo.siteVariantGUID;
		});

		self.initialized = ko.observable(false);
		self.saveData = false;
		self.strings = strings;

		self.folderGuid = ko.observable('');
		self.folderName = ko.observable('');
		self.selectedFolderName = ko.observable('');

		self.publicLink = ko.observable('');
		self.errorMessage = ko.observable('');

		self.hybridLinkIndex = ko.observable(0);

		// folder access
		self.folderAccess = ko.observable('member');
		self.folderAccessValues = ko.observableArray([
			{
				value: 'member',
				label: strings.APP_PROJECT_LIBRARY_FOLDER_MEMBER
			},
			{
				value: 'downloader',
				label: strings.APP_PROJECT_LIBRARY_FOLDER_DOWNLOADER
			}
		]);
		self.folderAccessValuesDP = new ArrayDataProvider(self.folderAccessValues, {
			keyAttributes: 'value'
		});

		self.folderAccessValue = ko.computed({
			read: function () {
				return self.folderAccess();
			},
			write: function (value) {
				self.folderAccess(value);
				self.showConvoPane(self.folderAccess() === 'member');
			},
			owner: self
		});

		//Sort
		self.sortBy = ko.observable('nameasc');
		self.sortByValues = ko.observableArray([
			{
				value: 'nameasc',
				label: strings.APP_FOLDERFILE_NAME_ASC
			},
			{
				value: 'namedesc',
				label: strings.APP_FOLDERFILE_NAME_DSC
			}
		]);
		self.sortByValuesDP = new ArrayDataProvider(self.sortByValues, {
			keyAttributes: 'value'
		});

		// Convert sortBy observable to array observable for oj-select
		self.sortByValue = ko.computed({
			read: function () {
				return [self.sortBy()];
			},
			write: function (value) {
				self.sortBy(value[0]);
			},
			owner: self
		});

		//number of folders displayed
		self.shownum = ko.observable(5);
		//the min value of the folders displayed
		self.shownummin = ko.observable(1);
		self.shownummax = ko.observable(50);
		self.shownumstep = ko.observable(1);

		self.showNumOption = ko.observable('all');
		self.showNumOptionValues = ko.observableArray([
			{
				value: 'all',
				label: strings.APP_FOLDERLIST_SHOW_ALL_FOLDERS
			},
			{
				value: 'shownum',
				label: strings.APP_FOLDERLIST_SHOW_NUMBER_FOLDERS
			}
		]);
		self.showNumOptionValuesDP = new ArrayDataProvider(self.showNumOptionValues, {
			keyAttributes: 'value'
		});

		self.showNumIsAll = ko.computed(function () {
			if (self.showNumOption() === 'all') {
				self.shownum(5);
				return true;
			} else {
				return false;
			}
		});

		// default selection
		self.subFolders = ko.observableArray([]);
		self.subFoldersDP = new ArrayDataProvider(self.subFolders, {
			keyAttributes: 'value'
		});
		self.noSubFolder = ko.computed(function () {
			return (self.folderGuid() === '') &&
				(self.publicLink() === '');
		});

		self.defaultSelection = ko.observable('');

		self.isUpgrade = ko.computed(function () {
			if (self.publicLink() !== '') {
				//legacy public link case
				return true;
			} else {
				// member or hybrid link case
				return false;
			}
		});

		self.allowSetConvoPane = ko.computed(function () {
			return self.folderGuid() && self.folderAccess() === 'member';
		});

		// handle initialization of the viewModel
		self.init = function (customData) {

			self.config = {
				folderGuid: customData.hasOwnProperty('folderGuid') ? customData.folderGuid : defaultFolder,
				publiclink: customData.hasOwnProperty('publiclink') ? customData.publiclink : '',
				hybridLinkIndex: customData.hasOwnProperty('hybridLinkIndex') ? customData.hybridLinkIndex : 0,
				sortBy: customData.hasOwnProperty('sortBy') ? customData.sortBy : 'nameasc',
				pfname: customData.hasOwnProperty('pfname') ? customData.pfname : true,
				folderAccess: customData.hasOwnProperty('folderAccess') ? customData.folderAccess : 'downloader',
				showConvoPane: customData.hasOwnProperty('showConvoPane') ? customData.showConvoPane : true,
				shownum: customData.hasOwnProperty('shownum') ? customData.shownum : 5,
				showNumOption: customData.hasOwnProperty('showNumOption') ? customData.showNumOption : 'all',
				defaultSelection: customData.hasOwnProperty('defaultSelection') ? customData.defaultSelection : ''
			};


			self.folderGuid(self.config.folderGuid);

			self.hybridLinkIndex(self.config.hybridLinkIndex);

			self.folderAccess(self.hybridLinkIndex() === 0 ? 'member' : self.config.folderAccess);
			self.showConvoPane = ko.observable(self.folderAccess() !== 'member' ? false : self.config.showConvoPane);

			self.pfname = ko.observable(self.config.pfname);
			self.publicLink(self.config.publiclink);
			self.sortBy(self.config.sortBy);
			self.shownum(self.config.shownum);
			self.showNumOption(self.config.showNumOption);
			self.defaultSelection(self.config.defaultSelection);

			self.querySubFolders();

			//put save in ko.computed to do auto save
			self.save = ko.computed(function () {
				//save
				var saveconfig = {
					'folderGuid': self.folderGuid(),
					'publiclink': self.publicLink(),
					'hybridLinkIndex': self.hybridLinkIndex(),
					'defaultSelection': self.defaultSelection(),
					'sortBy': self.sortBy(),
					'pfname': self.pfname(),
					'folderAccess': self.folderAccess(),
					'showConvoPane': self.showConvoPane(),
					'shownum': self.shownum(),
					'showNumOption': self.showNumOption()
				};
				//dispatch config to app
				if (self.saveData) {
					SitesSDK.setProperty('componentAssets', self.assets);
					SitesSDK.setProperty('customSettingsData', saveconfig);
				}
			});


			//subscribe to requery folders when observables changes
			// requery sub folders when publiclink changes
			self.publicLink.subscribe(function (newValue) {
				self.defaultSelection('noselection');
				self.querySubFolders();
			});

			// requery sub folders when sorting changes
			self.sortBy.subscribe(function (newValue) {
				self.defaultSelection('noselection');
				self.querySubFolders();
			});

			// requery sub folders when switch between show all and show certain number
			self.showNumIsAll.subscribe(function (newValue) {
				self.defaultSelection('noselection');
				self.querySubFolders();
			});
			// requery sub folders when number of folders changes
			self.shownum.subscribe(function (newValue) {
				self.defaultSelection('noselection');
				self.querySubFolders();
			});

			// now viewModel has been initialized
			self.initialized(true);
			self.saveData = true;

		};

		// get the customSettings Data and init the viewModel
		// get the  hybridlink data and customSettings Data, then init the viewModel
		SitesSDK.getProperty('componentAssets', function (assets) {
			self.assets = assets;
			SitesSDK.getProperty('customSettingsData', self.init);
		});

		// Callback when a file is selected
		self.selectFolder = function (data) {
			if (data) {
				data.forEach(function (file) {
					var folderGuid = file.id,
						textArea;

					//convert to hybrid link selection and delete legacy public link data
					if (self.publicLink() !== '') {
						self.publicLink('');
					}

					self.folderGuid('folder/' + folderGuid);

					// unescape the file.name
					textArea = document.createElement('textarea');
					textArea.innerHTML = file.name;
					self.selectedFolderName(textArea.value);
					self.defaultSelection('noselection');
					appUtils.createHybridLink(siteGuid, pageId, siteVariantGUID, folderGuid, idcToken, self.onCreateHybridLinkSuccess, self.onCreateHybridLinkFailure);
					self.querySubFolders();

				});

			}
		};

		self.onCreateHybridLinkSuccess = function (data) {
			var dLinkID = data.LocalData.dLinkID,
				folderId = data.LocalData.fItemGUID,
				uniqueId = Math.floor(Math.random() * 1000),
				sourceURL = '/documents/embed/link/' + dLinkID + '/folder/' + folderId;

			//console.log('Hybrid Link created with dLinkID : ' + dLinkID);
			self.assets = [{
				id: uniqueId,
				title: self.selectedFolderName(),
				source: sourceURL,
				description: 'Hybrid link from Folder List',
				fileName: self.selectedFolderName()
			}];
			self.hybridLinkIndex(uniqueId);
			self.folderAccess('downloader');
			self.showConvoPane(false);
		};

		self.onCreateHybridLinkFailure = function (err) {
			console.log('Error creating hybrid link.error=' + err);
		};

		// bring up a file picker to select the folder
		self.showFilePicker = function () {
			// select folders
			SitesSDK.filePicker({
				'multiSelect': false,
				'foldersOnly': true,
				'category': 'documents',
				'location': self.folderGuid().replace('folder/', ''),
				'showReset': true
			}, function (folders) {
				self.selectFolder(folders);
			});
		};

	}; //end of view model

	SettingsViewModel.prototype.querySubFolders = function () {
		var self = this,
			folderId = self.folderGuid(),
			publiclink = self.publicLink(),
			sortBy = self.sortByValue().toString(),
			showAll = self.showNumIsAll(),
			shownumber = self.shownum(),
			updatedArray = [{
				value: 'noselection',
				label: strings.APP_FOLDERLIST_DEFAULT_SELECTION
			}],
			orderbyCol,
			orderby,
			uri,
			server,
			linkId,
			docWebUri;

		// default value when not set
		sortBy = sortBy || 'nameasc';

		if (folderId === '' && publiclink === '') {
			self.subFolders(updatedArray);
			return;
		}

		if (publiclink === '') {

			folderId = folderId.replace('folder/', '');

			// Sorting option
			orderbyCol = 'fItemName';
			orderby = sortBy === 'nameasc' ? 'Asc' : 'Desc';

			uri = idcFolderItemsUri.replace('[folder]', folderId);
			uri = uri.replace('[sortfield]', orderbyCol);
			uri = uri.replace('[sortorder]', orderby);

			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': uri,
				'success': function (data) {
					self.parseWebData('', '', folderId, data, showAll, shownumber);
				},
				'error': function (xhr, status, err) {
					//alert('status=' + status + ' err=' + err);
				}
			});
			self.errorMessage('');

		} else {

			server = publiclink.indexOf('/documents/') > 0 ? publiclink.substring(0, publiclink.indexOf('/documents/')) : '';
			linkId = publiclink.indexOf('/link/') > 0 ? publiclink.substring(publiclink.indexOf('/link/') + 6) : '';
			folderId = publiclink.indexOf('/folder/') > 0 ? publiclink.substring(publiclink.indexOf('/folder/') + 8) : '';
			if (linkId.indexOf('/') > 0) {
				linkId = linkId.substring(0, linkId.indexOf('/'));
			}
			if (folderId.indexOf('/') > 0) {
				folderId = folderId.substring(0, folderId.indexOf('/'));
			}
			if (server === '') {
				server = 'https://documents.us.oracle.com';
			}

			orderbyCol = 'fItemName';
			orderby = sortBy === 'nameasc' ? 'Asc' : 'Desc';

			docWebUri = '/documents/link/web' +
				'?dLinkID=' + linkId +
				'&item=fFolderGUID:' + folderId +
				'&IdcService=' + 'FLD_BROWSE' +
				'&doCombinedBrowse=1' +
				'&combinedCount=' + '999' +
				'&combinedStartRow=0' +
				'&combinedSortField=' + orderbyCol +
				'&combinedSortOrder=' + orderby;

			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docWebUri,
				'success': function (data) {
					self.parseWebData(server, linkId, folderId, data, showAll, shownumber);
					self.errorMessage('');
				},
				'error': function (xhr, status, err) {
					//alert('status=' + status + ' err=' + err);
					if (err.indexOf('Forbidden') >= 0) {
						self.errorMessage(strings.APP_FOLDERLIST_PUBLIC_LINK_NOT_ALLOWED);
					} else {
						self.errorMessage(strings.APP_FOLDERLIST_PUBLIC_LINK_INVALID);
					}
				}
			});
		}
	};

	SettingsViewModel.prototype.parseWebData = function (server, linkId, folderId, webData, showAll, shownumber) {
		var self = this,
			fFolderGUIDIdx,
			fFolderNameIdx,
			fields,
			total = 0,
			updatedArray = [{
				value: 'noselection',
				label: strings.APP_FOLDERLIST_DEFAULT_SELECTION
			}],
			i,
			idx,
			results;

		// get the folder info
		if (!devcsServer) {
			for (i = 0; i < webData.ResultSets.FolderInfo.fields.length; i++) {
				if (webData.ResultSets.FolderInfo.fields[i].name === 'fFolderName') {
					self.folderName(webData.ResultSets.FolderInfo.rows[webData.ResultSets.FolderInfo.currentRow][i]);
					break;
				}
			}
		} else {
			self.folderName(defaultFolderName);
		}

		// get the folder list
		fields = webData.ResultSets.ChildFolders.fields;
		for (i = 0; i < fields.length; i++) {
			if (fields[i].name === 'fFolderGUID') {
				fFolderGUIDIdx = i;
			} else if (fields[i].name === 'fFolderName') {
				fFolderNameIdx = i;
			}
		}

		results = webData.ResultSets.ChildFolders.rows;

		for (idx = 0; idx < results.length; idx++) {
			updatedArray.push({
				value: results[idx][fFolderGUIDIdx],
				label: results[idx][fFolderNameIdx]
			});
			total = total + 1;
			if (showAll === false && total === shownumber) {
				break;
			}
		}

		self.subFolders(updatedArray);
	};

	//create view model
	vm = new SettingsViewModel();
	// return the module
	return vm;

});
