/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs */
requirejs.config({
	baseUrl: '.',
	paths: {
		'knockout': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/knockout/knockout-3.5.1',
		'preact': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/preact/dist/preact.umd',
		'preact/hooks': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/preact/hooks/dist/hooks.umd',
		'preact/compat': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/preact/compat/dist/compat.umd',
		'preact/jsx-runtime': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/preact/jsx-runtime/dist/jsxRuntime.umd',
		'@oracle/oraclejet-preact': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/oraclejet-preact/amd',
		'jquery': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/jquery/jquery-3.6.1.min',
		'jqueryui-amd': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/jquery/jqueryui-amd-1.13.2.min',
		'ojs': 'https://static.oracle.com/cdn/jet/14.0.4' + '/default/js/min',
		'ojL10n': 'https://static.oracle.com/cdn/jet/14.0.4' + '/default/js/ojL10n',
		'ojtranslations': 'https://static.oracle.com/cdn/jet/14.0.4' + '/default/js/resources',
		'signals': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/js-signals/signals.min',
		'text': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/require/text',
		'hammerjs': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/hammer/hammer-2.0.8.min',
		'ojdnd': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/dnd-polyfill/dnd-polyfill-1.0.2.min',
		'touchr': 'https://static.oracle.com/cdn/jet/14.0.4' + '/3rdparty/touchr/touchr'
	}
});

requirejs(['jquery', 'knockout', './settings-vm'], function ($, ko, vm) {
	'use strict';
	ko.applyBindings(vm);
});
