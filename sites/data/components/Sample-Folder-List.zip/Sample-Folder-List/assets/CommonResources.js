/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define([], function() {
	'use strict';
	return {
	"APP_PROJECT_LIBRARY_FOLDER_ACCESS": "Select Folder Permission",
	"APP_PROJECT_LIBRARY_FOLDER_MEMBER": "Member Access",
	"APP_PROJECT_LIBRARY_FOLDER_VIEWER": "Site Visitor Access: Viewer",
	"APP_PROJECT_LIBRARY_FOLDER_DOWNLOADER": "Site Visitor Access: Downloader",
	"APP_PROJECT_LIBRARY_FOLDER_CONTRIBUTOR": "Site Visitor Access: Contributor",
	"APP_PROJECT_LIBRARY_FOLDER_MANAGER": "Manager",
	"APP_PROJECT_LIBRARY_SHOW_CONVERSATION_PANE": "Show side pane in Documents Manager",
	// file-list folder-list common
	"APP_FOLDERFILE_CHOOSEFOLDER": "Folder Selection",
	"APP_FOLDERFILE_FOLDERNAME_PLACEHOLDER": "No folder selected",
	"APP_FOLDERFILE_FOLDERINPUT_PLACEHOLDER": "Enter a public link URL for a folder",
	"APP_FOLDERFILE_NAME_ASC": "Name Ascending",
	"APP_FOLDERFILE_NAME_DSC": "Name Descending",
	"APP_FOLDERFILE_LAST_UPDATE_ASC": "Last Update Ascending",
	"APP_FOLDERFILE_LAST_UPDATE_DSC": "Last Update Descending",
	"APP_FOLDERFILE_SELECT": "Select",
	"APP_FOLDERFILE_FOLDER_PICKER": "Folder Picker",
	"APP_FOLDERFILE_BACK": "Back",
	"APP_FOLDERFILE_DOCUMENTS_FOLDER": "Oracle Documents Folder",
	"APP_FOLDERFILE_PUBLIC_URL": "Public Link",
	"APP_FOLDERFILE_PUBLIC_URL_ERMSG": "You can't use public links coming from a different Oracle Documents server (with a different URL).",
	"APP_FOLDERFILE_HYBRIDLINK_WARNING": "All site visitors can view and download the contents of this folder.",
	"APP_FOLDERFILE_UPGRADE_WARNING": "The selected folder uses an outdated type of link. Please click Select to update the folder link.",
	// folder-list and file list common messages - render
	"APP_FOLDERFILE_LAST_MODIFIED": "Last modified on {0} by {1}",
	"APP_FOLDERFILE_TRIGGER_DESCRIPTION": "Description",
	"APP_FOLDERFILE_TRIGGER_MIME_TYPE": "Mime Type",
	"APP_FOLDERFILE_TRIGGER_SIZE": "Size",
	"APP_FOLDERFILE_TRIGGER_AUTHOR": "Author",
	"APP_FOLDERFILE_TRIGGER_CREATED_TIME": "Created Time",
	"APP_FOLDERFILE_TRIGGER_MODIFIED_TIME": "Modified Time",
	// folder-list
	"APP_FOLDERLIST_DISPLAY_NAME": "Folder List",
	"APP_FOLDERLIST_DESCRIPTION": "Folders in Oracle Documents",
	"APP_FOLDERLIST_SHOW_ALL_FOLDERS": "Show All Folders",
	"APP_FOLDERLIST_SHOW_NUMBER_FOLDERS": "Show Limited Number of Folders",
	"APP_FOLDERLIST_HEADER": "Show folder name header",
	"APP_FOLDERLIST_SORTING": "Folder Sorting",
	"APP_FOLDERLIST_SUBFORLDERS": "Show Subfolders",
	"APP_FOLDERLIST_DEFAULT_SELECTION": "Choose Default Selection",
	"APP_FOLDERLIST_PUBLIC_LINK_NOT_ALLOWED": "Public links are not allowed",
	"APP_FOLDERLIST_PUBLIC_LINK_INVALID": "The public link URL is invalid",
	// folder-list - render
	"APP_FOLDERLIST_NO_FOLDER_TO_DISPLAY": "No Folders to Display",
	"APP_FOLDERLIST_TRIGGER_FOLDER_SELECTED": "Folder Selected",
	"APP_FOLDERLIST_TRIGGER_FOLDER_ID": "Folder Id",
	"APP_FOLDERLIST_TRIGGER_FOLDER_LINK": "Folder Link",
	"APP_FOLDERLIST_TRIGGER_FOLDER_NAME": "Folder Name"
	};
});
