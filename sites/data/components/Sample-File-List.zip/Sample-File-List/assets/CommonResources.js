/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define([], function() {
	'use strict';
	return {
	"APP_PROJECT_LIBRARY_FOLDER_ACCESS": "Select Folder Permission",
	"APP_PROJECT_LIBRARY_FOLDER_MEMBER": "Member Access",
	"APP_PROJECT_LIBRARY_FOLDER_VIEWER": "Site Visitor Access: Viewer",
	"APP_PROJECT_LIBRARY_FOLDER_DOWNLOADER": "Site Visitor Access: Downloader",
	"APP_PROJECT_LIBRARY_FOLDER_CONTRIBUTOR": "Site Visitor Access: Contributor",
	"APP_PROJECT_LIBRARY_FOLDER_MANAGER": "Manager",
	"APP_PROJECT_LIBRARY_SHOW_CONVERSATION_PANE": "Show side pane in Documents Manager",
	// file-list folder-list common
	"APP_FOLDERFILE_CHOOSEFOLDER": "Folder Selection",
	"APP_FOLDERFILE_FOLDERNAME_PLACEHOLDER": "No folder selected",
	"APP_FOLDERFILE_FOLDERINPUT_PLACEHOLDER": "Enter a public link URL for a folder",
	"APP_FOLDERFILE_NAME_ASC": "Name Ascending",
	"APP_FOLDERFILE_NAME_DSC": "Name Descending",
	"APP_FOLDERFILE_LAST_UPDATE_ASC": "Last Update Ascending",
	"APP_FOLDERFILE_LAST_UPDATE_DSC": "Last Update Descending",
	"APP_FOLDERFILE_SELECT": "Select",
	"APP_FOLDERFILE_FOLDER_PICKER": "Folder Picker",
	"APP_FOLDERFILE_BACK": "Back",
	"APP_FOLDERFILE_DOCUMENTS_FOLDER": "Oracle Documents Folder",
	"APP_FOLDERFILE_PUBLIC_URL": "Public Link",
	"APP_FOLDERFILE_PUBLIC_URL_ERMSG": "You can't use public links coming from a different Oracle Documents server (with a different URL).",
	"APP_FOLDERFILE_HYBRIDLINK_WARNING": "All site visitors can view and download the contents of this folder.",
	"APP_FOLDERFILE_UPGRADE_WARNING": "The selected folder uses an outdated type of link. Please click Select to update the folder link.",
	// folder-list and file list common messages - render
	"APP_FOLDERFILE_LAST_MODIFIED": "Last modified on {0} by {1}",
	"APP_FOLDERFILE_TRIGGER_DESCRIPTION": "Description",
	"APP_FOLDERFILE_TRIGGER_MIME_TYPE": "Mime Type",
	"APP_FOLDERFILE_TRIGGER_SIZE": "Size",
	"APP_FOLDERFILE_TRIGGER_AUTHOR": "Author",
	"APP_FOLDERFILE_TRIGGER_CREATED_TIME": "Created Time",
	"APP_FOLDERFILE_TRIGGER_MODIFIED_TIME": "Modified Time",
	// file-list
	"APP_FILELIST_DISPLAY_NAME": "File List",
	"APP_FILELIST_DESCRIPTION": "Files in Oracle Documents",
	"APP_FILELIST_SHOW_ALL_FILES": "Show All Files",
	"APP_FILELIST_SHOW_NUMBER_FILES": "Show Limited Number of Files",
	"APP_FILELIST_OPTIONS": "Display Options",
	"APP_FILELIST_HEADER": "Folder name header",
	"APP_FILELIST_FILE_DESCRIPTION": "File description",
	"APP_FILELIST_SEPARATORS": "File separators",
	"APP_FILELIST_DOWNLOAD_ICON": "Download icon",
	"APP_FILELIST_LAST_UPDATED": "Last updated",
	"APP_FILELIST_FILE_SIZE": "File size",
	"APP_FILELIST_IMAGE": "Image",
	"APP_FILELIST_ENABLE_TRIGGER": "Activate trigger when file is selected",
	"APP_FILELIST_ENABLE_AUTOWIRING": "Auto-refresh file list based on selection in folder list component",
	"APP_FILELIST_FILE_SORTING": "File Sorting",
	"APP_FILELIST_SHOW_FILES": "Show Files",
	"APP_FILELIST_TRIGGERS_ACTIONS": "Triggers & Actions",
	// file-list - render
	"APP_FILELIST_NO_FILES_TO_DISPLAY": "No Files to Display",
	"APP_FILELIST_TRIGGER_FILE_SELECTED": "File Selected - must be enabled in settings",
	"APP_FILELIST_TRIGGER_FILE_ID": "File Id",
	"APP_FILELIST_TRIGGER_FILE_LINK": "File Link",
	"APP_FILELIST_TRIGGER_FILE_PREVIEW_LINK": "File Preview Link",
	"APP_FILELIST_TRIGGER_FILE_NAME": "File Name",
	"APP_FILELIST_TRIGGER_TITLE": "Title",
	"APP_FILELIST_TRIGGER_FILE_OBJECT": "Selected File",
	"APP_FILELIST_ACTION_DISPLAY_FILES": "Display files",
	"APP_FILELIST_ACTION_DISPLAY_FOLDERID_OR_URL": "Folder Id or URL"
	};
});
