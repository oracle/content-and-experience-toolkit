/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs */
requirejs.config({
	'baseUrl': '.',

	paths: {
		'knockout': '../../../../node_modules/knockout/build/output/knockout-latest',
		'jquery': '../../../../node_modules/jquery/dist/jquery',
	},
	waitSeconds: 0
});

requirejs(['jquery', 'knockout', './render-vm'], function($, ko, vm) {
	'use strict';
	 ko.applyBindings(vm);
});
