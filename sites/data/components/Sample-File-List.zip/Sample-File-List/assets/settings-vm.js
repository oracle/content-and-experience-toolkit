/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global requirejs, baseTagObj,SitesSDK,define,console*/
define([
	'jquery',
	'knockout',
	'CommonResources',
	'app-utils',
	'ojs/ojarraydataprovider',
	'settings-dependencies'
], function ($, ko, strings, appUtils, ArrayDataProvider) {
	'use strict';

	var vm, SettingsViewModel;

	var defaultFolder = window.location.hostname === 'localhost' ? 'home' : '',
		defaultFolderName = window.location.hostname === 'localhost' ? 'Home' : '';

	SettingsViewModel = function () {
		var self = this,
			idcToken,
			siteGuid,
			pageId,
			siteVariantGUID;

		SitesSDK.getSiteProperty('siteInfo', function (propertyData) {
			var siteinfo = propertyData.siteInfo;
			JSON.stringify(siteinfo);
			idcToken = siteinfo.idcToken;
			siteGuid = siteinfo.siteGUID;
			pageId = siteinfo.pageId;
			siteVariantGUID = siteinfo.siteVariantGUID;
		});

		self.initialized = ko.observable(false);
		self.saveData = false;
		self.strings = strings;

		self.folderGuid = ko.observable('');
		self.publicLink = ko.observable('');
		self.hybridLinkIndex = ko.observable(0);

		// folder access
		self.folderAccess = ko.observable('member');
		self.folderAccessValues = ko.observableArray([
			{
				value: 'member',
				label: strings.APP_PROJECT_LIBRARY_FOLDER_MEMBER
			},
			{
				value: 'downloader',
				label: strings.APP_PROJECT_LIBRARY_FOLDER_DOWNLOADER
			}
		]);
		self.folderAccessValuesDP = new ArrayDataProvider(self.folderAccessValues, {
			keyAttributes: 'value'
		});

		self.folderAccessValue = ko.computed({
			read: function () {
				return self.folderAccess();
			},
			write: function (value) {
				self.folderAccess(value);
				self.showConvoPane(self.folderAccess() === 'member');
			},
			owner: self
		});

		//Sort
		self.sortBy = ko.observable('nameasc');
		self.sortByValues = ko.observableArray([
			{
				value: 'nameasc',
				label: strings.APP_FOLDERFILE_NAME_ASC
			},
			{
				value: 'namedesc',
				label: strings.APP_FOLDERFILE_NAME_DSC
			},
			{
				value: 'lastupdateasc',
				label: strings.APP_FOLDERFILE_LAST_UPDATE_ASC
			},
			{
				value: 'lastupdatedesc',
				label: strings.APP_FOLDERFILE_LAST_UPDATE_DSC
			}
		]);
		self.sortByValuesDP = new ArrayDataProvider(self.sortByValues, {
			keyAttributes: 'value'
		});

		//number of files displayed
		self.shownum = ko.observable(5);
		//the min value of the files displayed
		self.shownummin = ko.observable(1);
		self.shownummax = ko.observable(50);
		self.shownumstep = ko.observable(1);

		self.showNumOption = ko.observable('all');

		self.showNumOptionValues = ko.observableArray([
			{
				value: 'all',
				label: strings.APP_FILELIST_SHOW_ALL_FILES
			},
			{
				value: 'shownum',
				label: strings.APP_FILELIST_SHOW_NUMBER_FILES
			}
		]);
		self.showNumOptionValuesDP = new ArrayDataProvider(self.showNumOptionValues, {
			keyAttributes: 'value'
		});

		self.showNumIsAll = ko.computed(function () {
			if (self.showNumOption() === 'all') {
				self.shownum(5);
				return true;
			} else {
				return false;
			}
		});

		self.isUpgrade = ko.computed(function () {
			if (self.publicLink() !== '') {
				//legacy public link case
				return true;
			} else {
				// member or hybrid link case
				return false;
			}
		});

		self.allowSetConvoPane = ko.computed(function () {
			return self.folderGuid() && self.folderAccess() === 'member';
		});

		// handle initialization of the viewModel
		self.init = function (customData) {

			self.config = {
				folderGuid: customData.hasOwnProperty('folderGuid') ? customData.folderGuid : defaultFolder,
				folderName: customData.hasOwnProperty('folderName') ? customData.folderName : defaultFolderName,
				publiclink: customData.hasOwnProperty('publiclink') ? customData.publiclink : '',
				hybridLinkIndex: customData.hasOwnProperty('hybridLinkIndex') ? customData.hybridLinkIndex : 0,
				folderAccess: customData.hasOwnProperty('folderAccess') ? customData.folderAccess : 'downloader',
				showConvoPane: customData.hasOwnProperty('showConvoPane') ? customData.showConvoPane : true,
				sortBy: customData.hasOwnProperty('sortBy') ? customData.sortBy : 'nameasc',
				desc: customData.hasOwnProperty('desc') ? customData.desc : true,
				lastUpdated: customData.hasOwnProperty('lastUpdated') ? customData.lastUpdated : false,
				fsize: customData.hasOwnProperty('fsize') ? customData.fsize : false,
				fimg: customData.hasOwnProperty('fimg') ? customData.fimg : false,
				download: customData.hasOwnProperty('download') ? customData.download : true,
				separator: customData.hasOwnProperty('separator') ? customData.separator : true,
				pfname: customData.hasOwnProperty('pfname') ? customData.pfname : true,
				fautowiring: customData.hasOwnProperty('fautowiring') ? customData.fautowiring : true,
				fstrigger: customData.hasOwnProperty('fstrigger') ? customData.fstrigger : false,
				shownum: customData.hasOwnProperty('shownum') ? customData.shownum : 5,
				showNumOption: customData.hasOwnProperty('showNumOption') ? customData.showNumOption : 'all'
			};

			self.folderGuid(self.config.folderGuid);
			self.folderName = ko.observable(self.config.folderName);
			self.oldFolderName = ko.observable(self.config.folderName);

			self.hybridLinkIndex(self.config.hybridLinkIndex);

			self.folderAccess(self.hybridLinkIndex() === 0 ? 'member' : self.config.folderAccess);
			self.showConvoPane = ko.observable(self.folderAccess() !== 'member' ? false : self.config.showConvoPane);

			//options
			self.desc = ko.observable(self.config.desc);
			self.lastUpdated = ko.observable(self.config.lastUpdated);
			self.fsize = ko.observable(self.config.fsize);
			self.fimg = ko.observable(self.config.fimg);
			self.download = ko.observable(self.config.download);
			self.separator = ko.observable(self.config.separator);
			self.pfname = ko.observable(self.config.pfname);
			self.fautowiring = ko.observable(self.config.fautowiring);
			self.fstrigger = ko.observable(self.config.fstrigger);
			self.publicLink(self.config.publiclink);
			self.sortBy(self.config.sortBy);
			self.shownum(self.config.shownum);
			self.showNumOption(self.config.showNumOption);

			//put save in ko.computed to do auto save
			self.save = ko.computed(function () {
				//save
				var saveconfig = {
					'folderGuid': self.folderGuid(),
					'folderName': self.folderName(),
					'publiclink': self.publicLink(),
					'hybridLinkIndex': self.hybridLinkIndex(),
					'folderAccess': self.folderAccess(),
					'showConvoPane': self.showConvoPane(),
					'sortBy': self.sortBy(),
					'desc': self.desc(),
					'lastUpdated': self.lastUpdated(),
					'fsize': self.fsize(),
					'fimg': self.fimg(),
					'download': self.download(),
					'separator': self.separator(),
					'pfname': self.pfname(),
					'fautowiring': self.fautowiring(),
					'fstrigger': self.fstrigger(),
					'shownum': self.shownum(),
					'showNumOption': self.showNumOption()
				};
				//dispatch config to app
				if (self.saveData) {
					SitesSDK.setProperty('componentAssets', self.assets);
					SitesSDK.setProperty('customSettingsData', saveconfig);
				}
			});

			// now viewModel has been initialized
			self.initialized(true);
			self.saveData = true;
		};

		// get the  hybridlink data and customSettings Data, then init the viewModel
		SitesSDK.getProperty('componentAssets', function (assets) {
			self.assets = assets;
			SitesSDK.getProperty('customSettingsData', self.init);
		});


		// Callback when a file is selected
		self.selectFolder = function (data) {
			if (data) {
				data.forEach(function (file) {
					var folderGuid = file.id,
						textArea;

					//convert to hybrid link selection and delete legacy public link data
					if (self.publicLink() !== '') {
						self.publicLink('');
					}

					self.folderGuid('folder/' + folderGuid);

					// unescape the file.name
					textArea = document.createElement('textarea');
					textArea.innerHTML = file.name;
					self.folderName(textArea.value);

					appUtils.createHybridLink(siteGuid, pageId, siteVariantGUID, folderGuid, idcToken, self.onCreateHybridLinkSuccess, self.onCreateHybridLinkFailure);
				});

			}
		};

		self.onCreateHybridLinkSuccess = function (data) {
			var dLinkID = data.LocalData.dLinkID,
				folderId = data.LocalData.fItemGUID,
				uniqueId = Math.floor(Math.random() * 1000),
				sourceURL = '/documents/embed/link/' + dLinkID + '/folder/' + folderId;

			//console.log('Hybrid Link created with dLinkID : ' + dLinkID);
			self.assets = [{
				id: uniqueId,
				title: self.folderName(),
				source: sourceURL,
				description: 'Hybrid link from Folder List',
				fileName: self.folderName()
			}];
			self.hybridLinkIndex(uniqueId);
			self.folderAccess('downloader');
			self.showConvoPane(false);
		};

		self.onCreateHybridLinkFailure = function (err) {
			console.log('Error creating hybrid link.error=' + err);
		};

		// bring up a file picker to select the folder
		self.showFilePicker = function () {
			// select folders
			SitesSDK.filePicker({
				'multiSelect': false,
				'foldersOnly': true,
				'category': 'documents',
				'location': self.folderGuid().replace('folder/', ''),
				'showReset': true
			}, function (folders) {
				self.selectFolder(folders);
			});
		};

	}; //end of view model

	//create view model
	vm = new SettingsViewModel();
	// return the module
	return vm;
});
