/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define */
define(['knockout', 'jquery', 'css!./styles/design.css', 'text!./comptemplate.html'], function (ko, $, css, comptemplate) {
	'use strict';


	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var OPACompViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		self.server = ko.observable('');
		self.interviewName = ko.observable('');

		// handle initialization 
		self.initialized = ko.observable(false);

		// used for inline properties
		self.interviewId = 'scs-opa-' + self.id;
		self.interviewDivId = self.id + '_InterviewDiv';

		self.redisplay = ko.observable(true);

		self.isEmbed = ko.computed(function () {
			return true;
		}, self);

		// style extension object
		self.opaStyle = {};
		self.getOPAStyles = function () {
			var designPath = SCSRenderAPI.getThemeDesignUrlPrefix(),
				elements = [
					'interviewContent',
					'screenTitleBlock',
					'screenTitle',
					'nextButton',
					'backButton',
					'restartButton',
					'exitButton',
					'header',
					'footer',
					'question',
					'control',
					'label',
					'controlError',
					'controlErrorText',
					'textInput',
					'textAreaInput',
					'calendarInput',
					'dropDownInput',
					'filterDropDownInput',
					'listInput',
					'radioInput',
					'checkboxInput',
					'autoCompleteInput',
					'captchaInput',
					'signatureInput',
					'explanationHeader',
					'explanationText',
					'signatureClearButton',
					'uploadAddButton',
					'entityRemoveButton'
				],
				elementName,
				styles = {},
				i;

			console.log('designPath=' + designPath);
			if (designPath) {
				$.ajax({
					url: designPath,
					dataType: "text",
					async: false,
					success: function (cssText) {
						// cssText will be a string containing the text of the file
						for (i = 0; i < elements.length; i += 1) {
							elementName = elements[i];
							if (cssText.indexOf('scs-opainterview-' + elementName) >= 0) {
								styles[elementName] = {
									className: 'scs-opainterview-' + elementName
								};
							}
						}
						// check for scs-opainterview-interview
						if (cssText.indexOf('scs-opainterview-interview ') >= 0 ||
							cssText.indexOf('scs-opainterview-interview{') >= 0) {
							styles['interview'] = {
								className: 'scs-opainterview-interview'
							};
						}
					}
				});
			}

			self.opaStyle = styles;
			console.log('opaStyle=' + JSON.stringify(self.opaStyle));
		};
		self.getOPAStyles();

		self.getOPAServer = function () {
			if (!self.server()) {
				var serverUrl = '',
					enabled = '',
					docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=OPA',
					appInfo,
					i,
					start = 0;

				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': docsConfigUrl,
					async: false,
					'success': function (data) {
						appInfo = data.ResultSets.AFApplicationInfo;
						if (appInfo) {
							for (i = 0; i < appInfo.fields.length; i += 1) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}
								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
					},
					'error': function (xhr, status, err) {
						console.log('getOPAServer: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
					}
				});
				self.server(serverUrl);
			}
		};
		self.getOPAServer();

		// load OPA library and display the interview
		self.getOPALibrary = function () {
			if (self.server() && self.interviewName() && self.isEmbed()) {
				var opaServer = self.server();
				require(['css!' + opaServer + '/web-determinations/staticresource/interviews.css', 'css!' + opaServer + '/web-determinations/staticresource/fonts/fonts.css', opaServer + '/web-determinations/staticresource/interviews.js'],
					function (opacss, opafont, opajs) {
						self.inlineOPA();
					});
			}
		};
		self.getOPALibrary();

		self.reRender = function () {
			self.redisplay(false);
			self.redisplay(true);
		};

		// Interview changes, remove the previous one then display the new interview
		self.interviewName.subscribe(function (newValue) {
			self.reRender();
		});

		self.opaVisible = ko.computed(function () {
			return self.redisplay();
		});

		self.hasVisualData = ko.computed(function () {
			return self.isEmbed() && self.server() && self.interviewName();
		});

		self.inlineOPA = function () {
			var el = document.getElementById(self.interviewDivId),
				deploymentName = self.interviewName(),
				webDeterminationsUrl = self.server() + '/web-determinations';
			if (el && deploymentName && webDeterminationsUrl) {
				el.innerHTML = "";
				console.log('show interview: ' + deploymentName);
				OraclePolicyAutomation.AddExtension({
					style: self.opaStyle
				});
				OraclePolicyAutomationEmbedded.StartInterview(el, webDeterminationsUrl, deploymentName);
			} else {
				console.log('opainterview: inlineOPA: Div not found');
			}
		};

		// redisplay the interview
		self.opaVisible.subscribe(function (newValue) {
			if (newValue && self.isEmbed()) {
				self.getOPALibrary();
			}
		});

		// execute action handler
		self.executeActionsListener = function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;
		};

		// 
		// Handle property changes
		//
		self.updateCustomSettingsData = $.proxy(function (customData) {
			var name = customData && customData.interviewName || '';
			self.interviewName(name);
			self.initialized(true);
		}, self);
		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		// listen for the EXECUTE ACTION request to handle custom actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeActionsListener, self));
		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));

		//
		// Initialize customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);
	};


	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var OPACompImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	OPACompImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	OPACompImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new OPACompViewModel(args);
	};
	// create the template based on the initial values
	OPACompImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			comptemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	OPACompImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);

		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var OPACompFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new OPACompImpl(args));
		}
	};
	return OPACompFactory;
});
