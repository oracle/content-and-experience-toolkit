/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define, console */
define(['knockout', 'jquery', 'css!./styles/design.css', 'text!./template.html'], function(ko, $, css, sampleComponentTemplate) {
	'use strict';
	// ----------------------------------------------
	// Define a Knockout Template for your component
	// ----------------------------------------------
	// ./template.html contains the template

	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var SampleComponentViewModel = function(args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		// create the observables for passing data
		self.type = ko.observable('Chart');
		self.height = ko.observable(300);
		self.width = ko.observable(400);
		self.chartWidgetId = ko.observable('YOUR_CHART_WIDGET_ID');
		self.watchListWidgetId = ko.observable('YOUR_WATCHLIST_WIDGET_ID');
		self.tickerListWidgetId = ko.observable('YOUR_TICKER_WIDGET_ID');
		var ids = {
			'Chart': self.chartWidgetId(),
			'Watchlist': self.watchListWidgetId(),
			'Ticker': self.tickerListWidgetId()
		};

		self.isWidgetIdSpecified = function() {
			return !isNaN(parseInt(ids[self.type()], 10));
		};
		self.url = ko.computed(function() {


			if (self.isWidgetIdSpecified()) {
				return 'https://widgets.tc2000.com/WidgetServer.ashx?id=' + ids[self.type()];
			}
		});

		// handle initialization 
		self.customSettingsDataInitialized = ko.observable(false);
		self.initialized = ko.computed(function() {
			return self.customSettingsDataInitialized();
		}, self);

		self.updateCustomSettingsData = $.proxy(function(customData) {

			if (!customData) {
				return;
			}
			//update observable
			if (customData.type) {
				self.type(customData.type);
			}
			if (customData.height) {
				self.height(customData.height);
			}

			if (customData.width) {
				self.width(customData.width);
			}
			self.customSettingsDataInitialized(true);
		}, self);

		self.updateSettings = function(settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};


		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));


		// listen for COPY_CUSTOM_DATA request
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.COPY_CUSTOM_DATA, $.proxy(self.copyComponentCustomData, self));

		// listen for PASTE_CUSTOM_DATA request
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.PASTE_CUSTOM_DATA, $.proxy(self.pasteComponentCustomData, self));

		//
		// Initialize the customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);
	};

	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var SampleComponentImpl = function(args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	SampleComponentImpl.prototype.init = function(args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	SampleComponentImpl.prototype.createViewModel = function(args) {
		// create the viewModel
		this.viewModel = new SampleComponentViewModel(args);
	};
	// create the template based on the initial values
	SampleComponentImpl.prototype.createTemplate = function(args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			sampleComponentTemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	SampleComponentImpl.prototype.setupCallbacks = function() {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function(container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);
		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function() {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var sampleComponentFactory = {
		createComponent: function(args, callback) {
			// return a new instance of the component
			return callback(new SampleComponentImpl(args));
		}
	};
	return sampleComponentFactory;
});
