/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * @preserve Copyright (c) 2020, 2022, Oracle and/or its affiliates.
 */

// setup RequireJS
var JET_CDN = "https://static.oracle.com/cdn/jet/12.1.1";
require.config({
	paths: {
		// Oracle JET
		"jqueryui-amd": JET_CDN + "/3rdparty/jquery/jqueryui-amd-1.13.0.min",
		"ojs": JET_CDN + "/default/js/min",
		"ojtranslations": JET_CDN + "/default/js/resources",
		"css-builder": JET_CDN + "/3rdparty/require-css/css-builder",
		"normalize": JET_CDN + "/3rdparty/require-css/normalize",
		"preact": JET_CDN + "/3rdparty/preact/dist/preact.umd",
		"preact/hooks": JET_CDN + "/3rdparty/preact/hooks/dist/hooks.umd",
		"preact/compat": JET_CDN + "/3rdparty/preact/compat/dist/compat.umd",
		"proj4": JET_CDN + "/3rdparty/proj4js/dist/proj4",
		"knockout": JET_CDN + "/3rdparty/knockout/knockout-3.5.1",
		"jquery": JET_CDN + "/3rdparty/jquery/jquery-3.6.0.min",
		"hammerjs": JET_CDN + "/3rdparty/hammer/hammer-2.0.8.min",
		"ojdnd": JET_CDN + "/3rdparty/dnd-polyfill/dnd-polyfill-1.0.2.min",
		"ojL10n": JET_CDN + "/default/js/debug/ojL10n",
		"signals": JET_CDN + "/3rdparty/js-signals/signals.min",
		"text": JET_CDN + "/3rdparty/require/text",
		"css": JET_CDN + "/3rdparty/require-css/css.min",
		"customElements": JET_CDN + "/3rdparty/webcomponents/custom-elements.min",
		"touchr": JET_CDN + "/3rdparty/touchr/touchr",
		"corejs": JET_CDN + "/3rdparty/corejs/shim.min",
	},
	shim: {
		shim: {
			jquery: {
				exports: ["jQuery", "$"]
			}
		}
	}
});

// run the app
require([
	'knockout',
	'./utils',
	'ojs/ojbootstrap',
	'ojs/ojmodel',
	'ojs/ojcollectiontreedatasource',
	'ojs/ojformlayout',
	'ojs/ojinputtext',
	'ojs/ojlabel',
	'ojs/ojknockout',
	'ojs/ojtreeview'
], function (ko, TranslationUtils, Bootstrap, Model, CollectionTreeDataSource) {
	var initEditor = function (sdk) {
		var utils = new TranslationUtils(sdk);

		// get all the items to be translated
		utils.getSelectedItems().then(function (selectedItems) {
			utils.getAllItems(selectedItems).then(function (contentItems) {
				function TreeViewModel() {
					var ContentItem = Model.Model.extend({
						idAttribute: 'id'
					});

					var addedItems = []; // only show items once, even if referenced in several places

					function addItemsToCollection(items, collection) {
						items.forEach(function (id) {
							contentItems.forEach(function (contentItem) {
								if (contentItem.id === id) {
									var isNewItem = addedItems.indexOf(id) === -1,
										isContentItem = contentItem.type !== "DigitalAsset";

									// only add if an item we haven't seen and it's a content item
									if (isNewItem && isContentItem) {
										collection.add(contentItem);
										addedItems.push(id);
									}
								}
							});
						});
					}

					function getChildCollection(rootCollection, model) {
						// Create a collection for the selected items
						var siCollection = new Model.Collection(null, {
							model: ContentItem
						});

						if (model === null) {
							// Root collection, add all the selected items
							addItemsToCollection(selectedItems, siCollection);
						} else {
							// find the referenced item
							var parentItem = contentItems.filter(function (item) {
								return item.id === model.id;
							})[0];

							if (parentItem) {
								// add in all the dependencies
								addItemsToCollection(parentItem.dependencies.map(function (item) {
									return item.id;
								}), siCollection);
							}
						}

						return siCollection;
					}

					function parseMetadata(model) {
						function getChildContentItems() {
							return model.attributes.dependencies.filter(function (dependentItem) {
								if (addedItems.indexOf(dependentItem.id) !== -1) {
									// already added, don't add again
									return false;
								} else {
									return contentItems.filter(function (item) {
										return (item.type !== 'DigitalAsset' && dependentItem.id === item.id);
									}).length !== 0;
								}
							});
						}

						var retObj = {};
						retObj.key = model.id;
						retObj.leaf = getChildContentItems().length === 0;
						retObj.depth = 0;
						return retObj;
					}

					this.dataSource = new CollectionTreeDataSource({
						root: getChildCollection(null, null),
						parseMetadata: parseMetadata,
						childCollectionCallback: getChildCollection
					});

					this.connectorJobId = sdk.properties.connector.jobId;
				}
				Bootstrap.whenDocumentReady().then(
					function () {
						ko.applyBindings(new TreeViewModel(), document.getElementById('componentDemoContent'));
					});
			});
		});
	};

	// initialize the SDK and render the editor
	window.translationEditorSDK.initSDK(initEditor);
});
