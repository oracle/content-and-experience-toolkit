/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * @preserve Copyright (c) 2020, 2022, Oracle and/or its affiliates.
 */

define(['jquery'], function ($) {
	var TranslationJobUtils = function (SDK) {
		this.SDK = SDK;
		this.translationJob = this.SDK.properties.translationJob;
		this.connector = this.SDK.properties.connector;
	};

	function beforeSend(xhr) {
		// use current permissions
		// check for override in localStorage in format:  <user>:<password>
		var userCredentials = window.localStorage.getItem('TranslationCredentials');

		// use custom permissions
		if (userCredentials) {
			xhr.setRequestHeader("Authorization", "Basic " + btoa(userCredentials));
		} else {
			xhr.setRequestHeader("Authorization", "session");
		}
	}

	TranslationJobUtils.prototype.getAllItems = function (selectedItems) {
		var self = this;
		return new Promise(function (resolve, reject) {
			if ((selectedItems || []).length === 0) {
				return resolve([]);
			}

			//  get all the dependencies that will have been included
			var url = "/content/management/api/v1.1/bulkItemsOperations";

			var payload = {
				operations: {
					validatePublish: {
						channels: [],
						validation: {
							verbosity: "normal"
						}
					}
				},
				q: 'id eq "' + selectedItems.join('" OR id eq "') + '"'
			};

			$.ajax({
				"url": url,
				"method": "POST",
				"dataType": "json",
				"processData": false,
				"contentType": "application/json",
				"beforeSend": beforeSend,
				"data": JSON.stringify(payload),
				"success": function (response) {
					var validatePublish = response.operations && response.operations.validatePublish,
						validationResults = validatePublish && validatePublish.validationResults,
						policyValidation = validationResults && validationResults.length > 0 &&
                        validationResults[0].policyValidation,
						items = policyValidation && policyValidation.items || [];
					resolve(items);
				},
				"error": function (jqXHR, textStatus, errorThrown) {
					resolve({
						selectedItems: selectedItems,
						allItems: []
					});
				}
			});
		});
	};

	TranslationJobUtils.prototype.getSelectedItems = function () {
		// Note:  
		//  This is just a sample to show a working UI.  
		//  The results here may not be what was added to the zip file since the items may have been updated since the translation job was created.
		//  You will need to query back these values from the job.json file within the zip file sent to your connector
		var self = this;
		return new Promise(function (resolve, reject) {
			if ((self.translationJob.type === 'assets') && (self.translationJob.data.properties.collectionId)) {
				var url = '/content/management/api/v1.1/items?limit=10000&totalResults=true&q=(collections co "' + self.translationJob.data.properties.collectionId + '")';
				$.ajax({
					"url": url,
					"method": "GET",
					"beforeSend": beforeSend,
					"success": function (response) {
						resolve((response.items || []).map(function (item) {
							return item.id;
						}));
					},
					"error": function (jqXHR, textStatus, errorThrown) {
						resolve([]);
					}
				});
			} else if (self.translationJob.type === 'assets') {
				return resolve(self.translationJob.data.properties.contentIds);
			} else {
				console.log("Sample Translation UI: ToDo - Add in query to get all selected items in a site's publishing job");
				return resolve([]);
			}
		});
	};

	return TranslationJobUtils;
});