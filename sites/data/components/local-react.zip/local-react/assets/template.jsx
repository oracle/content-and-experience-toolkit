import React from 'https://esm.sh/react';

export default function Template(props) {
	return (
		<div className="sample-react-component">
			{props.showStoryLayout ?
				(props.alignImageRight
					? <div className="scs-story-layout">
						<Paragraph {...props} />
						<Image {...props} />
					</div>
					: <div className="scs-story-layout">
						<Image {...props} />
						<Paragraph {...props} />
					</div>)
				: ''}
			{props.showTopLayout ?
				(<div>
					<Image {...props} />
					<Paragraph {...props} />
				</div>) : ''}
		</div>
	)
}

function Paragraph(props) {
	return (
		<div style={props.paragraphStyle}>
			<div className="scs-title-text">
				<div>{props.titleText}</div>
			</div>
			<div className="scs-paragraph-text">
				<p dangerouslySetInnerHTML={{ __html: props.paragraphText }}></p>
			</div>
			<Link {...props} />
		</div>
	)
}

function Link(props) {
	return (<>
		{props.linkText ? <a target="_blank" href={props.linkURL}><span>{props.linkText}</span></a> : ''}
	</>)
}

function Image(props) {
	return (
		<div style={props.imageStyle} data-layout={props.alignImage}>
			<div className="scs-image-container">
				<img id={props.imageId} className="scs-image-image" src="/_sitescloud/renderer/app/sdk/images/sample-image.png" alt="" title="" />
			</div>
		</div>
	)
}
