/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */
/**
 * Router handling /api/lsp requests
 */
/**
 * @ignore
 */
var express = require('express'),
	mockServer = require('./mockLspServer.js'),
	router = express.Router();


var doRequest = function (handler, req, res) {
	console.log('*** Mock LSP Server: ' + handler + ' - ' + req.url);

	try {
		var callResult = mockServer[handler]({
			bearerToken: req.bearerToken,
			params: req.params,
			data: req.body
		});

		if (callResult) {
			res.setHeader('Content-Type', 'application/json');
			res.end(JSON.stringify(callResult));
		} else {
			res.writeHead(404, '*** Mock LSP Server: Failed to call api - ' + handler);
			res.end();
		}
	} catch (e) {
		var errorCode = e && e.errorCode || 500,
			errorMessage = e && e.errorMessage || JSON.stringify(e);

		res.writeHead(errorCode, errorMessage);
		res.end();
	}
};

//
// GET requests
//
router.get('/lsp/rest/api/v1/community', (req, res) => {
	doRequest('getCommunity', req, res);
});
router.get('/lsp/rest/api/v1/workflows', (req, res) => {
	doRequest('getWorkflows', req, res);
});
router.get('/lsp/rest/api/v1/project/:projectId/status', (req, res) => {
	doRequest('getProjectStatus', req, res);
});
router.get('/lsp/rest/api/v1/project/:projectId', (req, res) => {
	doRequest('getProject', req, res);
});
router.get('/lsp/rest/api/v1/project', (req, res) => {
	doRequest('getProjects', req, res);
});
router.get('/lsp/rest/api/v1/document/:documentId/translation/:locale', (req, res) => {
	doRequest('getDocumentTranslation', req, res);
});
router.get('/lsp/rest/api/v1/document/:documentId', (req, res) => {
	doRequest('getDocument', req, res);
});

// handle unsuported GET requests
router.get('/*', (req, res) => {
	console.log('*** Mock LSP Server GET: ' + req.url);
	res.writeHead(404, "Unsupported API");
	res.end();
});

//
// POST requests
//
router.post('/lsp/rest/api/v1/document', (req, res) => {
	doRequest('createDocument', req, res);
});
router.post('/lsp/rest/api/v1/project', (req, res) => {
	doRequest('createProject', req, res);
});
router.post('/lsp/rest/api/v1/document/:documentId/translation', (req, res) => {
	doRequest('translateDocument', req, res);
});

// handle unsuported POST requests
router.post('/*', (req, res) => {
	console.log('*** Mock LSP Server POST: ' + req.url);
	res.writeHead(404, "Unsupported API");
	res.end();
});

// Export the router
module.exports = router;