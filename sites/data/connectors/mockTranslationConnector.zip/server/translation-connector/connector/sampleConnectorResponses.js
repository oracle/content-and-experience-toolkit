/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */


var mustache = require('mustache');


var defaultModel = {
    "authenticationType": "{{authenticationType}}",
    "connectorAbout": "{{connectorAbout}}",
    "connectorPickerType": "{{connectorPickerType}}",
    "connectorServiceProviderName": "{{connectorServiceProviderName}}",
    "locale": "{{locale}}",
    "localizedConnectorAbout": "{{localizedConnectorAbout}}",
    "localizedConnectorName": "{{localizedConnectorName}}"
};

var responses = {
    "GET": {
        "/v1/server": {
            "name": "{{connectorName}}",
            "nameLocalizations": [{
                "locale": "{{locale}}",
                "localizedString": "{{{localizedConnectorName}}}"
            }],
            "version": "{{connectorVersion}}",
            "about": "{{{connectorAbout}}}",
            "aboutLocalizations": [{
                "locale": "{{locale}}",
                "localizedString": "{{{localizedConnectorAbout}}}"
            }],
            "authenticationType": "{{authenticationType}}",
            "pickerType": "NONE",
            "enableMultiUserCopyBack": false,
            "maxUploadSize": 1073741824,
            "fields": [{
                    "ID": "ProxyHost",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "HTTP Proxy Hostname",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "HTTP Proxy Hostname"
                    }],
                    "description": "The HTTP proxy hostname, leave blank to disable.",
                    "descriptionLocalizations": [{
                        "locale": "en",
                        "localizedString": "The HTTP proxy hostname, leave blank to disable."
                    }],
                    "required": false
                },
                {
                    "ID": "ProxyPort",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "HTTP Proxy Port",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "HTTP Proxy Port"
                    }],
                    "description": "The HTTP proxy port number, leave blank to default to port 80.",
                    "descriptionLocalizations": [{
                        "locale": "en",
                        "localizedString": "The HTTP proxy port number, leave blank to default to port 80."
                    }],
                    "required": false
                },
                {
                    "ID": "ProxyScheme",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "HTTP Proxy Scheme",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "HTTP Proxy Scheme"
                    }],
                    "description": "The HTTP proxy scheme, leave blank to default to http.",
                    "descriptionLocalizations": [{
                        "locale": "en",
                        "localizedString": "The HTTP proxy scheme, leave blank to default to http."
                    }],
                    "required": false
                },
                {
                    "ID": "BearerToken",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "Bearer Token",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "Bearer Token"
                    }],
                    "description": null,
                    "descriptionLocalizations": [],
                    "required": true
                },
                {
                    "ID": "WorkflowId",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "Workflow Id",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "Bearer Token"
                    }],
                    "description": null,
                    "descriptionLocalizations": [],
                    "required": true
                },
                {
                    "ID": "AdditionalData",
                    "datatype": "STRING",
                    "siteSettable": true,
                    "userSettable": false,
                    "connectorSettable": false,
                    "authorizationURLParameter": false,
                    "label": "Additional Data",
                    "labelLocalizations": [{
                        "locale": "en",
                        "localizedString": "Additional Data"
                    }],
                    "description": null,
                    "descriptionLocalizations": [],
                    "required": true
                }

            ],
            "supportedConnectorTypes": ["TRANSLATION"],
            "connectorType": "TRANSLATION",
            "proprietorName": "",
            "serviceProviderName": "{{connectorServiceProviderName}}",
            "nativeAppInfos": null
        },
        "/v1/job": {
            "properties": {
                "title": "Jobs",
                "limit": 10,
                "total": 3,
                "offset": 0,
                "size": 3
            },
            "entities": [{
                    "properties": {
                        "creation_date": 1535404704229,
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{jobName1}}",
                        "id": "{{jobId1}}"
                    }
                },
                {
                    "properties": {
                        "creation_date": 1535404704229,
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{jobName2}}",
                        "id": "{{jobId2}}"
                    }
                },
                {
                    "properties": {
                        "creation_date": 1535404704229,
                        "community_id": "{{communityId}}",
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{jobName3}}",
                        "id": "{{jobId3}}"
                    }
                }
            ]
        },
        "/v1/job/{{jobId}}": {
            "properties": {
                "creation_date": 1553213135982,
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "callback_url": null,
                "status": "{{jobStatus}}",
                "statusMessage": "{{jobStatusMessage}}",
                "progress": "{{jobProgress}}",
                "title": "{{jobTitle}}",
                "id": "{{jobId}}",
                "projectId": "{{projectId}}"
            }
        }
    },
    "POST": {
        "/v1/job": {
            "properties": {
                "creation_date": 1553213135982,
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "status": "CREATED",
                "progress": "0",
                "callback_url": null,
                "title": "{{jobName}}",
                "id": "{{jobId}}",
                "projectId": "{{projectId}}"
            }
        },
        "/v1/job/{{jobId}}/translate": {
            "properties": {
                "creation_date": 1553213135982,
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "callback_url": null,
                "status": "{{jobStatus}}",
                "title": "{{jobTitle}}",
                "id": "{{jobId}}",
                "projectId": "{{projectId}}"
            }
        },
        "/v1/job/{{jobId}}/refreshTranslation": {
            "properties": {
                "creation_date": 1553213135982,
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "callback_url": null,
                "status": "{{jobStatus}}",
                "progress": "{{jobProgress}}",
                "title": "{{jobTitle}}",
                "id": "{{jobId}}",
                "projectId": "{{projectId}}"
            }
        }
    }
};
var RESPONSE_TEMPLATE = JSON.stringify(responses);

var MockResponses = function () {};

// Format the response for the URL request
// Applies the model to the response to insert expected values
// callType:  [ GET | POST ]
// url:  e.g. "/document/6a6ee468-33f3-4c8d-ae54-e755400e66d4/translation":"
// model: e.g. { "documentId": "6a6ee468-33f3-4c8d-ae54-e755400e66d4", "localeCode": "fr-FR", "documentStatus": "COMPLETE", "percentComplete": 100 }
MockResponses.prototype.formatResponse = function (callType, url, model) {
    var response;
    try {
        // update the default model with the included values
        var templateModel = JSON.parse(JSON.stringify(defaultModel));
        Object.keys(model).forEach(function (key) {
            templateModel[key] = model[key];
        });

        // apply the combined model to the template
        var mockResponses = mustache.render(RESPONSE_TEMPLATE, templateModel);

        // get the requested response
        var responses = JSON.parse(mockResponses)[callType.toUpperCase()];
        response = responses[url];
    } catch (e) {
        // log error
        console.log(e);
    }

    // handle the response
    if (response) {
        return response;
    } else {
        var errorMessage = "mockResponses.getResponse(): Unable to create response for request - " + url;
        console.log(errorMessage);
        throw ({
            errorCode: 400,
            errorMessage: errorMessage
        });
    }
};

// Export the mock responses
module.exports = new MockResponses();