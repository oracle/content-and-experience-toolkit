/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */

var request = require('request'),
	translationProviderApi = require('./translationProvider').api;

//
// NOTE: re-implement this object based on server and API requirements
//
var port = process.env.CECLSP_PORT || 8084,
	mockServerPrefix = 'http://localhost:' + port + '/lsp/rest/api/v1',
	urls = {
		COMMUNITY: mockServerPrefix + '/community',
		PROJECT: mockServerPrefix + '/project',
		DOCUMENT: mockServerPrefix + '/document',
		WORKFLOW: mockServerPrefix + '/workflow'
	};


/**
 * Implementation of calls to the Translation Provider interface for the "MockServer".</br>
 * You will need to create the corresponding implementation for your Language Service Provider.
 * @constructor
 * @alias MockTranslationProvider
 * @augments TranslationProviderInterface
 */
var MockTranslationProvider = function () {};
MockTranslationProvider.prototype = Object.create(translationProviderApi.prototype);

/** @inheritdoc */
MockTranslationProvider.prototype.addDocument = function (projectId, authToken, name, content, sourceLocale, additionalData) {
	var self = this,
		error = '';

	if (!projectId || !authToken, !name || !content || !sourceLocale) {
		// invalid parameters
		error = 'MockTranslationProvider.addDocument(): required parameters: projectId, authToken, name, content';
	} else {
		// validate content is JSON & not empty
		try {
			var contentJSON = JSON.parse(content);
			if (Object.keys(contentJSON).length === 0) {
				// ToDo: create a "translated" document for this as it's already translated
				error = 'MockTranslationProvider.addDocument(): content parameter JSON must not be an empty object';
			}
		} catch (e) {
			error = 'MockTranslationProvider.addDocument(): content parameter must be JSON';
		}
	}

	// if there is an error, report it
	if (error) {
		return Promise.reject('MockTranslationProvider.addDocument(): ' + error);
	}

	// add the document
	return new Promise(function (resolve, reject) {
		request.post({
			url: urls.DOCUMENT,
			auth: {
				bearer: authToken
			},
			form: {
				'projectId': projectId,
				'sourceLocale': sourceLocale,
				'format': 'JSON',
				'charset': 'UTF-8',
				'name': name,
				'content': content
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var documentResponse = JSON.parse(body);
					return resolve(documentResponse);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.getDocument = function (authToken, id) {
	return new Promise(function (resolve, reject) {
		request.get({
			url: urls.DOCUMENT + '/' + id,
			auth: {
				bearer: authToken
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var document = JSON.parse(body);
					return resolve(document);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.getDocumentTranslationStatuses = function (authToken, id) {
	// confirm parameters
	if (!authToken || !id) {
		return Promise.reject('MockTranslationProvider.getDocumentTranslationStatuses(): required parameters: authToken, id');
	}

	return new Promise(function (resolve, reject) {
		request.get({
			url: urls.DOCUMENT + '/' + id + '/translation',
			auth: {
				bearer: authToken
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var translation = JSON.parse(body);
					return resolve(translation);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.getDocumentTranslationStatus = function (authToken, id, locale) {
	// confirm parameters
	if (!authToken || !id) {
		return Promise.reject('MockTranslationProvider.getTranslationStatus(): required parameters: authToken, id');
	}

	return this.getDocumentTranslationStatuses(id).then(function (translationStatuses) {
		var translations = translationStatuses.entities || [],
			translation;

		for (var i = 0; i < translations.length; i++) {
			if (translations[i].locale_code === locale) {
				translation = translations[i];
				break;
			}
		}

		return Promise.resolve(translation);
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.addTranslation = function (authToken, projectId, id, locale) {
	var self = this;

	// confirm parameters
	if (!authToken || !projectId || !id || !locale) {
		return Promise.reject('MockTranslationProvider.addTranslation(): required parameters: authToken, projectId, id, locale');
	}


	return new Promise(function (resolve, reject) {
		request.post({
			url: urls.DOCUMENT + '/' + id + '/translation',
			auth: {
				bearer: authToken
			},
			form: {
				'localeCode': locale,
				'projectId': projectId
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var translation = JSON.parse(body);
					return resolve(translation);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.getTranslation = function (authToken, id, locale) {
	// confirm parameters
	if (!authToken || !id || !locale) {
		return Promise.reject('MockTranslationProvider.getTranslation(): required parameters: authToken, id, locale');
	}

	return new Promise(function (resolve, reject) {
		request.get({
			url: urls.DOCUMENT + '/' + id + '/translation/' + locale,
			auth: {
				bearer: authToken
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var translation = JSON.parse(body);
					return resolve(translation);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.addProject = function (authToken, communityId, workflowId, projectName) {
	var self = this;

	// confirm parameters
	if (!authToken || !communityId || !workflowId || !projectName) {
		return Promise.reject('MockTranslationProvider.addProject(): required parameters: authToken, communityId, workflowId, projectName)');
	}

	// create the project
	return new Promise(function (resolve, reject) {
		request.post({
				url: urls.PROJECT,
				auth: {
					bearer: authToken
				},
				form: {
					name: projectName,
					communityId: communityId,
					workflowId: workflowId
				}
			},
			function (error, httpResponse, body) {
				if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
					try {
						var project = JSON.parse(body);
						return resolve(project);
					} catch (e) {
						return reject(e);
					}
				} else {
					return reject(error);
				}
			});
	});
};

/** @inheritdoc */
MockTranslationProvider.prototype.getProjectStatus = function (authToken, id) {
	if (!authToken || !id) {
		return Promise.reject('MockTranslationProvider.getProjectStatus(): required parameters: authToken, id)');
	}
	return new Promise(function (resolve, reject) {
		request.get({
			url: urls.PROJECT + '/' + id + '/status',
			auth: {
				bearer: authToken
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				var projectStatus = JSON.parse(body);
				return resolve(projectStatus);
			} else {
				return reject(error);
			}
		});
	});

};

/** @inheritdoc */
MockTranslationProvider.prototype.getCommunity = function (authToken) {
	if (!authToken) {
		return Promise.reject('MockTranslationProvider.getCommunity(): required parameters: authToken)');
	}

	return new Promise(function (resolve, reject) {
		request.get({
			url: urls.COMMUNITY,
			auth: {
				bearer: authToken
			}
		}, function (error, httpResponse, body) {
			if (!error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
				try {
					var communityResponse = JSON.parse(body),
						community = communityResponse.entities[0],
						communityDetails = community.properties;

					return resolve(communityDetails.id);
				} catch (e) {
					return reject(e);
				}
			} else {
				return reject(error);
			}
		});
	});
};

module.exports = new MockTranslationProvider();