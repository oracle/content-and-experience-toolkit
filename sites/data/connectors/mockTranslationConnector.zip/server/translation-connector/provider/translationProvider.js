/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */

/**
 * Connector's interface to the Language Service Provider.</br>
 * Handles all the required GET/POST/DELETE requests.
 * @constructor
 * @alias TranslationProviderInterface
 */
var ProviderInterface = function () {};
ProviderInterface.prototype = {
	getAccountInfo: function (authToken) {
		return Promise.reject('ProviderInterface.getAccountInfo(): not implemented');
	},
	getLocales: function (authToken) {
		return Promise.reject('ProviderInterface.getLocales(): not implemented');
	},
	patchDocument: function (authToken, id, args) {
		return Promise.reject('ProviderInterface.patchDocument(): not implemented');
	},
	deleteDocument: function (authToken, id) {
		return Promise.reject('ProviderInterface.deleteDocument(): not implemented');
	},
	/**
	 * Import a document into the Language Service Provider.
	 * 
	 * @param {string} projectId Identifier of the project that will include the document.
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} name Name of the document.
	 * @param {string} content JSON content of the document.
	 * @param {string} sourceLocale The source locale for the document.
	 * @param {string} additionalData Additional Data to apply on each document.
	 * @returns {Promise.<object>} The response from the Language Service Provider.
	 */
	addDocument: function (projectId, authToken, name, content, sourceLocale, additionalData) {
		return Promise.reject('ProviderInterface.addDocument(): not implemented');
	},
	/**
	 * Get the document identied by the Language service provider Id
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @returns {Promise.<string>} The content of the document.
	 */
	getDocument: function (authToken, id) {
		return Promise.reject('ProviderInterface.getDocument(): not implemented');
	},
	documentExists: function (authToken, id) {
		return Promise.reject('ProviderInterface.documentExists(): not implemented');
	},
	/**
	 * Get the statuses of all the locales of the document in the Language Service Provider.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @returns {Promise.<object>} The Language Service Provider GET "/:id/translation" response.
	 */
	getDocumentTranslationStatuses: function (authToken, id) {
		return Promise.reject('ProviderInterface.getDocumentTranslationStatuses(): not implemented');
	},
	/**
	 * Get the status of the specified locale of the document in the Language Service Provider.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @param {string} locale Name of the locale to check.
	 * @returns {Promise.<object>} The Language Service Provider GET "/:id/translation" response specific for the requested locale.
	 */
	getDocumentTranslationStatus: function (authToken, id, locale) {
		return Promise.reject('ProviderInterface.getDocumentTranslationStatus(): not implemented');
	},
	getDocumentInfo: function (authToken, id) {
		return Promise.reject('ProviderInterface.getDocumentInfo(): not implemented');
	},
	getDocumentStatus: function (authToken, id) {
		return Promise.reject('ProviderInterface.getDocumentStatus(): not implemented');
	},
	/**
	 * Request the document be translated into the given locale.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} projectId Identifier of the project that will include the document.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @param {string} locale Name of the locale to check.
	 * @returns {Promise.<object>} The Language Service Provider POST "/:id/translation" response.
	 */
	addTranslation: function (authToken, projectId, id, locale) {
		return Promise.reject('ProviderInterface.addTranslation(): not implemented');
	},
	/**
	 * Get the tranlation of the document for the given locale.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @param {string} locale Name of the locale to check.
	 * @returns {Promise.<string>} The Language Service Provider GET "/:id/translation/:locale" response.
	 */
	getTranslation: function (authToken, id, locale) {
		return Promise.reject('ProviderInterface.getTranslation(): not implemented');
	},
	deleteTranslation: function (authToken, id, locale) {
		return Promise.reject('ProviderInterface.deleteTranslation(): not implemented');
	},
	getCommunities: function (authToken) {
		return Promise.reject('ProviderInterface.getCommunities(): not implemented');
	},
	/**
	 * Create a new project in the Language Service Provider. 
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} communityId Community identifier that should contain the project.
	 * @param {string} workflowId Identifier of the Language Service Provider workflow to use to translate any documents.
	 * @param {string} projectName Name of project to create.
	 * @returns {Promise.<string>} The Language Service Provider string id for the created project.
	 */
	addProject: function (authToken, communityId, workflowId, projectName) {
		return Promise.reject('ProviderInterface.addProject(): not implemented');
	},
	/**
	 * Get the percent complete of the project.<br/>
	 * This represents the percentage complete of the translations for all the documents in the project.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @param {string} id Language Service Provider identifier for the document.
	 * @returns {Promise.<string>} The Language Service Provider GET "/:id/status" response.
	 */
	getProjectStatus: function (authToken, id) {
		return Promise.reject('ProviderInterface.getProjectStatus(): not implemented');
	},
	getProjects: function (authToken, community_id) {
		return Promise.reject('ProviderInterface.getProjects(): not implemented');
	},
	getVaults: function (authToken, community_id) {
		return Promise.reject('ProviderInterface.getVaults(): not implemented');
	},
	getFilters: function (authToken) {
		return Promise.reject('ProviderInterface.getFilters(): not implemented');
	},
	getFilter: function (authToken, id) {
		return Promise.reject('ProviderInterface.getFilter(): not implemented');
	},
	getFilterContent: function (authToken, id) {
		return Promise.reject('ProviderInterface.getFilterContent(): not implemented');
	},
	addFilter: function (authToken, name, type, content) {
		return Promise.reject('ProviderInterface.addFilter(): not implemented');
	},
	getWorkflowsImpl: function (authToken, communityId) {
		return httpApi.get(urls.WORKFLOW + '?community_id=' + communityId);
	},
	/**
	 * Get the details about the community for this user.
	 * 
	 * @param {string} authToken Authorization header tokent ot include in the request.
	 * @returns {Promise.<object>} The Language Service Provider GET "/community" response.
	 */
	getCommunity: function (authToken) {
		return Promise.reject('ProviderInterface.getCommunity(): not implemented');
	}
};

module.exports = {
	api: ProviderInterface,
	factory: { 
		create: function (provider) { 
			// Replace the following default provider with your translation provider implementation

			//return require(provider || './lingotekProvider.js');
			return require(provider || './mockTranslationProvider.js');
		}
	}
};