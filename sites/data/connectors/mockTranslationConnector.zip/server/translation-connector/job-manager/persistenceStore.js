/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */

/**
 * Manage persistence of the job during the jobs lifecycle. <br/>
 * This module is responsible for saving the state of the job and managing the state during startup/shutdown & failover. <br/>
 * <ul>
 *   <li>Specifically, it needs to: 
 *     <ul>
 *       <li>Keep track of all the jobs.</li>
 *       <li>For each job: 
 *         <ul>
 *           <li>Store metadata about the job and mapping it to the project in the Language Service Provider.</li>
 *           <li>Store/Unpack the zip file provided by the OCE translation job.</li>
 *           <li>Store metadata about each file in the zip mapping the file to the entry in the Language Service Provider.</li>
 *           <li>Store all the translations for each of the files as they become available.</li>
 *           <li>Create a final zip of all the translated files in the format required for ingestion into the OCE translation jobs.</li>
 *           <li>On job delete, remove all artifacts associated with the job.</li>
 *         </ul>
 *       </li>
 *     </ul>
 *   </li>
 * </ul>
 * @constructor
 * @alias PersistenceStoreInterface
 */
var PersistenceStoreInterface = function () {};

PersistenceStoreInterface.prototype = {
    /**
     * Get all the jobs currently tracked by the {@link PersistenceApi}<br/>
     * @returns {Promise.<SampleJobManager.JobConfig[]>} A Promise that returns an array of the metadata for each of the translation jobs. 
     */

    getAllJobs: function () {
        return Promise.reject('PersistenceStoreInterface.getAllJobs(): not implemented');
    },

    //
    // Job CRUD
    // 
    /**
     * Create a translation job<br/>
     * Create an entry for this translation job in the persistence store. 
     * @param {object} args JavaScript object containing the "createJob" parameters. 
     * @param {string} args.jobName Name of the OCE translation job.
     * @param {string} args.workflowId Language Service Provider workflow identifier to use to translate this job. 
     * @param {string} args.authToken Language Service Provider Authorization header to use to communicate with the LSP. 
     * @param {string} args.additionalData Additional Data to apply on each document in the LSP.
     * @returns {Promise.<SampleJobManager.JobConfig>} The metadata created and stored for this job. 
     */
    createJob: function (args) {
        return Promise.reject('PersistenceStoreInterface.createJob(): not implemented');
    },
    /**
     * Get a translation job.<br/>
     * Retrieve the job metadata from the persistence store for this job. 
     * @param {object} args JavaScript object containing the "getJob" parameters. 
     * @param {string} args.jobId Identifier for the job in the persistence store. 
     * @returns {Promise.<SampleJobManager.JobConfig>} The metadata created and stored for this job. 
     */
    getJob: function (args) {
        return Promise.reject('PersistenceStoreInterface.getJob(): not implemented');
    },
    /**
     * Update a translation job.<br/>
     * Update the translation job with new metadata about the jobs state.<br/>
     * Note: This currently supports only updating the following properties in the metadata: 
     * <ul>
     *   <li>status<li>
     *   <li>statusMessage<li>
     *   <li>translatedZipFile<li>
     *   <li>progress<li>
     * </ul>
     * @param {SampleJobManager.JobConfig} args JavaScript object containing the metadata to update for this job. 
     * @returns {Promise.<SampleJobManager.JobConfig>} The updated metadata stored for this job. 
     */
    updateJob: function (args) {
        return Promise.reject('PersistenceStoreInterface.updateJob(): not implemented');
    },
    /**
     * Delete all persistence data related to the provided job identifier. 
     * @param {object} args JavaScript object containing the "deleteJob" parameters. 
     * @param {string} args.jobId Identifier of the job to be deleted. 
     * @returns {Promise} A Promise that is resolved when the job has been deleted.
     */
    deleteJob: function (args) {
        return Promise.reject('PersistenceStoreInterface.deleteJob(): not implemented');
    },

    //
    // Source file CRUD operations
    // 
    /**
     * Import the source zip file and expand it into the "translation-source" folder in the persistence store.
     * @param {object} args JavaScript object containing the "importSourceZip" parameters. 
     * @param {string} args.jobId Identifier of the job to be deleted. 
     * @param {stream} args.zipFile The contents of the zip file to write to the filesystem
     * @returns {Promise} A Promise that is resolved when the zip file has been written to the filesystem and expanded.
     */
    importSourceZip: function (args) {
        return Promise.reject('PersistenceStoreInterface.importSourceZip(): not implemented');
    },
    /**
     * Get the source job.json files that are in the zip file.<br/>
     * The job can be either: 
     * <ul>
     *   <li> "assets" job type, which has a structure of: 
     *     <ul>
     *       <li>job.json
     *       <li>root
     *     </ul>
     *   </li>
     *   <li> "site" job type, which has a structure of: 
     *     <ul>
     *       <li>assets
     *         <ul>
     *           <li>job.json</li>
     *           <li>root</li>
     *         </ul>
     *       </li>
     *       <li> site
     *         <ul>
     *           <li>job.json</li>
     *           <li>root</li>
     *         </ul>
     *       </li>
     *     </ul>
     *   </li>
     * </ul>
     * @param {object} args JavaScript object containing the "getSourceJobJSON" parameters. 
     * @param {string} args.jobId Identifier of the job to retrieve the job.json information.
     * @returns {Promise.<SampleJobManager.JobDetails>} A Promise that is resolved with the combined job.json files.
     */
    getSourceJobJSON: function (args) {
        return Promise.reject('PersistenceStoreInterface.getSourceJobJSON(): not implemented');
    },
    /**
     * Get the requested source file from the job.
     * @param {object} args JavaScript object containing the "getSourceFile" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {string} args.filePath Name of the file on the file system to return.
     * @param {SampleJobManager.file} args.file Details about the file to return from the persistence store.
     * @returns {Promise.<string>} A Promise that is resolved with the file content.
     */
    getSourceFile: function (args) {
        return Promise.reject('PersistenceStoreInterface.getSourceFile(): not implemented');
    },
    /**
     * Get path to the binary files folder of the digital asset.
     * @param {string} args.contentItemId Digital Asset Id
     * @returns {string} path to the binary files folder of the digital asset.
     */
    getBinaryFilePath: function (args) {
        return 'PersistenceStoreInterface.getBinaryFilePath(): not implemented';
    },
    /**
     * Get list of files in the binary files folder of the digital asset.
     * @param {object} args JavaScript object containing the "getSourceFile" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {string} args.folderPath Folder path of the binary file directory.
     * @param {SampleJobManager.file} args.file Details about the file to return from the persistence store.
     * @returns {Array.<string>} list of files in the binary files folder of the digital asset.
     */
    getFolderFiles: function (args) {
        return 'PersistenceStoreInterface.getFolderFiles(): not implemented';
    },
    /**
     * Get binary file spec of the binary file.
     * @param {object} args JavaScript object containing the "getSourceFile" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {string} args.folderPath Folder path of the binary file directory.
     * @param {SampleJobManager.file} args.file Details about the file to return from the persistence store.
     * @returns {string} binary file spec of the digital asset.
     */
    getBinaryFileSpec: function (args) {
        return 'PersistenceStoreInterface.getBinaryFileSpec(): not implemented';
    },
    /**
     * Get binary file.
     * @param {object} args JavaScript object containing the "getSourceFile" parameters.
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource.
     * @param {string} args.folderPath Folder path of the binary file directory.
     * @param {SampleJobManager.file} args.file Details about the file to return from the persistence store.
     * @returns {Promise.<string>} binary file.
     */
    getBinaryFile: function (args) {
        return Promise.reject('PersistenceStoreInterface.getBinaryFile(): not implemented');
    },

    //
    // Translated files CRUD operations
    // 
    /**
     * Create a repository to hold all the translated files.
     * @param {object} args JavaScript object containing the "createTranslationRepository" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @returns {Promise} A Promise that is resolved when the repository has been setup to receive translations.
     */
    createTranslationRepository: function (args) {
        return Promise.reject('PersistenceStoreInterface.createTranslationRepository(): not implemented');
    },
    /**
     * Add a translated file to the translation repository 
     * @param {object} args JavaScript object containing the "addTranslationFile" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {string} args.locale The locale of the translation for this file.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {string} args.filePath Name of the file on the file system to return.
     * @param {string} args.fileContent Translated content for the file.
     * @param {string} args.fileName Descriptive name if failed to write the file contents.
     * @returns {Promise} A Promise that is resolved when the file has been saved to the translation repository.
     */
    addTranslationFile: function (args) {
        return Promise.reject('PersistenceStoreInterface.addTranslationFile not implemented');
    },
    /**
     * Add a translated binary file to the translation repository 
     * @param {object} args JavaScript object containing the "addTranslationFile" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {string} args.locale The locale of the translation for this file.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {string} args.filePath Name of the file on the file system to return.
     * @param {string} args.fileContent Translated content for the file.
     * @param {string} args.fileName Descriptive name if failed to write the file contents.
     * @param {string} args.folderPath Folder path to the binary file.
     * @returns {Promise} A Promise that is resolved when the file has been saved to the translation repository.
     */
    addBinaryTranslationFile: function (args) {
        return Promise.reject('PersistenceStoreInterface.addBinaryTranslationFile not implemented');
    },
    /**
     * Create the export zip file for the translated files.
     * @param {object} args JavaScript object containing the "createTranslationZip" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @returns {Promise.<SampleJobManager.JobConfig>} A Promise that is resolved with the updated job metadata containing the "translatedZipFile" property for the created zip file.
     */
    createTranslationZip: function (args) {
        return Promise.reject('PersistenceStoreInterface.createTranslationZip(): not implemented');
    },

    /**
     * @typedef {Object} ZipFileStream
     * @memberof PersistenceApi
     * @property {string} size size of the zip file
     * @property {stream} stream zip file stream 
     */

    /**
     * Export the translated zip file
     * @param {object} args JavaScript object containing the "exportTranslationZip" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @returns {Promise.<PersistenceApi.ZipFileStream>} A Promise that is resolved with a zip file stream that can be returned in an HTTPS response.
     */
    exportTranslationZip: function (args) {
        return Promise.reject('PersistenceStoreInterface.exportTranslationZip(): not implemented');
    },


    //
    // File metadata CRUD
    // 
    /**
     * @typedef {Object} fileMetadata
     * @memberof PersistenceApi
     * @property {string} jobId id of the job this file is in 
     * @property {('assets'| 'file')} jobType type of zip file used for the job
     * @property {('assets'| 'file')} fileType type of file
     * @property {SampleJobManager.file} file details about this file
     */
    /**
     * Create the metadata to be held for a file being translated.
     * @param {object} args JavaScript object containing the "createFileMetadata" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {SampleJobManager.file} args.file Details about the file in the persistence store.
     * @returns {Promise.<PersistenceApi.fileMetadata>} A Promise that is resolved with a details on the metadata for the file
     */
    createFileMetadata: function (args) {
        return Promise.reject('PersistenceStoreInterface.createFileMetadata(): not implemented');
    },
    /**
     * Get the meta-data for a file being translated.
     * @param {object} args JavaScript object containing the "getFileMetadata" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {SampleJobManager.file} args.file Details about the file in the persistence store.
     * @returns {Promise.<PersistenceApi.fileMetadata>} A Promise that is resolved with a details on the metadata for the file
     */
    getFileMetadata: function (args) {
        return Promise.reject('PersistenceStoreInterface.getFileMetadata(): not implemented');
    },

    /**
     * Update the metadata for a file being translated.
     * @param {object} args JavaScript object containing the "updateFileMetadata" parameters. 
     * @param {string} args.jobId Identifier of the job.
     * @param {('site'|'assets')} args.fileType Type of file to fetch - whether it's an assets file or a site resource. 
     * @param {SampleJobManager.file} args.file Details about the file in the persistence store.
     * @returns {Promise.<PersistenceApi.fileMetadata>} A Promise that is resolved with a details on the metadata for the file
     */
    updateFileMetadata: function (args) {
        return Promise.reject('PersistenceStoreInterface.updateFileMetadata(): not implemented');
    }
};

// Export the persistence store 
module.exports = {
    api: PersistenceStoreInterface,
    factory: {
        create: function (persistenceStore) {
            return require(persistenceStore || './sampleFilePersistenceStore');
        }
    }
};