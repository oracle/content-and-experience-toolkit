/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */

// list of locales supported by OCE
var oceLocales = ["af", "sq", "am", "ar", "ar-DZ", "ar-BH", "ar-EG", "ar-IQ", "ar-JO", "ar-KW", "ar-LB", "ar-LY", "ar-MA", "ar-OM", "ar-QA", "ar-SA", "ar-SY", "ar-TN", "ar-AE", "ar-YE", "hy", "as", "az", "az-AZ", "az-Cyrl-AZ", "az-Latn-AZ", "eu", "be", "bn", "bs", "bg", "my", "ca", "zh", "zh-CN", "zh-HK", "zh-MO", "zh-SG", "zh-TW", "hr", "cs", "da", "dv", "nl", "nl-BE", "nl-NL", "en", "en-CB", "en-AU", "en-BZ", "en-CA", "en-IN", "en-IE", "en-JM", "en-NZ", "en-PH", "en-ZA", "en-TT", "en-GB", "en-US", "et", "fo", "fi", "fr", "fr-BE", "fr-CA", "fr-FR", "fr-LU", "fr-CH", "gl", "ka", "de", "de-AT", "de-DE", "de-LI", "de-LU", "de-CH", "el", "gn", "gu", "he", "hi", "hu", "is", "id", "it", "it-IT", "it-CH", "ja", "kn", "ks", "kk", "km", "ko", "lo", "la", "lv", "lt", "mk", "ms", "ms-BN", "ms-MY", "ml", "mt", "mi", "mr", "mn", "ne", "zxx", "no", "no-NO", "nb", "nn", "or", "pa", "fa", "pl", "pt", "pt-BR", "pt-PT", "rm", "ro", "ro-MO", "ru", "ru-MO", "sa", "gd", "gd-IE", "sr", "sr-SP", "sr-RS", "sr-Cyrl-RS", "sr-Latn-RS", "sd", "si", "sk", "sl", "so", "es", "es-AR", "es-BO", "es-CL", "es-CO", "es-CR", "es-DO", "es-EC", "es-SV", "es-GT", "es-HN", "es-MX", "es-NI", "es-PA", "es-PY", "es-PE", "es-PR", "es-ES", "es-UY", "es-VE", "sw", "sv", "sv-FI", "sv-SE", "tg", "ta", "tt", "te", "th", "bo", "ts", "tn", "tr", "tk", "uk", "und", "ur", "uz", "uz-UZ", "uz-Cyrl-UZ", "uz-Latn-UZ", "vi", "cy", "xh", "yi", "zu"];

// define the LSP entries for the OCE locales the LSP doesn't support
var lspLocaleMap = {
	"af": "af-ZA",
	"sq": "sq-SQ",
	"am": "am-ET",
	"ar": "ar", // standard arabic 
	"hy": "hy-AM",
	"as": "as-IN",
	"az": "az-AZ",
	"eu": "eu-ES",
	"be": "be-BY",
	"bn": "bn-BD",
	"bs": "bs-BA",
	"bg": "bg-BG",
	"my": "my-MM",
	"ca": "ca-ES",
	"zh": "zh-CN",
	"hr": "hr-HR",
	"cs": "cs-CZ",
	"da": "da-DK",
	"dv": "dv-MV",
	"nl": "nl-NL",
	"en": "en-US",
	"et": "et-EE",
	"fo": null, // no mapping - Faroese 
	"fi": "fi-FI",
	"fr": "fr-FR",
	"gl": "gl-ES",
	"ka": "ka-GE",
	"de": "de-DE",
	"el": "el-GR",
	"gn": "gn-BO",
	"gu": "gu-IN",
	"he": "he-IL",
	"hi": "hi-IN",
	"hu": "hu-HU",
	"is": "is-IS",
	"id": "id-ID",
	"it": "it-IT",
	"ja": "ja-JP",
	"kn": "kn-IN",
	"ks": "ks-IN",
	"kk": "kk-KZ",
	"km": "km-KH",
	"ko": "ko-KR",
	"lo": "lo-LA",
	"la": "la-VA",
	"lv": "lv-LV",
	"lt": "lt-LT",
	"mk": "mk-MK",
	"ms": "ms-MY",
	"ml": "ml-IN",
	"mt": "mt-MT",
	"mi": "mi-NZ",
	"mr": "mr-IN",
	"mn": "mn-MN",
	"ne": "ne-NP",
	"zxx": null, // graphic/photo/video (no linguistic information) 
	"no": "no-NO",
	"nb": "nb-NO",
	"nn": "nn-NO",
	"or": "or-IN",
	"pa": "pa-IN",
	"fa": "fa-IR",
	"pl": "pl-PL",
	"pt": "pt-PT",
	"rm": null, // no mapping - Raeto-Romance
	"ro": "ro-RO",
	"ru": "ru-RU",
	"sa": "sa-IN",
	"gd": "gd-GB",
	"sr": "sr-CS",
	"sd": "sd-PK",
	"si": "si-LK",
	"sk": "sk-SK",
	"sl": "sl-SI",
	"so": "so-SO",
	"es": "es-ES",
	"sw": "sw-TZ",
	"sv": "sv-SE",
	"tg": "tg-TJ",
	"ta": "ta-IN",
	"tt": null, // no mapping - Tatar
	"te": "te-IN",
	"th": "th-TH",
	"bo": "bo-CN",
	"ts": "ts-ZA",
	"tn": "tn-BW",
	"tr": "tr-TR",
	"tk": "tk-TM",
	"uk": "uk-UA",
	"und": null, // "und ==> undefined" locale
	"ur": "ur-PK",
	"uz": "uz-UZ",
	"vi": "vi-VN",
	"cy": "cy-GB",
	"xh": "xh-ZA",
	"yi": "yi-IL",
	"zu": "zu-ZA",
	"az-Cyrl-AZ": "az-AZ", // cyrlic/latin characters
	"az-Latn-AZ": "az-AZ",
	"sr-Cyrl-RS": "sr-CS",
	"sr-Latn-RS": "sc-CS",
	"uz-Cyrl-UZ": "uz-UZ",
	"uz-Latn-UZ": "uz-UZ"
};

// create a map of OCE locale to the corresponding supported LSP locale
var localeMap = {};
oceLocales.forEach(function (oceLocale) {
	localeMap[oceLocale] = lspLocaleMap.hasOwnProperty(oceLocale) ? lspLocaleMap[oceLocale] : oceLocale;
});

module.exports = localeMap;



