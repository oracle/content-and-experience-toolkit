/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */
var translationProvider = require('../provider/translationProvider').factory.create(),
    filterApi = require('./translationFilter'),
    persistenceStore = require('./persistenceStore').factory.create();



/**
 * Import all Assets & Site files into the Language Service Provider. <br/>
 * The steps invovled are: <br/>
 * <ul>
 *   <li>For each site & assets file: 
 *     <ul>
 *       <li>Load up and parse the file's JSON </li>
 *       <li>Filter the file to remove all non-translatable strings</li>
 *       <li>Handle empty files, these aren't sent to the Langauge Service Provider</li>
 *       <li>Import the filtered non-emtpy file into the Langauge Service Provider and retrieve the documentId for the file.</li>
 *       <li>Create a metadata file in the persistence store that contains the documentId for the file so the translated strings can be later merged with the original file</li>
 *       <li>Wait for the file to be imported before continuing with the next file</li>
 *   </ul>
 * </ul>
 * @constructor
 * @alias SampleFileImporter
 */
var SampleFileImporter = function () {};
SampleFileImporter.prototype.EMPTY_DOCUMENT_ID = 'emptyDocument';

// Get exclude fields.
// Get content type from the given content.
// Lookup exclude fields of the content type from the contentTypes object.
var getContentExcludeFields = function (fileContentJson, contentTypes) {
        var excludes = [];

        if (contentTypes) {
            if (fileContentJson.hasOwnProperty('type')) {
                var type = fileContentJson.type;
                if (type) {
                    contentTypes.filter(function(contentType) {
                        return type === contentType.name;
                    }).map(function (contentType) {
                        contentType.fields.forEach(function (field) {
                            if (field.translation && !field.translation.translate) {
                                excludes.push(field.name);
                            }
                        });
                    });
                }
            }
        }

        return excludes;
    };

/**
 * Import a file into the Language Service Provider. <br/>
 * The steps invovled are: <br/>
 * <ul>
 *   <li>For each site & assets file: 
 *     <ul>
 *       <li>Load up and parse the file's JSON </li>
 *       <li>Filter the file to remove all non-translatable strings</li>
 *       <li>Handle empty files, these aren't sent to the Langauge Service Provider</li>
 *       <li>Import the filtered non-emtpy file into the Langauge Service Provider and retrieve the documentId for the file.</li>
 *       <li>Create a metadata file in the persistence store that contains the documentId for the file so the translated strings can be later merged with the original file</li>
 *       <li>Wait for the file to be imported before continuing with the next file</li>
 *   </ul>
 * </ul>
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @param {string} projectId - The Langauge Service Provider project identifier corresponding to this job.
 * @param {SampleJobManager.file} file - Details on the site or assets file to import
 * @param {('site'|'assets')} fileType - The type of file being imported
 * @param {SampleJobManater.contentType[]} contentTypes - Array of content types.
 * @returns {Promise.<persistenceStore.fileMetadata>} The metada containing information about the file and the imported document created for the file
 */
SampleFileImporter.prototype.importFile = function (jobConfig, projectId, file, sourceLanguage, fileType, contentTypes) {
    var self = this;

    return new Promise(function (resolve, reject) {
        // meta-data for the file is created after the file is imported
        // see if the meta-data for this file already exists
        persistenceStore.getFileMetadata({
            jobId: jobConfig.properties.id,
            fileType: fileType,
            file: file
        }).then(function (fileMetadata) {
            // meta-data already exists so the file has already been imported, were done
            resolve(fileMetadata);
        }).catch(function (error) {
            // read in the file
            persistenceStore.getSourceFile({
                jobId: jobConfig.properties.id,
                fileType: fileType,
                filePath: file.path
            }).then(function (fileContents) {
                var originalFile = fileContents && fileContents.length > 0 ? JSON.parse(fileContents) : '';

                // ToDo: Handle filtered empty files
                if (!originalFile || Object.keys(originalFile).length === 0) {
                    var message = 'SampleFileImporter.importFile(): file is empty - ' + file.name;
                    console.log(message);

                    // Empty files are sent to the LSP,  use 'emptyDocument' as documentId so that we don't try to retrieve it
                    file.documentId = self.EMPTY_DOCUMENT_ID;

                    // write the file meta-data so we can get the document for the file once translated
                    persistenceStore.createFileMetadata({
                        jobId: jobConfig.properties.id,
                        jobType: jobConfig.jobType,
                        fileType: fileType,
                        file: file
                    }).then(function (fileMetadata) {
                        resolve(fileMetadata);
                    }).catch(function (error) {
                        console.log('SampleFileImporter.importFile(): unable to create meta-data file for file - ' + file.name);
                        reject(error);
                    });
                } else {

                    var excludes = getContentExcludeFields(originalFile, contentTypes);

                    if (excludes.length > 0) {
                        console.log('SampleFileImporter.importFile(): exclude fields for content type', originalFile.type, excludes);
                    }

                    // extract only the translatable properties from the document
                    var content = JSON.stringify(filterApi.getTranslatableProperties(originalFile, fileType, excludes));

                    // add the document
                    translationProvider.addDocument(projectId, jobConfig.authToken, file.name, content, sourceLanguage, jobConfig.additionalData).then(function (documentEntry) {
                        // wait for file to complete import - poll every 5 seconds(?) up to when?
                        var checkFileImport = function (id) {
                            translationProvider.getDocument(jobConfig.authToken, id).then(function (document) {
                                // update the file meta-data to include the document ID
                                file.documentId = document.properties.id;

                                // write the file meta-data so we can get the document for the file once translated
                                persistenceStore.createFileMetadata({
                                    jobId: jobConfig.properties.id,
                                    jobType: jobConfig.jobType,
                                    fileType: fileType,
                                    file: file
                                }).then(function (fileMetadata) {
                                    resolve(fileMetadata);
                                }).catch(function (error) {
                                    console.log('SampleFileImporter.importFile(): unable to create meta-data file for file - ' + file.name);
                                    reject(error);
                                });
                            }).catch(function () {
                                // file not available, check again in 3s
                                setTimeout(function () {
                                    checkFileImport(id);
                                }, 3000);
                            });
                        };
                        checkFileImport(documentEntry.properties.id);
                    }).catch(function (httpError) {
                        var error = {
                            errorCode: httpError && httpError.statusCode || 500,
                            errorMessage: httpError && httpError.statusMessage || 'unknown error'
                        };
                        console.log('SampleFileImporter.importFile(): error importing file - ' + file.path);
                        console.log(JSON.stringify(error));
                        reject(error);
                    });
                }
            });
        });
    });
};

/**
 * Create a list of functions that returns a promise for each file in the list.<br/>
 * The promises are chained in a "return p1.then(return p2.then(return p3.then(...)))" model to avoid overloading the Language Service Provider. 
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @param {SampleJobManager.JobDetails} jobDetails - The details of the combined job.json files.
 * @param {('site'|'assets')} fileType - The type of file being imported
 * @param {SampleJobManager.file[]} files - Array of files to import.
 * @param {SampleJobManater.contentType[]} contentTypes - Array of content types.
 * @returns {function[]} An array of functions, each of which returns a pronmise that resolves when the file is imported. 
 */
SampleFileImporter.prototype.importFileList = function (jobConfig, jobDetails, fileType, files, contentTypes) {
    var self = this;

    // create the array of functions to return the import promises
    return (files || []).map(function (file) {
        return function () {
            return self.importFile(jobConfig, jobConfig.properties.projectId, file, jobDetails.sourceLanguage, fileType, contentTypes);
        };
    });
};

/**
 * Import all the Site & Assets files into the Langauge Service Provider for this job <br/>
 * The promises are chained in a "return p1.then(return p2.then(return p3.then(...)))" model to avoid overloading the Language Service Provider. 
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @param {SampleJobManager.JobDetails} jobDetails - The details of the combined job.json files.
 * @returns {Promise} A Promise that resovles when all files have been imported. 
 */
SampleFileImporter.prototype.importFiles = function (jobConfig, jobDetails) {
    var self = this;

    return new Promise(function (resolve, reject) {
        // make sure necessary files are there and then import all the JSON files into the LSP server
        if (jobDetails.sourceLanguage && jobDetails.targetLanguages) {
            // import the assets & the site into the LSP
            var importPromises = [];
            if (jobDetails.assets) {
                importPromises = importPromises.concat(self.importFileList(jobConfig, jobDetails, 'assets', jobDetails.assets && jobDetails.assets.files, jobDetails.assets && jobDetails.assets.contentTypes));
            }
            if (jobDetails.site) {
                importPromises = importPromises.concat(self.importFileList(jobConfig, jobDetails, 'site', jobDetails.site && jobDetails.site.files));
            }

            // now run through and import all the files
            // chain the promises in the array so that they execute as: return p1.then(return p2.then(return p3.then(...)));
            var doImport = importPromises.reduce(function (previousPromise, nextPromise) {
                    return previousPromise.then(function () {
                        // wait for the previous promise to complete and then return a new promise for the next 
                        return nextPromise();
                    });
                },
                // Start with a previousPromise value that is a resolved promise 
                Promise.resolve());

            // once all files are imported, can continue
            doImport.then(function () {
                console.log('SampleFileImporter.importFilestranslateFiles(): all files imported');
                resolve();
            }).catch(function (e) {
                console.log('SampleFileImporter.importFiles(): error importing files');
                console.log(JSON.stringify(e));
                reject(e);
            });
        } else {
            reject('SampleFileImporter.importFiles(): no source language specified in job.json files');
        }
    });
};


// Export the mock translator
module.exports = new SampleFileImporter();