The Translation Connector SDK for Oracle Content and Experience is a sample NodeJS implementation of the Translation Connector API. The sample accepts a Oracle Content and Experience translation job zip file, transates all the resources in the file and returns a new zip file containing all the translations. <p>
Note: The SDK requires the user to have access to a Language Servic Provider to do the actual string translations. A mock Langauge Service Provider server is included in the SDK to mimic the responses from the Language Service Provider by simply prepends the targeted locales onto the strings. 

The Translation Connector SDK consists of three main modules:
+ **[SampleConnector]{@link SampleConnector}**: A sample translation connector that implements the required Oracle Content and Experience Translation Connector API. 
+ **[SampleJobManager]{@link SampleJobManager}**: A filesystem based sample job manager that maintains the state of the connector jobs while they are translated.
+ **[TranslationProviderInterface]{@link TranslationProviderInterface}**: A set of APIs used to call the Language Service Provider to submit documents for translation and retrieve the translated documents.

The Sample Translation Connector code is split up into three areas: 
+ **/translation-connector**: 
    + **/connector**: Implements the required Oracle Content and Experience Translation Connector APIs.
    + **/job-manager**: A sample implementation of a file-based persistence store to unzip the translation job, translate it and zip up the translations. 
    + **/provider**: Implements the Language Service Provider APIs to upload, translate and download documents.

In addition, there is a implemntation of a mock Language Service Provider for testing:
+ **/mockserver**: A mock Language Service Provider, which simply adds the requested translation locale to all the strings. 