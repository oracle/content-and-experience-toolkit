/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */
var fs = require('fs'),
	path = require('path'),
	responses = require('./mockLspResponses');


// Define an "out" folder to hold the mock translation projects
var projectDir = path.join(__dirname, "out");

// Define some mock workflows that can be used for translation
var mockWorkflows = {
	// create a mock "automated machine" workflow that simply converts a string to:  "##{locale} - {string}##"
	'machine-workflow-id': {
		title: 'Machine Workflow',
		description: 'automated machine translations only',
		id: 'machine-workflow-id',
		// The translation function within the workflow is called to translate any string in the document
		translation: function (localeCode, translateString) {
			var translatedString = translateString,
				canTranslate = function (str) {
					var translatable = false;

					// translate if:
					// - it is a string
					translatable = (typeof str === 'string' && isNaN(str));
					if (translatable) {
						// - it doesn't look like a URL
						translatable = ['http', 'https', 'ftp', 'file', 'mailto', 'tel'].indexOf(str.split(':')[0]) === -1;
					}

					return translatable;
				};

			// mock the translation - simply add ##{locale}## before the string
			if (canTranslate(translateString)) {
				var normalLocale = localeCode + ' ',
					richTextPrefix = '<!DOCTYPE html>',
					richTextLocale = '<div>##' + localeCode + '##</div>',
					mdePrefix = '<!---mde-->',
					mdeLocale = '* ##' + localeCode + '##\n',
					divPrefix = '<div>',
					divLocale = '<div>##' + localeCode + '##</div>';

				// handle the various types of rich text strings
				if (translateString.startsWith(richTextPrefix)) {
					// handle rich text
					translatedString = translateString.replace(richTextPrefix, richTextPrefix + richTextLocale);
				} else if (translateString.startsWith(mdePrefix)) {
					// handle markdown text
					translatedString = translateString.replace(mdePrefix, mdePrefix + mdeLocale);
				} else if (translateString.startsWith(divPrefix)) {
					// handle site text
					translatedString = translateString.replace(divPrefix, divPrefix + divLocale);
				} else {
					// otherwise handle normal text
					translatedString = normalLocale + translateString;
				}
			}

			return translatedString;
		}
	}
};

// Utility function to walk the folder hierarchy until we find the requested fileId
var findFile = function (dir, fileId) {
	var list = fs.readdirSync(dir);
	if (list) {
		var file;
		for (var i = 0; i < list.length; i++) {
			// see if the this is the file we're looking for
			if (list[i] === fileId) {
				file = path.join(dir, list[i]);
				break;
			} else {
				// if not, check any directories
				var checkDir = path.join(dir, list[i]);
				if (fs.lstatSync(checkDir).isDirectory()) {
					file = findFile(checkDir, fileId);
					// if we found the file in one of the directories, we're done here
					if (file) {
						break;
					}
				}
			}
		}
		return file;
	}
};

/*
   Structure of the mock server data
   +-communities
	 +-{bearerToken1} - folder based on the bearer token value used for requests (normalize token - remove non-alphanumeric chars and lowercase)
	 | +-projects
	 |   +-{project1} - random generated number used as the project ID
	 |   |  +-{project1}.json - contains the project name and workflow ID
	 |   |  +-{document1} - random generated number used as the document ID
	 |   |  |  +-metadata.json - contains the document Id & document name and source locale
	 |   |  |  +-{srcLocale}
	 |   |  |  | +-{document1}.json - contents of the original document
	 |   |  |  +-{locale1}
	 |   |  |  | +-{document1}.json
	 |   |  |  +-{locale2}
	 |   |  |  | +-{document1}.json
	 |   |  |  +-{locale3}
	 |   |  |  | +-{document1}.json
	 |   |  |  ...
	 |   |  +-{document2}
	 |   |  +-{document3}
	 |   |  ...
	 |   +-{project2}
	 |   +-{project3}
	 |   ...
     +-{bearerToken2}
     +-{bearerToken3}
	 ...
*/

/**
 * An implementation of a mock-up of a Language Service Provider.<br/>
 * The "translation" of strings is simply to add "##{locale}##" to all the strings in the documents submitted to the mock server.</br>
 * The mock server starts up in the same node server as the SampleConnector and implements the following endpoints: 
 * <ul>
 * <li>http://localhost:{port}/lsp/rest/api/v1/community</li>
 * <li>http://localhost:{port}/lsp/rest/api/v1/workflow</li>
 * <li>http://localhost:{port}/lsp/rest/api/v1/project</li>
 * <li>http://localhost:{port}/lsp/rest/api/v1/document</li>
 * </ul>
 * 
 * @constructor
 * @alias MockServer
 */
var MockServer = function () {
	this.initialize();
};

// idempotent function to make sure required folders are there so that we can begin to create projects
MockServer.prototype.initialize = function () {
	// create the project "out" directory
	if (!fs.existsSync(projectDir)) {
		fs.mkdirSync(projectDir);
	}

	// create the "out/communities" directory
	this.communitiesPath = path.join(projectDir, 'communities');
	if (!fs.existsSync(this.communitiesPath)) {
		fs.mkdirSync(this.communitiesPath);
	}

	// initialize the communities object
	this.communities = this.communities || {};
};


// write the requested error message to the console and throw the error
MockServer.prototype.throwError = function (error) {
	console.log(error.errorMessage);
	throw (error);
};

MockServer.prototype.validateRequest = function (args, checks) {
	var self = this,
		functionName = checks && checks.functionName || 'validateRequest';

	if (checks) {
		// handle community check
		if (!this.getCommunity(args)) {
			self.throwError({
				errorCode: 405, // Method Not Allowed
				errorMessage: 'No community available'
			});
		}

		// handle required URL parameter checks
		(checks.requiredParameters || []).forEach(function (requiredParameter) {
			if (!args.params || !args.params[requiredParameter]) {
				self.throwError({
					errorCode: 400, // Bad Request
					errorMessage: 'mockLspServer.' + functionName + '(): missing required parameter - ' + requiredParameter
				});
			}
		});

		// handle required body (data) parameter checks
		(checks.requiredData || []).forEach(function (dataParameter) {
			if (!args.data || !args.data[dataParameter]) {
				self.throwError({
					errorCode: 400, // Bad Request
					errorMessage: 'mockLspServer.' + functionName + '(): missing required parameter - ' + dataParameter
				});
			}
		});
	}
};

/*
   Mock getting the community for current user
   Each "user" is a separate "community" folder based on the Bearer token they supply
   If the folder doesn't exist, create a new folder based on the Bearer token value

   Structure of the mock server data
   +-communities
	 +-{bearerToken1} - folder based on the bearer token value used for requests (normalize token - remove non-alphanumeric chars and lowercase)
	 ...
*/
MockServer.prototype.getCommunity = function (args) {
	// make sure everything's initialized
	this.initialize();

	// create the directory for this community if it doesn't exist
	var communityId = args.bearerToken.replace(/\W/g, '');
	this.communities[args.bearerToken] = this.communities[args.bearerToken] || {
		id: communityId,
		path: path.join(this.communitiesPath, communityId)
	};
	if (!fs.existsSync(this.communities[args.bearerToken].path)) {
		fs.mkdirSync(this.communities[args.bearerToken].path);
	}

	// return the community config
	return responses.formatResponse('GET', '/community', {
		communityTitle: 'My Mock Community',
		communityId: communityId
	});
};

// Mock getting Workflows for community
MockServer.prototype.getWorkflows = function (args) {
	this.validateRequest(args, {
		functionName: 'getWorkflows'
	});

	// return the mock workflow
	return responses.formatResponse('GET', '/workflow', {
		workflowTitle: mockWorkflows[key].title,
		workflowDescription: mockWorkflows[key].description,
		workflowId: mockWorkflows[key].id
	});
};

// Mock getting the Project in the Community
// /api/lsp/project - get all project details
MockServer.prototype.getProjects = function (args) {
	this.validateRequest(args, {
		functionName: 'getProjects'
	});

	// create the response model adding in the projects
	var community = this.communities[args.bearerToken],
		model = {
			communityId: community.id,
			workflowId: mockWorkflows['machine-workflow-id'].id
		};

	// get the list of projects on the filesystem
	var projectsDir = path.join(community.path, 'projects');

	if (fs.existsSync(projectsDir)) {
		var projectsList = fs.readdirSync(projectsDir),
			projects = [];

		for (var i = 0; i < projectsList.length; i++) {
			if (fs.lstatSync(path.join(projectsDir, projectsList[i])).isDirectory()) {
				projects.push(projectsList[i]);
			}
		}

		projects.forEach(function (project, index) {
			model['projectId' + (index + 1)] = project;
			model['projectTitle' + (index + 1)] = 'Title: ' + project;
		});
	}

	return responses.formatResponse('GET', '/project', model);
};

// Mock getting the Project in the Community
// Mock getting a single project for user
// If the project folder exists under the "community" folder, return the project.json file from within it
// /api/lsp/project/{id} - project details
MockServer.prototype.getProject = function (args) {
	this.validateRequest(args, {
		functionName: 'getProject',
		requiredParameters: ['projectId']
	});

	// get the parameters
	var projectId = args.params.projectId;

	// get the meta-data for the project
	var community = this.communities[args.bearerToken],
		projectMetadataFile = path.join(community.path, 'projects', projectId, projectId + '.json');
	if (fs.existsSync(projectMetadataFile)) {
		// read in the project metadata
		try {
			var projectMetadata = JSON.parse(fs.readFileSync(projectMetadataFile));
			return responses.formatResponse('GET', '/project/' + projectId, {
				projectId: projectMetadata.properties.id,
				communityId: community.id,
				workflowId: projectMetadata.workflowId,
				projectTitle: projectMetadata.name
			});
		} catch (e) {
			self.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.getProject(): unable to parse metadata file - ' + projectId
			});
		}
	} else {
		self.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.getProject(): missing metadata file for - ' + projectId
		});
	}
};


// Mock getting the status of the Project in the Community
// /api/lsp/project/{id}/status - project details
MockServer.prototype.getProjectStatus = function (args) {
	this.validateRequest(args, {
		functionName: 'getProject',
		requiredParameters: ['projectId']
	});

	var projectId = args.params.projectId;

	// status is always 100% in the mock server
	return responses.formatResponse('GET', '/project/' + projectId + '/status', {
		projectId: projectId,
		projectTitle: 'Title: ' + projectId,
		percentComplete: 100
	});
};

/*
   Mock creating a Project in the Community

   Structure of the mock server data
   +-communities/{bearerToken1}/projects
	 +-{project1} - random generated number used as the project ID
	 |  +-{project1}.json - contains the project name and workflow ID
*/
MockServer.prototype.createProject = function (args) {
	this.validateRequest(args, {
		functionName: 'createProject',
		requiredData: ['name', 'workflowId']
	});

	// get the parameters
	var projectName = args.data.name,
		workflowId = args.data.workflowId;

	// generate a random number directory for the project
	var projectId = 'project' + Math.floor(100000 + Math.random() * 900000);

	// create the projects directory if it doesn't exist
	var community = this.communities[args.bearerToken],
		projects = path.join(community.path, 'projects');
	if (!fs.existsSync(projects)) {
		fs.mkdirSync(projects);
	}

	// create this project if it doesn't exist
	var projectDir = path.join(projects, projectId);
	if (!fs.existsSync(projectDir)) {
		fs.mkdirSync(projectDir);
	}

	// get the project data
	var projectJSON,
		projectFile = path.join(projectDir, projectId + '.json');
	if (fs.existsSync(projectFile)) {
		try {
			var contents = fs.readFileSync(projectFile, 'utf8');
			projectJSON = JSON.parse(contents);
		} catch (e) {
			self.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.createProject(): failed to parse project.json file for: ' + projectId
			});
		}
	} else {
		projectJSON = {
			name: projectName,
			workflowId: workflowId,
			properties: {
				id: projectId
			}
		};
		fs.writeFileSync(projectFile, JSON.stringify(projectJSON), function (err) {
			self.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.createProject(): failed to write project.json file'
			});
		});
	}

	return responses.formatResponse('POST', '/project', {
		projectTitle: projectJSON.name,
		projectId: projectJSON.properties.id,
		communityId: community.id,
		workflowId: projectJSON.workflowId
	});
};

// Mock getting the Document
// /api/lsp/document/{id}
MockServer.prototype.getDocument = function (args) {
	this.validateRequest(args, {
		functionName: 'getDocument',
		requiredParameters: ['documentId']
	});

	var documentId = args.params.documentId;

	// find the document folder
	var community = this.communities[args.bearerToken],
		documentFolderPath = findFile(community.path, documentId);

	// if we haven't found it, report it
	if (!documentFolderPath) {
		self.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.getDocument(): unable to find document directory for - ' + documentId
		});
	} else {
		// mock up the response
		var metadataFilePath = path.join(documentFolderPath, 'metadata.json');
		if (fs.existsSync(metadataFilePath)) {
			var fileProperties = JSON.parse(fs.readFileSync(metadataFilePath)).properties;
			return responses.formatResponse('GET', '/document/' + documentId, {
				documentTitle: fileProperties.documentTitle,
				documentId: documentId,
				documentName: fileProperties.documentName,
				documentStatus: 'ACTIVE',
				documentExtension: 'json',
				projectId: fileProperties.projectId,
				userId: fileProperties.userId,
				communityId: community.id,
				workflowId: fileProperties.workflowId
			});
		} else {
			self.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.getDocument(): missing metadata file for - ' + documentId
			});
		}
	}
};


// Mock getting the Document import process
// /api/lsp/document/{id}/import-process
MockServer.prototype.getDocumentImportProcess = function (args) {
	this.validateRequest(args, {
		functionName: 'getDocumentImportProcess',
		requiredParameters: ['documentId']
	});

	var documentId = args.params.documentId;

	// mock up the response
	return responses.formatResponse('GET', '/document/' + documentId + '/import-process', {
		documentId: documentId
	});
};

// Mock getting the status for a Document
// /api/lsp/document/{id}/translation/{locale}
MockServer.prototype.getDocumentTranslation = function (args) {
	this.validateRequest(args, {
		functionName: 'getDocument',
		requiredParameters: ['documentId', 'locale']
	});

	var documentId = args.params.documentId,
		translationLocale = args.params.locale;

	// find the document folder
	var community = this.communities[args.bearerToken],
		documentFolderPath = findFile(community.path, documentId);

	// if we haven't found it, report it
	if (!documentFolderPath) {
		self.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.getDocument(): unable to find document directory for - ' + documentId
		});
	} else {
		// see if there is a translation for requested locale
		var translationFilePath = path.join(documentFolderPath, translationLocale, documentId + '.json');
		if (fs.existsSync(translationFilePath)) {
			return JSON.parse(fs.readFileSync(translationFilePath));
		} else {
			self.throwError({
				errorCode: 400,
				errorMessage: 'mockLspServer.getDocument(): missing translation for - ' + documentId + ':' + translationLocale
			});
		}
	}
};

// Mock getting the status for a Document
// /api/lsp/document/{id}/binarytranslation/{locale}
MockServer.prototype.getBinaryTranslation = function (args) {
	this.validateRequest(args, {
		functionName: 'getBinaryTranslation',
		requiredParameters: ['documentId', 'locale']
	});

	var documentId = args.params.documentId,
		translationLocale = args.params.locale;

	// find the document folder
	var community = this.communities[args.bearerToken],
		documentFolderPath = findFile(community.path, documentId);

	// if we haven't found it, report it
	if (!documentFolderPath) {
		self.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.getBinaryTranslation(): unable to find document directory for - ' + documentId
		});
	} else {
		// read in the document metadata
		var metadataFilePath = path.join(documentFolderPath, 'metadata.json');
		if (fs.existsSync(metadataFilePath)) {
			var metadataFile = JSON.parse(fs.readFileSync(metadataFilePath));

			// see if there is a translation for requested locale
			var translationFilePath = path.join(documentFolderPath, translationLocale, metadataFile.name);
			if (fs.existsSync(translationFilePath)) {
				return fs.readFileSync(translationFilePath);
			} else {
				self.throwError({
					errorCode: 400,
					errorMessage: 'mockLspServer.getBinaryTranslation(): missing translation for - ' + documentId + ':' + translationLocale
				});
			}
		}
		else {
			self.throwError({
				errorCode: 400,
				errorMessage: 'mockLspServer.getBinaryTranslation(): missing metadata for - ' + documentId + ':' + translationLocale
			});
		}
	}
};

/*
   Mock creating a Document in a Project

   Structure of the mock server data
   +-communities/{bearerToken1}/projects/{project1}/
	 +-{document1} - random generated number used as the document ID
	 | +-metadata.json - contains the document Id & document name and source locale
	 | +-{srcLocale}
	 |   +-{document1}.json - contents of the original document
*/
MockServer.prototype.createDocument = function (args) {
	this.validateRequest(args, {
		functionName: 'createDocument',
		requiredData: ['projectId', 'name', 'sourceLocale', 'content']
	});

	var documentName = args.data.name,
		projectId = args.data.projectId,
		sourceLocale = args.data.sourceLocale,
		content = args.data.content,
		documentId;

	// generate a random number directory for the document
	documentId = 'document' + Math.floor(100000 + Math.random() * 900000);

	// find the projects directory 
	var community = this.communities[args.bearerToken],
		projects = path.join(community.path, 'projects');
	if (fs.existsSync(projects)) {
		// find this project directory
		var projectDir = path.join(projects, projectId);
		if (fs.existsSync(projectDir)) {
			// create the document directory
			var documentDir = path.join(projectDir, documentId);
			fs.mkdirSync(documentDir);

			// create the document file
			var documentData = {
				name: documentName,
				properties: {
					id: documentId,
					projectId: projectId,
					sourceLocale: sourceLocale
				}
			};
			var documentMetadata = path.join(documentDir, 'metadata.json');
			fs.writeFileSync(documentMetadata, JSON.stringify(documentData), function (err) {
				self.throwError({
					errorCode: 500,
					errorMessage: 'mockLspServer.createDocument(): failed to write document metadata file'
				});
			});

			// create the source locale directory
			var sourceLocaleDir = path.join(documentDir, sourceLocale);
			fs.mkdirSync(sourceLocaleDir);

			// create the document in the source locale directory
			var documentFile = path.join(sourceLocaleDir, documentId + '.json');
			fs.writeFileSync(documentFile, (typeof content === 'string' ? content : JSON.stringify(content)), function (err) {
				self.throwError({
					errorCode: 500,
					errorMessage: 'mockLspServer.createDocument(): failed to write document source locale file'
				});
			});

			return documentData;
		} else {
			this.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.createDocument(): unable to find project directory - ' + projectDir
			});
		}
	} else {
		this.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.createDocument(): unable to find projects directory - ' + projects
		});
	}
};

/*
   Mock creating a binary file in a Project

   Structure of the mock server data
   +-communities/{bearerToken1}/projects/{project1}/
	 +-{document1} - random generated number used as the document ID
	 | +-metadata.json - contains the document Id & document name and source locale
	 | +-{srcLocale}
	 |   +-{name} - name of the binary file
*/
MockServer.prototype.createBinary = function (args) {
	this.validateRequest(args, {
		functionName: 'createBinary',
		requiredData: ['projectId', 'name', 'sourceLocale', 'binaryFileSpec']
	});

	var documentName = args.data.name,
		projectId = args.data.projectId,
		sourceLocale = args.data.sourceLocale,
		binaryFileSpec = args.data.binaryFileSpec,
		documentId;

	// generate a random number directory for the document
	documentId = 'document' + Math.floor(100000 + Math.random() * 900000);

	// find the projects directory 
	var community = this.communities[args.bearerToken],
		projects = path.join(community.path, 'projects');
	if (fs.existsSync(projects)) {
		// find this project directory
		var projectDir = path.join(projects, projectId);
		if (fs.existsSync(projectDir)) {
			// create the document directory
			var documentDir = path.join(projectDir, documentId);
			fs.mkdirSync(documentDir);

			// create the document file
			var documentData = {
				name: documentName,
				binaryFile: true,
				properties: {
					id: documentId,
					projectId: projectId,
					sourceLocale: sourceLocale
				}
			};
			var documentMetadata = path.join(documentDir, 'metadata.json');
			fs.writeFileSync(documentMetadata, JSON.stringify(documentData), function (err) {
				self.throwError({
					errorCode: 500,
					errorMessage: 'mockLspServer.createBinary(): failed to write document metadata file'
				});
			});

			// create the source locale directory
			var sourceLocaleDir = path.join(documentDir, sourceLocale);
			fs.mkdirSync(sourceLocaleDir);

			// copy the binary file to the source locale directory
			var binaryFile = path.join(sourceLocaleDir, documentName);
			try {
				fs.copyFileSync(binaryFileSpec, binaryFile, fs.constants.COPYFILE_FICLONE);
			} catch (fe) {
				console.log('mockLspServer.createBinary() copyFileSync encountered exception');
				console.log(fe);
				this.throwError({
					errorCode: 404,
					errorMessage: 'mockLspServer.createBinary(): unable to copy file - ' + projectDir
				});
			}

			return documentData;
		} else {
			this.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.createBinary(): unable to find project directory - ' + projectDir
			});
		}
	} else {
		this.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.createBinary(): unable to find projects directory - ' + projects
		});
	}
};

/*
   Translate a document into the requested locale

   Structure of the mock server data
   +-communities/{bearerToken1}/projects/{project1}/{document1}
	 +-{locale1}
	 | +-{document1}.json
	 +-{locale2}
	 | +-{document1}.json
	 +-{locale3}
	 | +-{document1}.json
	 ...
*/
MockServer.prototype.translateDocument = function (args) {
	this.validateRequest(args, {
		functionName: 'translateDocument',
		requiredData: ['projectId', 'localeCode']
	});

	var documentId = args.params.documentId,
		projectId = args.data.projectId,
		localeCode = args.data.localeCode;

	// get the workflow from the project
	var workflow,
		community = this.communities[args.bearerToken],
		projectMetadataFile = path.join(community.path, 'projects', projectId, projectId + '.json');
	if (fs.existsSync(projectMetadataFile)) {
		// read in the project metadata
		try {
			// get the workflow to use to translate this file
			var projectMetadata = JSON.parse(fs.readFileSync(projectMetadataFile));
			workflow = mockWorkflows[projectMetadata.workflowId];
			if (!workflow || typeof workflow.translation !== 'function') {
				this.throwError({
					errorCode: 500,
					errorMessage: 'mockLspServer.translateDocument(): unable to find translation function for workflowId - ' + projectMetadata.workflowId
				});
			}

			// make sure this isn't already translated
			var translatedDirPath = path.join(community.path, 'projects', projectId, documentId, localeCode);

			// read in the document metadata
			var metadataFilePath = path.join(community.path, 'projects', projectId, documentId, 'metadata.json');
			if (fs.existsSync(metadataFilePath)) {
				var metadataFile = JSON.parse(fs.readFileSync(metadataFilePath));

				if (metadataFile.binaryFile) {
					var translatedBinaryFilePath = path.join(translatedDirPath, metadataFile.name);

					// make sure this isn't already translated
					if (!fs.existsSync(translatedBinaryFilePath)) {
						var originalBinaryFile = path.join(community.path, 'projects', projectId, documentId, metadataFile.properties.sourceLocale, metadataFile.name);
						if (fs.existsSync(originalBinaryFile)) {
							// create the translation directory
							if (!fs.existsSync(translatedDirPath)) {
								fs.mkdirSync(translatedDirPath);
							}

							// copy the binary file
							try {
								fs.copyFileSync(originalBinaryFile, translatedBinaryFilePath, fs.constants.COPYFILE_FICLONE);
							} catch (fe) {
								console.log('mockLspServer.translateDocument() copyFileSync encountered exception');
								console.log(fe);
								this.throwError({
									errorCode: 404,
									errorMessage: 'mockLspServer.translateDocument(): unable to copy file - ' + projectDir
								});
							}

							return responses.formatResponse('POST', '/document/' + documentId + '/translation', {
								documentId: documentId,
								documentStatus: 'READY',
								percentComplete: 0,
								localeCode: localeCode
							});
						}
					}
				}
				else {
					var translatedFilePath = path.join(translatedDirPath, documentId + '.json');

					// make sure this isn't already translated
					if (!fs.existsSync(translatedFilePath)) {
						// read in the original document
						var originalFile = path.join(community.path, 'projects', projectId, documentId, metadataFile.properties.sourceLocale, documentId + '.json');
						if (fs.existsSync(originalFile)) {
							var sourceData = JSON.parse(fs.readFileSync(originalFile));

							// translate the sourceData into the required locale
							var traverse = function (translateObj) {
								if (translateObj !== null && typeof translateObj === "object") {
									Object.entries(translateObj).forEach(([key, value]) => {
										translateObj[key] = traverse(value);
									});
									return translateObj;
								} else {
									return workflow.translation(localeCode, translateObj);
								}
							};

							// "translate" the data
							var translatedFile = traverse(sourceData);

							// create the translation directory
							if (!fs.existsSync(translatedDirPath)) {
								fs.mkdirSync(translatedDirPath);
							}

							// create the translation file
							fs.writeFileSync(translatedFilePath, JSON.stringify(translatedFile), function (err) {
								this.throwError({
									errorCode: 500,
									errorMessage: 'mockLspServer.translateDocument(): failed to write document translation'
								});
							});

							return responses.formatResponse('POST', '/document/' + documentId + '/translation', {
								documentId: documentId,
								documentStatus: 'READY',
								percentComplete: 0,
								localeCode: localeCode
							});
						}
					}
				}
			} else {
				this.throwError({
					errorCode: 404,
					errorMessage: 'Unable to locate document metadata file'
				});
			}
		} catch (e) {
			self.throwError({
				errorCode: 404,
				errorMessage: 'mockLspServer.translateDocument(): unable to parse metadata file for - ' + documentId
			});
		}
	} else {
		// no project meta-data file
		self.throwError({
			errorCode: 404,
			errorMessage: 'mockLspServer.translateDocument(): missing metadata file for - ' + documentId
		});
	}

	// for the mock server, if the file already exists, assume it's already been translated
	return responses.formatResponse('POST', '/document/' + documentId + '/translation', {
		documentId: documentId,
		documentStatus: 'READY',
		percentComplete: 0,
		localeCode: localeCode
	});
};

// Export the mock server
module.exports = new MockServer();