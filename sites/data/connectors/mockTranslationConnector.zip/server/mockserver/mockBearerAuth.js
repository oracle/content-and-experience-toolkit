/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */

// define the Bearer Auth node implementation
var BearerAuth = function () {};
BearerAuth.prototype.validate = function (req, res, next) {
    // only protect Mock LSP server API calls
    if (!req.path.startsWith('/lsp/rest/api')) {
        return next();
    }

    // make sure the Bearer token is included in the authorization header
    if (!req.headers.authorization || req.headers.authorization.indexOf('Bearer ') === -1) {
        return res.status(401).json({
            message: 'Missing Authorization Header'
        });
    }

    // get the bearer token
    var bearerToken = req.headers.authorization.split(' ')[1];

    // validate bearer token
    // Note: for mock server, token just needs to exist
    if (!bearerToken) {
        return res.status(401).json({
            message: 'Invalid Bearer Token'
        });
    }

    // attach bearer token to request object
    req.bearerToken = bearerToken;

    // continue with the request
    next();
};

module.exports = new BearerAuth();