/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* jshint esversion: 6 */


var mustache = require('mustache');


var defaultModel = {
    'communityId': '{{communityId}}',
    'communityTitle': '{{communityTitle}}',
    'documentExtension': '{{documentExtension}}',
    'documentId': '{{documentId}}',
    'documentStatus': '{{documentStatus}}',
    'documentTitle': '{{documentTitle}}',
    'localeCode': '{{localeCode}}',
    'percentComplete': '{{percentComplete}}',
    'projectId': '{{projectId}}',
    'projectTitle': '{{projectTitle}}',
    'userId': '{{userID}}',
    'workflowId': '{{workflowId}}',
    'workflowDescription': '{{workflowDescription}}',
    'workflowTitle': '{{workflowTitle}}'
};

var responses = {
    "GET": {
        "/community": {
            "properties": {
                "title": "Communities",
                "limit": 10,
                "total": 1,
                "offset": 0,
                "size": 1
            },
            "entities": [{
                "properties": {
                    "title": "{{communityTitle}}",
                    "id": "{{communityId}}"
                }
            }]
        },
        "/community/{{communityId}}": {
            "properties": {
                "title": "{{communityTitle}}",
                "id": "{{communityId}}"
            }
        },
        "/workflow": {
            "properties": {
                "title": "Workflows",
                "limit": 10,
                "total": 1,
                "offset": 0,
                "size": 1
            },
            "entities": [{
                "properties": {
                    "title": "{{workflowTitle}}",
                    "description": "{{workflowDescription}}",
                    "id": "{{workflowId}}"
                }
            }]
        },
        "/project": {
            "properties": {
                "title": "Projects",
                "limit": 10,
                "total": 3,
                "offset": 0,
                "size": 3
            },
            "entities": [{
                    "properties": {
                        "creation_date": 1535404704229,
                        "community_id": "{{coummunityId}}",
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{projectTitle1}}",
                        "id": "{{projectId1}}"
                    }
                },
                {
                    "properties": {
                        "creation_date": 1535404704229,
                        "community_id": "{{coummunityId}}",
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{projectTitle2}}",
                        "id": "{{projectId2}}"
                    }
                },
                {
                    "properties": {
                        "creation_date": 1535404704229,
                        "community_id": "{{coummunityId}}",
                        "workflow_id": "{{workflowId}}",
                        "due_date": 0,
                        "callback_url": null,
                        "title": "{{projectTitle3}}",
                        "id": "{{projectId3}}"
                    }
                }
            ]
        },
        "/project/{{projectId}}": {
            "properties": {
                "creation_date": 1553213135982,
                "community_id": "{{communityId}}",
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "callback_url": null,
                "title": "{{projectTitle}}",
                "id": "{{projectId}}"
            }
        },
        "/project/{{projectId}}/status": {
            "properties": {
                "title": "{{projectTitle}}",
                "progress": "{{percentComplete}}",
                "count": {
                    "format_tag": 0,
                    "document": 1,
                    "word": 1
                },
                "status": "ACTIVE"
            }
        },
        "/document/{{documentId}}": {
            "properties": {
                "complete_date": 1553213312197,
                "project_id": "{{projectId}}",
                "created_by_user": "{{userId}}",
                "title": "{{documentTitle}}",
                "upload_date": 1553213235356,
                "modified_date": 1553213312166,
                "external_url": null,
                "last_uploaded_date": 1553213235356,
                "status": "{{documentStatus}}",
                "name": "{{documentName}}",
                "id": "{{documentId}}",
                "extension": "{{documentExtension}}"
            }
        },
        "/document/{{documentId}}/translation/{{localeCode}}": {
            "properties": {
                "percent_complete": "{{percentComplete}}",
                "due_date": 0,
                "complete_date": 1553213312180,
                "start_date": 1553213312051,
                "words": 1,
                "locale_code": "{{localeCode}}",
                "status": "{{documentStatus}}",
                "id": "{{documentId}}"
            }
        },
        "/document/{{documentId}}/content?{{localeCodeParameter}}={{localeCode}}": {
            "properties": {
                "percent_complete": "{{percentComplete}}",
                "due_date": 0,
                "complete_date": 1553213312180,
                "start_date": 1553213312051,
                "words": 1,
                "locale_code": "{{localeCode}}",
                "status": "{{documentStatus}}",
                "id": "{{documentId}}"
            }
        }
    },
    "POST": {
        "/project": {
            "properties": {
                "creation_date": 1553213135982,
                "community_id": "{{communityId}}",
                "workflow_id": "{{workflowId}}",
                "due_date": 0,
                "callback_url": null,
                "title": "{{projectTitle}}",
                "id": "{{projectId}}"
            }
        },
        "/document": {
            "properties": {
                "process_id": "{{projectId}}",
                "progress": 0,
                "title": "{{projectTitle}}",
                "upload_date": 0,
                "id": "{{documentId}}"
            }
        },
        "/document/{{documentId}}/translation": {
            "properties": {
                "percent_complete": "{{percentComplete}}",
                "due_date": 0,
                "complete_date": 0,
                "start_date": 0,
                "words": 1,
                "locale_code": "{{localeCode}}",
                "status": "{{documentStatus}}",
                "id": null
            }
        }
    }
};
var RESPONSE_TEMPLATE = JSON.stringify(responses);

var MockResponses = function () {};

// Format the response for the URL request
// Applies the model to the response to insert expected values
// callType:  [ GET | POST ]
// url:  e.g. "/document/6a6ee468-33f3-4c8d-ae54-e755400e66d4/translation":"
// model: e.g. { "documentId": "6a6ee468-33f3-4c8d-ae54-e755400e66d4", "localeCode": "fr-FR", "documentStatus": "COMPLETE", "percentComplete": 100 }
MockResponses.prototype.formatResponse = function (callType, url, model) {
    var response;
    try {
        // update the default model with the included values
        var templateModel = JSON.parse(JSON.stringify(defaultModel));
        Object.keys(model).forEach(function (key) {
            templateModel[key] = model[key];
        });

        // apply the combined model to the template
        var mockResponses = mustache.render(RESPONSE_TEMPLATE, templateModel);

        // get the requested response
        var responses = JSON.parse(mockResponses)[callType.toUpperCase()];
        response = responses[url];
    } catch (e) {
        // log error
        console.log(e);
    }

    // handle the response
    if (response) {
        return response;
    } else {
        var errorMessage = "mockResponses.getResponse(): Unable to create response for request - " + url;
        console.log(errorMessage);
        throw ({
            errorCode: 400,
            errorMessage: errorMessage
        });
    }
};

// Export the mock responses
module.exports = new MockResponses();