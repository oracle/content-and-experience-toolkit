/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console, process, __dirname */
/* jshint esversion: 6 */

/**
 * Test Language Connector.
 */

var port = process.env.CECLSP_PORT || 8084;
process.env.CECLSP_PORT = port;  // store the port for the mock server provider

var express = require('express'),
	bodyParser = require('body-parser'),
	app = express(),
	fs = require('fs'),
	path = require('path'),
	request = require('request'),
	connectorRouter = require('./server/translation-connector/connector/sampleConnectorRouter.js'),
	basicAuth = require('./server/translation-connector/connector/sampleBasicAuth'),
	mockLspRouter = require('./server/mockserver/mockLspRouter.js'),
	mockBearerAuth = require('./server/mockserver/mockBearerAuth');

// project root is the current dir
var projectDir = path.join(__dirname);
var sitesDir = path.join(projectDir, 'data');

// setup basic auth for all connector requests
app.use(basicAuth.validate);

// setup bearer auth for all mock server requests
app.use(mockBearerAuth.validate);

// setup the body parser for POST requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));

// enable cookies
request = request.defaults({
	jar: true,
	proxy: null
});

app.use('/node_modules', express.static(path.join(projectDir, 'node_modules')));

// All /connector/api* requests are handled by the connectorRouter
app.get('/connector/rest/api*', connectorRouter);
app.post('/connector/rest/api*', connectorRouter);
app.delete('/connector/rest/api*', connectorRouter);

// All /lsp/api* requests are handled by mockLspRouter
app.get('/lsp/rest/api*', mockLspRouter);
app.post('/lsp/rest/api*', mockLspRouter);


// starter site request
app.get('*', (req, res) => {
	var filePathSuffix = req.path;
	if (filePathSuffix.indexOf('/') === 0) {
		filePathSuffix = filePathSuffix.substring(1);
	}

	var filePath = path.join(sitesDir, filePathSuffix);
	if (!existsAndIsFile(filePath)) {
		filePath = path.join(sitesDir, 'index.html');
	}

	if (existsAndIsFile(filePath)) {
		res.sendFile(filePath);
	} else {
		console.log('404: ' + filePath);
		res.writeHead(404, {});
		res.end();
	}
});

// Handle startup errors
process.on('uncaughtException', function (err) {
	'use strict';
	if (err.code === 'EADDRINUSE' || err.errno === 'EADDRINUSE') {
		console.log('======================================');
		console.error(`Another server is using port ${err.port}. Stop that process and try to start the server again.`);
		console.log('======================================');
	} else {
		console.error(err);
	}
});

var existsAndIsFile = function (filePath) {
	var ok = false;
	if (fs.existsSync(filePath)) {
		var statInfo = fs.statSync(filePath);
		ok = statInfo && statInfo.isFile();
	}
	return ok;
};

// determine if the module is being loaded by "require" or by "node"
if (require.main === module) {
	// running under node, start the server
	var server = app.listen(port, function () {
		"use strict";
		console.log('NodeJS running...:');
		console.log('Site page: http://localhost:' + port);
	});
} else {
	// running under tests, let the tests handle the server lifecycle
	module.exports = app;
}
