// Gulp and plugins
var gulp = require('gulp'),
	del = require('del'),
	noop = require('gulp-noop'),
	terser = require('gulp-terser'),
	replace = require('gulp-replace'),
	rename = require('gulp-rename'),
	sass = require('gulp-sass'),
	cleanCss = require('gulp-clean-css'),
	merge2 = require('merge2');

//
// NLS Tasks
//
gulp.task('nls', function () {
	// the "en" folder isn't created by translations - copy the "root" source into the "en" folder
	return gulp.src('assets/nls/root/*.*')
		.pipe(gulp.dest('assets/nls/en'));
});
gulp.task('clean-nls', function () {
	// remove the "en" folder, it is populated from the "root" folder
	return del(['assets/nls/en']);
});

//
// SASS/CSS Tasks
//
gulp.task('sass', function () {
	// compile all sass files into css under <template>/assets
	return merge2(gulp.src('./assets/**/*.scss')
		.pipe(sass({
			outputStyle: 'expanded'
		}).on('error', sass.logError))
		.pipe(cleanCss({
			compatibility: 'ie9'
		}))
		.pipe(gulp.dest(function (file) {
			return file.base;
		})));
});

gulp.task('clean-sass', function () {
	// ToDo: clean up any SASS generated CSS files'
	return Promise.resolve('ToDo: clean-sass');
});

gulp.task('watch', function () {
	// watch scss file changes and compile into css
	gulp.watch('./assets/**/*.scss', ['sass']);
});

//
// Uglify/Minify Tasks
//
function uglifyIfNeeded(options) {
	return process.env.SCS_DEBUG === '1' ? noop() : terser(options).on('error', function (err) {
		console.log(err.toString());
	});
}

gulp.task('uglify', function () {
	// minify all .js files under <template>/asset
	return gulp.src('./assets/**/!(*.min)*.js', {
			base: './'
		})
		.pipe(uglifyIfNeeded({
			output: {
				comments: 'some'
			}
		}))
		.pipe(gulp.dest('./'));
});

gulp.task('clean-uglify', function () {
	// ToDO: clean up any uglify generated files.
	return Promise.resolve('ToDo: clean-uglify');
});

//
// the default task
//
gulp.task('default', gulp.series('clean-nls', 'clean-sass', 'clean-uglify', gulp.parallel('nls', 'sass', 'uglify'), function (done) {
	done();
}));