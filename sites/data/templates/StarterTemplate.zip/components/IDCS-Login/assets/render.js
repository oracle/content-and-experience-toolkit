/* globals define */
define(['knockout', 
        'jquery', 
		'css!./styles/design.css',
		'css!./styles/loader.css',
		'text!./template.html'], 
		function (ko, $, css, loader, textTemplate) {
	'use strict';
	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var ComponentViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = SCSRenderAPI.getRenderMode();
		self.id = args.id;

		// create the observable
		self.editModeText = ko.observable("");
		
		// handle initialization 
		self.customSettingsDataInitialized = ko.observable(false);
		self.initialized = ko.computed(function () {
			return self.customSettingsDataInitialized();
		}, self);

		// Handle property changes
		self.updateCustomSettingsData = function(customData) {
			self.editModeText( customData && customData.editModeText );
			self.customSettingsDataInitialized(true);
		};
		
		// Initialize the customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);
	
		//  Listen for changes to the settings data.
		self.updateSettings = function(settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		SitesSDK.subscribe('SETTINGS_UPDATED', self.updateSettings);
	};

	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var ComponentImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	ComponentImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	ComponentImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new ComponentViewModel(args);
	};
	// create the template based on the initial values
	ComponentImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content';
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
				textTemplate + 
				'</div>';
		};
	
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	ComponentImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			
			// Do not include any js code when in builder - instead we will just
			// show the components edit mode text...
			if( !( this.viewModel.mode === 'edit' || 
			       this.viewModel.mode === 'navigate' ||
				   this.viewModel.mode === 'preview' ))
			{
				// Compute path to resource files. (Note that we only ever load in view mode.)
				var loginAppBaseUrl = 'scs-components-path/IDCS-Login/assets/';
		
				require([loginAppBaseUrl + "loadResource"], function() {
				  require([loginAppBaseUrl + "idcsAuthnSDK"], function() {
				    require([loginAppBaseUrl + "loginApp"]);
				  });
				}); 
			}
			
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);
		//
		// callback - update: handle property change event
		//
		this.update = $.proxy(function (args) {
			var self = this;
			// deal with each property changed
			$.each(args.properties, function (index, property) {
				if (property) {
					if (property.name === 'customSettingsData') {
						self.viewModel.updateComponentData(property.value);
					}
				}
			});
		}, this);
		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var componentFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new ComponentImpl(args));
		}
	};
	return componentFactory;
});
