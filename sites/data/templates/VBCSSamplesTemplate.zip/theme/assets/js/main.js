/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global SCSRenderAPI */
(function () {

	'use strict';

	// main entry point into the JET app
	// This sets up the JET require.js configuration and then runs the JET code on the page
	var runApp = function () {

		var renderAPI = SCSRenderAPI;
		var siteName = renderAPI && renderAPI.siteInfo && renderAPI.siteInfo.properties ? renderAPI.siteInfo.properties.siteName : '';
		console.log('Site name: ' + siteName);
	};

	var START_RENDERING_EVENT = 'scsrenderstart';
	if (document.addEventListener) {
		document.addEventListener(START_RENDERING_EVENT, runApp, false);
	} else if (document.attachEvent) {
		document.documentElement.scsrenderstart = 0;
		document.documentElement.attachEvent('onpropertychange', function (event) {
			if (event && (event.propertyName === START_RENDERING_EVENT)) {
				runApp();
			}
		});
	}
}());
