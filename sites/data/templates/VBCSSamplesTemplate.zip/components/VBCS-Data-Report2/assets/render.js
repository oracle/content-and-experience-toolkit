/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define */
define(['knockout', 'jquery', 'css!./styles/design.css', 'text!./comptemplate.html'], function (ko, $, css, comptemplate) {
	'use strict';

	var getVBCSServerURL = function () {
		var serverPromise = new Promise(function (resolve, reject) {
			// First try to get from siteinfo 
			var siteConnections = SCSRenderAPI.getSiteProperty('siteConnections');
			var serverUrl = siteConnections && siteConnections.VBCSConnection;

			if (serverUrl) {
				console.log('Get VBCS server from siteinfo: ' + serverUrl);
				resolve({
					'url': serverUrl
				});
			} else {
				// Get from integrations
				var configUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=VBCS';
				$.ajax({
					type: 'GET',
					dataType: 'json',
					url: configUrl,
					success: function (data) {
						var appInfo = data.ResultSets.AFApplicationInfo;
						var enabled;
						if (appInfo) {
							for (var i = 0; i < appInfo.fields.length; i += 1) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}
								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
						console.log('Get VBCS server from Idc Service: ' + serverUrl);
						resolve({
							'url': serverUrl
						});
					},
					error: function (xhr, status, err) {
						console.log('Request failed: url:' + configUrl + ' status: ' + status + ' error: ' + err);
						resolve({
							'url': serverUrl
						});
					}
				});
			}
		});
		return serverPromise;
	};

	var getAuthToken = function (args) {
		// dummy function if callbacks not supplied
		var dummyCallback = function () {};

		// extract the args and create the server URL
		var serverURL = (args.serverURL || '/').split('/ic/')[0],
			successCallback = args.successCallback || dummyCallback,
			errorCallback = args.errorCallback || dummyCallback,
			tokenURL = serverURL + '/ic/builder/resources/security/token';

		// For VBCS to get the authtoken:
		//  - make a POST call to /ic/builder/resources/security/token
		//  - include scope=run-time form parameter
		var getToken = function (tokenURL, successCallback, errorCallback) {
			$.ajax({
				'type': 'POST',
				'url': tokenURL,
				data: {
					scope: 'run-time'
				},
				'xhrFields': {
					withCredentials: true
				},
				'success': successCallback
			}).fail(errorCallback);
		};

		// try to get the token normally
		getToken(tokenURL,
			function (resp, status, xhr) {
				var ct = xhr.getResponseHeader("content-type") || "";

				// if the response was an HTML Form....
				if (ct.indexOf('html') > -1) {
					// parse the form and submit it
					var parser = new DOMParser(),
						htmlDoc = parser.parseFromString(resp, "text/html"),
						forms = htmlDoc.getElementsByTagName("form");
					if (forms.length === 1) {
						var f = forms[0];
						$.ajax({
							'type': 'POST',
							'url': f.action,
							'data': $(f).serialize(),
							'xhrFields': {
								'withCredentials': true
							},
							'success': function () {
								// retry getting the token now the form was auto-submitted
								getToken(tokenURL, successCallback, errorCallback);
							}
						}).fail(function () {
							// even if the form submit failed, retry getting the token
							getToken(tokenURL, successCallback, errorCallback);
						});
					}
				} else {
					// already logged in return the token
					successCallback(resp);
				}
			},
			errorCallback);
	};
	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var VBCSReportViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		self.initialized = ko.observable(false);
		self.VBCSServerUrl = ko.observable();

		self.requests = ko.observableArray();
		self.ticks = ko.observableArray();
		
		// Get VBCS server
		var serverPromise = getVBCSServerURL();
		serverPromise.then(function (result) {
			self.VBCSServerUrl(result.url);
			self.initialized(true);
			self.getRequests();
		});

		//
		// Raise the given trigger.
		//
		self.raiseTrigger = function (triggerName) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'payloadData': 'some data here'
				}
			});
		};

		// click Submit
		self.getRequests = function () {
			var vbcsServer = self.VBCSServerUrl();
			var authorization, token;
			var appName = 'requestform',
				mode = 'rt',
				appVersion = 'live',
				businessObject = 'Requestform';
			var url = vbcsServer + '/' + mode + '/' + appName + '/' + appVersion + '/resources/data/' + businessObject;
			
			// get token first
			getAuthToken({
				'serverURL': self.VBCSServerUrl(),
				'successCallback': function (data) {
					console.log(data);
					token = data;
					authorization = (token.token_type ? token.token_type : 'Bearer') + ' ' + token.access_token;
					url = url + '?limit=999&orderBy=creationDate:desc';
					$.ajax({
						type: 'GET',
						url: url,
						beforeSend: function (xhr) {
							xhr.setRequestHeader('Authorization', authorization);
						},
						success: function (data) {
							console.log(data);
							if (data && data.count > 0) {
								self.showChart(data.items);
							}
						},
						error: function (jqXhr, textStatus, errorThrown) {
							console.log('Error:');
							console.log(jqXhr);
							
						}
					});
				},
				'errorCallback': function (xhr, status, err) {
					if (xhr && xhr.status === 200) {
						token = xhr.responseText;
						console.log('Got token');
					} else {
						console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
						
					}
				}
			});

		};

		self.showChart = function (items) {
			var weekDayCounts = [0, 0, 0, 0, 0, 0, 0];
			var weekDayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
			for(var i = 0; i < items.length; i++) {
				var d = new Date(items[i].creationDate);
				var day = d.getDay();
				if (day >=0 && day < 7) {
					weekDayCounts[day] = weekDayCounts[day] + 1;
				}
			}
			console.log(weekDayCounts);
	
			var max = 0;
			var results = [];
			for(var i = 0; i < weekDayCounts.length; i++) {
				if (max < weekDayCounts[i]) {
					max = weekDayCounts[i];
				}
			}
			
			var lines = 7,
				buckets = 5;
			var gap = Math.round(max / buckets);
			var top = gap * (lines - 1);
			if (max > top) {
				gap += 1;
			}
			console.log('max: ' + max + ' gap: ' + gap);
			var ticks = [];
			for(var i = 0; i < lines; i++) {
				ticks[i] = {
					value: i * gap
				};
			}
			console.log(ticks);
			self.ticks(ticks.reverse());
			
			for(var i = 0; i < weekDayCounts.length; i++) {
				var height = (weekDayCounts[i] / gap) * 60;
				results.push({
					height: height.toString() + 'px',
					value: weekDayCounts[i],
					barcss: weekDayNames[i].toLowerCase()
				});
			}
			console.log(results);
			self.requests(results);
		};

		// execute action handler
		self.executeActionsListener = function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;
		};

		// 
		// Handle property changes
		//
		self.updateCustomSettingsData = $.proxy(function (customData) {}, self);
		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		// listen for the EXECUTE ACTION request to handle custom actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeActionsListener, self));
		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));

		//
		// Initialize customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);

	};

	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var VBCSReportImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	VBCSReportImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	VBCSReportImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new VBCSReportViewModel(args);
	};
	// create the template based on the initial values
	VBCSReportImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			comptemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	VBCSReportImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);

		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var VBCSReportFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new VBCSReportImpl(args));
		}
	};
	return VBCSReportFactory;
});
