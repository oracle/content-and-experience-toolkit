/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define */
define(['knockout', 'jquery', 'css!./styles/design.css', 'text!./comptemplate.html'], function (ko, $, css, comptemplate) {
	'use strict';

	var getVBCSServerURL = function () {
		var serverPromise = new Promise(function (resolve, reject) {
			// First try to get from siteinfo 
			var siteConnections = SCSRenderAPI.getSiteProperty('siteConnections');
			var serverUrl = siteConnections && siteConnections.VBCSConnection;

			if (serverUrl) {
				console.log('Get VBCS server from siteinfo: ' + serverUrl);
				resolve({
					'url': serverUrl
				});
			} else {
				// Get from integrations
				var configUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=VBCS';
				$.ajax({
					type: 'GET',
					dataType: 'json',
					url: configUrl,
					success: function (data) {
						var appInfo = data.ResultSets.AFApplicationInfo;
						var enabled;
						if (appInfo) {
							for (var i = 0; i < appInfo.fields.length; i += 1) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}
								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
						console.log('Get VBCS server from Idc Service: ' + serverUrl);
						resolve({
							'url': serverUrl
						});
					},
					error: function (xhr, status, err) {
						console.log('Request failed: url:' + configUrl + ' status: ' + status + ' error: ' + err);
						resolve({
							'url': serverUrl
						});
					}
				});
			}
		});
		return serverPromise;
	};

	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var VBCSGatedFormViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		self.initialized = ko.observable(false);
		self.requestSuccessMsg = ko.observable();
		self.requestFailMsg = ko.observable();
		self.VBCSServerUrl = ko.observable();
		self.showDownload = ko.observable(false);

		self.firstName = ko.observable();
		self.lastName = ko.observable();
		self.email = ko.observable();
		self.phone = ko.observable();
		self.company = ko.observable();
		self.jobTitle = ko.observable();

		// Enable submit only after all required fields have values
		self.canSubmit = ko.computed(function () {
			return self.firstName() && self.lastName() && self.email();
		}, self);

		// Get VBCS server
		var serverPromise = getVBCSServerURL();
		serverPromise.then(function (result) {
			self.VBCSServerUrl(result.url);
			self.initialized(true);
		});

		//
		// Raise the given trigger.
		//
		self.raiseTrigger = function (triggerName) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'payloadData': 'some data here'
				}
			});
		};

		// click binding
		self.sendRequest = function (data, event) {
			var vbcsServer = self.VBCSServerUrl();
			var appName = 'requestform',
				appVersion = 'live',
				businessObject = 'Registration';
			var url = vbcsServer + '/rt/' + appName + '/' + appVersion + '/resources/data/' + businessObject;
			var payload = {
				'firstName': self.firstName(),
				'lastName': self.lastName(),
				'email': self.email(),
				'phone': self.phone(),
				'company': self.company(),
				'jobTitle': self.jobTitle()
			};

			$.ajax({
				type: 'POST',
				url: url,
				beforeSend: function (xhr) {
					xhr.setRequestHeader('Content-type', 'application/vnd.oracle.adf.resourceitem+json');
				},
				data: JSON.stringify(payload),
				dataType: 'json',
				success: function (data) {
					console.log(data);
					self.requestFailMsg('');
					self.requestSuccessMsg('Request has been submitted successfully');
					self.firstName('');
					self.lastName('');
					self.email('');
					self.phone('');
					self.company('');
					self.jobTitle('');
					self.showDownload(true);
				},
				error: function (jqXhr, textStatus, errorThrown) {
					console.log('Error:');
					console.log(jqXhr);
					self.requestSuccessMsg('');
					self.requestFailMsg('Failed to submit the request');
				}
			});
		};


		// execute action handler
		self.executeActionsListener = function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;
		};

		//
		// Raise the given trigger.
		//
		self.raiseTrigger = function (triggerName) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'payloadData': 'https://docs.oracle.com/en/cloud/paas/content-cloud/developer/developing-oracle-content-and-experience-cloud.pdf'
				}
			});
		};

		// click binding
		self.startDownload = function (data, event) {
			console.log('Raise trigger: VBCSGatedFormSubmitted');
			self.raiseTrigger("VBCSGatedFormSubmitted"); // matches appinfo.json
		};

		self.closeDownload = function (data, event) {
			self.requestSuccessMsg('');
			self.requestFailMsg('');
			self.showDownload(false);
		};

		// 
		// Handle property changes
		//
		self.updateCustomSettingsData = $.proxy(function (customData) {
		}, self);
		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		// listen for the EXECUTE ACTION request to handle custom actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeActionsListener, self));

		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));

		//
		// Initialize customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);
	};


	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var VBCSGatedFormImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	VBCSGatedFormImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	VBCSGatedFormImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new VBCSGatedFormViewModel(args);
	};
	// create the template based on the initial values
	VBCSGatedFormImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			comptemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	VBCSGatedFormImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);
		
		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var VBCSGatedFormFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new VBCSGatedFormImpl(args));
		}
	};
	return VBCSGatedFormFactory;
});
