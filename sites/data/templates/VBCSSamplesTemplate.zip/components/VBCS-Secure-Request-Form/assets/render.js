/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define */
define(['knockout', 'jquery', 'css!./styles/design.css', 'text!./comptemplate.html'], function (ko, $, css, comptemplate) {
	'use strict';

	var getVBCSServerURL = function () {
		var serverPromise = new Promise(function (resolve, reject) {
			// First try to get from siteinfo 
			var siteConnections = SCSRenderAPI.getSiteProperty('siteConnections');
			var serverUrl = siteConnections && siteConnections.VBCSConnection;

			if (serverUrl) {
				console.log('Get VBCS server from siteinfo: ' + serverUrl);
				resolve({
					'url': serverUrl
				});
			} else {
				// Get from integrations
				var configUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=VBCS';
				$.ajax({
					type: 'GET',
					dataType: 'json',
					url: configUrl,
					success: function (data) {
						var appInfo = data.ResultSets.AFApplicationInfo;
						var enabled;
						if (appInfo) {
							for (var i = 0; i < appInfo.fields.length; i += 1) {
								if (appInfo.fields[i].name === 'dAppEndPoint') {
									serverUrl = appInfo.rows[appInfo.currentRow][i];
								} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
									enabled = appInfo.rows[appInfo.currentRow][i];
								}
								if (serverUrl && enabled) {
									break;
								}
							}
							if (enabled !== '1') {
								serverUrl = '';
							}
						}
						console.log('Get VBCS server from Idc Service: ' + serverUrl);
						resolve({
							'url': serverUrl
						});
					},
					error: function (xhr, status, err) {
						console.log('Request failed: url:' + configUrl + ' status: ' + status + ' error: ' + err);
						resolve({
							'url': serverUrl
						});
					}
				});
			}
		});
		return serverPromise;
	};

	var getUser = function () {
		var userPromise = new Promise(function (resolve, reject) {
			var url = '/documents/web?IdcService=SCS_GET_TENANT_CONFIG';
			var userName = '';
			$.ajax({
				type: 'GET',
				dataType: 'json',
				url: url,
				success: function (data) {
					userName = data && data.LocalData && data.LocalData.dUserFullName;
					console.log('Get user from Idc Service: ' + url + ' name ' + userName);
					resolve({
						'userName': userName
					});
				},
				error: function (xhr, status, err) {
					console.log('Request failed: url:' + url + ' status: ' + status + ' error: ' + err);
					resolve({
						'userName': userName
					});
				}
			});
		});
		return userPromise;
	};

	var getAuthToken = function (args) {
		// dummy function if callbacks not supplied
		var dummyCallback = function () {};

		// extract the args and create the server URL
		var serverURL = (args.serverURL || '/').split('/ic/')[0],
			successCallback = args.successCallback || dummyCallback,
			errorCallback = args.errorCallback || dummyCallback,
			tokenURL = serverURL + '/ic/builder/resources/security/token';

		// For VBCS to get the authtoken:
		//  - make a POST call to /ic/builder/resources/security/token
		//  - include scope=run-time form parameter
		var getToken = function (tokenURL, successCallback, errorCallback) {
			$.ajax({
				'type': 'POST',
				'url': tokenURL,
				data: {
					scope: 'run-time'
				},
				'xhrFields': {
					withCredentials: true
				},
				'success': successCallback
			}).fail(errorCallback);
		};

		// try to get the token normally
		getToken(tokenURL,
			function (resp, status, xhr) {
				var ct = xhr.getResponseHeader("content-type") || "";

				// if the response was an HTML Form....
				if (ct.indexOf('html') > -1) {
					// parse the form and submit it
					var parser = new DOMParser(),
						htmlDoc = parser.parseFromString(resp, "text/html"),
						forms = htmlDoc.getElementsByTagName("form");
					if (forms.length === 1) {
						var f = forms[0];
						$.ajax({
							'type': 'POST',
							'url': f.action,
							'data': $(f).serialize(),
							'xhrFields': {
								'withCredentials': true
							},
							'success': function () {
								// retry getting the token now the form was auto-submitted
								getToken(tokenURL, successCallback, errorCallback);
							}
						}).fail(function () {
							// even if the form submit failed, retry getting the token
							getToken(tokenURL, successCallback, errorCallback);
						});
					}
				} else {
					// already logged in return the token
					successCallback(resp);
				}
			},
			errorCallback);
	};
	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var VBCSRequestFormViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		self.initialized = ko.observable(false);
		self.requestSuccessMsg = ko.observable();
		self.requestFailMsg = ko.observable();
		self.VBCSServerUrl = ko.observable();
		self.name = ko.observable();
		self.email = ko.observable();
		self.phone = ko.observable();
		self.subject = ko.observable();
		self.message = ko.observable();

		// Enable submit only after all required fields have values
		self.canSubmit = ko.computed(function () {
			return self.name() && self.email();
		}, self);

		// Get user 
		var userPromise = getUser();
		userPromise.then(function (result) {
			var userName = result && result.userName;
			self.name(userName === 'anonymous' ? '' : userName);
		});

		// Get VBCS server
		var serverPromise = getVBCSServerURL();
		serverPromise.then(function (result) {
			self.VBCSServerUrl(result.url);
			self.initialized(true);
		});

		//
		// Raise the given trigger.
		//
		self.raiseTrigger = function (triggerName) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'payloadData': 'some data here'
				}
			});
		};

		// click Submit
		self.sendRequest = function (data, event) {
			var vbcsServer = self.VBCSServerUrl();
			var authorization, token;
			var appName = 'securerequestform',
				mode = 'rt',
				appVersion = 'live',
				businessObject = 'Requestform';
			var url = vbcsServer + '/' + mode + '/' + appName + '/' + appVersion + '/resources/data/' + businessObject;
			var payload = {
				"name": self.name(),
				"email": self.email(),
				"phone": self.phone(),
				"subject": self.subject(),
				"message": self.message()
			};
			// get token first
			getAuthToken({
				'serverURL': self.VBCSServerUrl(),
				'successCallback': function (data) {
					console.log(data);
					token = data;
					authorization = (token.token_type ? token.token_type : 'Bearer') + ' ' + token.access_token;
					$.ajax({
						type: 'POST',
						url: url,
						beforeSend: function (xhr) {
							xhr.setRequestHeader('Content-type', 'application/vnd.oracle.adf.resourceitem+json');
							xhr.setRequestHeader('Authorization', authorization);
						},
						data: JSON.stringify(payload),
						dataType: 'json',
						success: function (data) {
							console.log(data);
							self.requestFailMsg('');
							self.requestSuccessMsg('Request has been submitted successfully');
							self.name('');
							self.email('');
							self.phone('');
							self.subject('');
							self.message('');
						},
						error: function (jqXhr, textStatus, errorThrown) {
							console.log('Error:');
							console.log(jqXhr);
							self.requestSuccessMsg('');
							self.requestFailMsg('Failed to submit the request');
						}
					});
				},
				'errorCallback': function (xhr, status, err) {
					if (xhr && xhr.status === 200) {
						token = xhr.responseText;
						console.log('Got token');
					} else {
						console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
						self.requestSuccessMsg('');
						self.requestFailMsg('Failed to get authorization token');
					}
				}
			});

		};

		// execute action handler
		self.executeActionsListener = function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;
		};

		// 
		// Handle property changes
		//
		self.updateCustomSettingsData = $.proxy(function (customData) {}, self);
		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		// listen for the EXECUTE ACTION request to handle custom actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeActionsListener, self));
		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));

		//
		// Initialize customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);

	};

	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var VBCSRequestFormImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	VBCSRequestFormImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	VBCSRequestFormImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new VBCSRequestFormViewModel(args);
	};
	// create the template based on the initial values
	VBCSRequestFormImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			comptemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	VBCSRequestFormImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);

		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var VBCSRequestFormFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new VBCSRequestFormImpl(args));
		}
	};
	return VBCSRequestFormFactory;
});
