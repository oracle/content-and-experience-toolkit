var mustache = require('mustache');

var AboutPageCompiler = function () {};

AboutPageCompiler.prototype.compile = function (args) {
	var self = this,
		layoutMarkup = args.layoutMarkup;

	self.SCSCompileAPI = args.SCSCompileAPI;

	return new Promise(function (resolve, reject) {
		var compiledPage = layoutMarkup,
			id = self.SCSCompileAPI.navigationRoot;

		// page is compiled so there is no FOUC, can remove the opacity workaround
		compiledPage = compiledPage.replace('opacity: 0;', 'opacity: 1;');

		// remove the dynamic menu creation, we'll be compiling it here
		compiledPage = compiledPage.replace('<script src="_scs_theme_root_/assets/js/topnav.js"></script>', '');

		// add link to Home page...
		var homePageURL = (self.SCSCompileAPI.getPageLinkData(id) || {}).href;
		if (homePageURL) {
			compiledPage = compiledPage.replace('class="navbar-brand" href="#"', 'class="navbar-brand" href="' + homePageURL + '"');
		}

		// build the menu and add it to the page
		var navMenu = self.createNavMenu();
		compiledPage = compiledPage.replace('<!-- navigation menu goes in here -->', navMenu);

		// return the compiled page
		resolve(compiledPage);
	});
};

AboutPageCompiler.prototype.createNavMenu = function () {
	var self = this,
		structureMap = self.SCSCompileAPI.structureMap,
		id = self.SCSCompileAPI.navigationRoot,
		navList = self.createNavItem(id); // start with Home link...

	// top level pages...
	var curID,
		navItem,
		navLink,
		navID,
		nodes = structureMap[id].children;

	//sub-menu...
	var createSubNodes = function (subnodes) {
		var allNodes = '';
		for (var sub = 0; sub < subnodes.length; sub++) {
			if (self.isNodeHidden(subnodes[sub]))
				continue;
			// add item in the sub-level navigation menu...
			allNodes = allNodes + self.createSubNavItem(subnodes[sub]);
		}
		return allNodes;
	};

	for (var n = 0; n < nodes.length; n++) {
		curID = nodes[n];
		// skip hidden node...
		if (self.isNodeHidden(curID))
			continue;

		if ((structureMap[curID].children.length > 0) && !self.allNodeChildrenAreHidden(curID)) {
			// add top level node with childeren...
			var template =
				'<li class="nav-item dropdown">' +
				'<a class="nav-link dropdown-toggle" href="#" id="{{navID}}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' +
				'{{text}}' +
				'</a>' +
				'<div class="dropdown-menu dropdown-menu-right" aria-labelledby="{{navID}}">' +
				'{{{subNodes}}}' +
				'</div>' +
				'</li>',
				model = {
					navID: "navbarDropdown" + structureMap[curID].name.replace(/\s/g, ''),
					subNodes: createSubNodes(structureMap[curID].children),
					text: structureMap[curID].name
				};

				navItem = mustache.render(template, model);
		} else {
			// add rop level node without childeren...
			navItem = self.createNavItem(curID);
		}

		navList += navItem;
	}

	return navList;
};

AboutPageCompiler.prototype.createNavItem = function (id) {
	var linkData = this.SCSCompileAPI.getPageLinkData(id) || {},
		template = '<li class="nav-item {{activeClass}}"><a class="nav-link" {{{href}}} {{{target}}}>{{text}}</a></li>',
		model = {
			activeClass: (id === this.SCSCompileAPI.navigationCurr) ? 'active' : '',
			href: 'href="' + linkData.href + '"' || '',
			target: 'target="' + linkData.target + '"' || '',
			text: this.SCSCompileAPI.structureMap[id].name
		};

	return mustache.render(template, model);
};

// returns <a class="dropdown-item"> tag for a sub-navigation menu item...
AboutPageCompiler.prototype.createSubNavItem = function (id) {
	var linkData = this.SCSCompileAPI.getPageLinkData(id) || {},
		template = '<a class="dropdown-item {{activeClass}}" {{{href}}} {{{target}}}>{{text}}</a>',
		model = {
			activeClass: (id === this.SCSCompileAPI.navigationCurr) ? 'active' : '',
			href: 'href="' + linkData.href + '"' || '',
			target: 'target="' + linkData.target + '"' || '',
			text: this.SCSCompileAPI.structureMap[id].name
		};

	return mustache.render(template, model);
};

// returns true if given navigation node is hidden...
AboutPageCompiler.prototype.isNodeHidden = function (id) {
	var navNode, isHidden = false;
	if (this.SCSCompileAPI.structureMap) {
		navNode = this.SCSCompileAPI.structureMap[id];
		if (navNode) {
			isHidden = (true === navNode.hideInNavigation);
		}
	}
	return isHidden;
};

// returns true if all children of given navigation node are hidden...
AboutPageCompiler.prototype.allNodeChildrenAreHidden = function (id) {
	var subnodes = this.SCSCompileAPI.structureMap[id].children,
		allHidden = (subnodes.length > 0) ? true : false;

	for (var sub = 0; sub < subnodes.length; sub++) {
		if (!this.isNodeHidden(subnodes[sub])) {
			allHidden = false;
			break;
		}
	}
	return allHidden;
};


module.exports = new AboutPageCompiler();