var fs = require('fs'),
    path = require('path'),
    mustache = require('mustache');


var MyComp = function () {};

MyComp.prototype.compile = function (args) {
    var compId = args.compId,
        customSettingsData = args.customSettingsData,
        componentLayout = args.componentLayout;

    return new Promise(function (resolve, reject) {
        try {
            var dir = __dirname,
                templateFile = path.join(dir, 'compile.html'),
                template = fs.readFileSync(templateFile, 'utf8'),
                showTopLayout = componentLayout === 'top';

            var model = {
                contentId: compId + '_content_' + args.viewMode,
                paragraphStyle: (showTopLayout ? '' : 'flex-grow:1;'),
                imageStyle: showTopLayout ? '' : 'flex-shrink:0;width:' + customSettingsData.width + ';',
                showStoryLayout: true,
                linkText: customSettingsData.nls.linkText,
                linkURL: customSettingsData.linkURL,
                alignImage: componentLayout === 'right' ? 'right' : 'left',
                titleID: '{{{titleId}}}',
                paragraphId: '{{{paragraphId}}}',
                imageId: '{{{imageId}}}'
            };

            if (componentLayout === 'right') {
                model.alignImageright = true;
            } else if (componentLayout === 'top') {
                model.alignImagetop = true;
            } else {
                model.alignImageleft = true;
            }


            var markup = '';
            markup = mustache.render(template, model);
            return resolve({
                hydrate: true,
                content: markup,
                nestedIDs: ['titleId', 'paragraphId', 'imageId']
            });
        } catch (e) {
            console.log(type + ': failed to expand template');
            console.log(e);
        }
        return resolve({});
    });
};


module.exports = new MyComp();