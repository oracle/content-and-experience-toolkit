/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
var fs = require('fs'),
	path = require('path'),
	mustache = require('mustache');

var ContentLayout = function (params) {
	this.contentClient = params.contentClient;
	this.contentItemData = params.contentItemData || {};
	this.scsData = params.scsData;
	// Backward compatibility for v1 API
	this.contentItemData.fields = this.contentClient.getInfo().contentVersion === 'v1' ? this.contentItemData.data : this.contentItemData.fields;
};

ContentLayout.prototype = {
	contentVersion: '>=1.0.0 <2.0.0',

	compile: function () {
		var compiledContent = '',
			content = JSON.parse(JSON.stringify(this.contentItemData)),
			contentClient = this.contentClient;

		// Store the id
		content.fields.author_id = content.id;

		if (this.scsData) {
			content.scsData = this.scsData;
			contentType = content.scsData.showPublishedContent === true ? 'published' : 'draft';
			secureContent = content.scsData.secureContent;
		}

		try {
			// add in style - possibly add to head but inline for simplicity
			var templateStyle = fs.readFileSync(path.join(__dirname, 'design.css'), 'utf8');
			content.style = '<style>' + templateStyle + '</style>';

			var templateHtml = fs.readFileSync(path.join(__dirname, 'layout.html'), 'utf8');
			compiledContent = mustache.render(templateHtml, content);
		} catch (e) {
			console.error(e.stack);
		}

		return Promise.resolve({
			content: compiledContent,
			hydrate: true
		});
	}
};

module.exports = ContentLayout;