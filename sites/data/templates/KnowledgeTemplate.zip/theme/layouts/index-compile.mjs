export default class {
	constructor({ SCSComponentAPI }) {
		this.componentAPI = SCSComponentAPI;
	}

	async compile({ layoutMarkup, SCSCompileAPI }) {
		let compiledPage = layoutMarkup;

		// Example: use string replace on the page layout to convert it to runtime values
		compiledPage = compiledPage.replace('opacity: 0;', 'opacity: 1;');

		//
		// add all the "Knowlege Banner" items to the list of detail pages that need to be compiled
		//

		// find the "service-detail" detail page ID
		const structureMap = this.componentAPI.getSiteInfo().structureMap;
		const detailPageId = Object.keys(structureMap).find((id) => {
			return (structureMap[id].name === 'Service-Detail');
		})

		// query back all the "knowledge banner" content items and add them to the detail pages
		const contentClient = this.componentAPI.getContentClient();
		try {
			const detailItems = await contentClient.queryItems({
				q: '(type eq "Knowledge-Banner")'
			});

			(detailItems && detailItems.items || []).forEach((contentItem) => {
				SCSCompileAPI.compileDetailPage(detailPageId, contentItem);
			});
		} catch (e) {
			console.log('index-compile.mjs: failed to query detail items', e);
		};

		return compiledPage;
	}
}