export default class {
	constructor() { }

	async compile({ layoutMarkup, SCSComponentAPI }) {
		this.componentAPI = SCSComponentAPI;
		let compiledPage = layoutMarkup;

		// Example: use string replace on the page layout to convert it to runtime values
		compiledPage = compiledPage.replace('opacity: 0;', 'opacity: 1;');

		// return the compiled page
		return compiledPage;
	}
}