/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * Copyright (c) 2021, Oracle and/or its affiliates.
 */
import { BaseComponent } from './baseComponent.mjs';

export default class extends BaseComponent {
	// Content Layout constructor 
	constructor(params) {
		super(params);
	}

	// override any functions that require NodeJS specific code
	addToPage(componentHTML) {
		// return the generated HTML and use hydrate in the render.js file to add any event handlers at runtime
		return Promise.resolve({
			hydrate: false, // Note: this component doesn't have any JavaScript event handlers, so there is no need to hydrate the component at runtime
			content: componentHTML
		});
	}

	// compile the component into the page
	compile() {
		// generate the HTML for the component using a Mustache template
		return this.renderComponent();
	}
}