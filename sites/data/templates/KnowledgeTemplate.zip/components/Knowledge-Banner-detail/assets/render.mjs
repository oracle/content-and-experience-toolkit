/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * Copyright (c) 2021, Oracle and/or its affiliates.
 */
import { BaseComponent } from './baseComponent.mjs';

export default class extends BaseComponent {
	// Content Layout constructor 
	constructor(params) {
		super(params);
	}

	// override any functions that require browser specific code
	addToPage(componentHTML) {
		// insert the expanded HTML into the passed in container.
		if (componentHTML) {
			this.container.insertAdjacentHTML('beforeend', componentHTML);
		}
	}

	// render the component into thparamse page
	render(container) {
		this.container = container;

		// generate the HTML for the component using a Mustache template
		return this.renderComponent();
	}
}