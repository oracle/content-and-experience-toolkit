/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * Copyright (c) 2021, Oracle and/or its affiliates.
 */
const BaseComponent = class {
    constructor({ SCSComponentAPI, contentItemData }) {
        this.componentAPI = SCSComponentAPI;
        this.contentItemData = contentItemData;

        this.componentPath = import.meta.url.replace('/baseComponent.mjs', '')
    }

    async loadResources() {
        // load in the resources in parallel
        const [template, css, queryGQL] = await Promise.all([
            this.componentAPI.loadResource({
                path: this.componentPath,
                resource: 'template.mustache'
            }),
            this.componentAPI.loadResource({
                path: this.componentPath,
                resource: 'design.css'
            }),
            this.componentAPI.loadResource({
                path: this.componentPath,
                resource: 'query.gql'
            })
        ]);

        // return the resources
        return {
            template: template,
            css: css,
            queryGQL: queryGQL
        };
    }

    async queryGraphQL(queryGQL) {
        const contentClient = this.componentAPI.getContentClient();
        let queryResult;

        // run the graphQL query passing in any variables
        try {
            queryResult = await contentClient.graphql({
                query: queryGQL,
                variables: {
                    channelToken: contentClient.getInfo().channelToken,
                    id: this.contentItemData.id
                }
            });
        } catch (e) {
            console.log('queryGraphQL: failed', e);
        }

        return queryResult;
    }

    createTemplateModel({ queryResult, css}) {
        // get the componentAPI mustache tags
        const componentTags = this.componentAPI.getMustacheTags();

        // merge componentAPI tags with the query results
        const model = { ...componentTags, ...queryResult.data, ...{css: css} };

        // do any further model updates

        return model;
    }

    addToPage() {
        throw new Error('addTopage method must be overridden');
    }

    async renderComponent() {
        let renderedHTML = '';

        // load in the resources
        const { template, queryGQL, css } = await this.loadResources();

        // run the GraphQL query
        const queryResult = await this.queryGraphQL(queryGQL);

        if (queryResult) {
            // create the model from the query results and resources to be used by the mustache template
            const model = this.createTemplateModel({
                queryResult: queryResult, 
                css: css
             });

            // render the mustache template applying the model
            try {
                renderedHTML = this.componentAPI.getMustache().render(template, model);
            } catch (e) {
                console.log('renderComponent: failed to expand Mustache template', e);
            }
        }

        // add the renderHTML to the page
        return this.addToPage(renderedHTML);
    }
};

export { BaseComponent };
