/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * Copyright (c) 2021, Oracle and/or its affiliates.
 */
const BaseComponent = class {
    constructor({ SCSComponentAPI, componentId }) {
        this.componentAPI = SCSComponentAPI;
        this.id = componentId;

        this.componentPath = import.meta.url.replace('/baseComponent.mjs', '')
    }

    async loadResources() {
        // load in the resources in parallel
        const [template, css] = await Promise.all([
            this.componentAPI.loadResource({
                path: this.componentPath,
                resource: 'template.mustache'
            }),
            this.componentAPI.loadResource({
                path: this.componentPath + '/styles',
                resource: 'design.css'
            }),
        ]);

        // return the resources
        return {
            template: template,
            css: css
        };
    }

    createTemplateModel({ css, overrides }) {
        // get the componentAPI mustache macros
        const componentMacros = this.componentAPI.getMustacheTags();

        // get the customSettingsData either passed in as an override or stored against the component
        const customData = overrides.customSettingsData || {};

        // create the navigation menu model
        const siteInfo = this.componentAPI.getSiteInfo();
        const navMenu = new NavigationMenu({
            SCSComponentAPI: this.componentAPI,
            structureMap: siteInfo.structureMap,
            rootId: siteInfo.navigationRoot,
            currentNodeId: siteInfo.currentPageId
        });
        const menuModel = {
            navMenuList: navMenu.createNavMenu(),
            navWidth: customData.navWidth || '50%',
            navAlign: customData.nls && customData.nls.navAlign || 'inherit',
        };

        // merge componentAPI macros with the navgiation menu results
        const model = { ...componentMacros, ...{ css: css }, ...menuModel };

        return model;
    }

    addToPage() {
        throw new Error('addTopage method must be overridden');
    }

    // Note: parameters may be passed in as overrides due to events at runtime
    async renderComponent({ customSettingsData, componentLayout, imageWidth } = {}) {
        let renderedHTML = '';

        // load in the resources
        const { template, css } = await this.loadResources();

        // create the model from the query results and resources to be used by the mustache template
        const model = this.createTemplateModel({
            css: css,
            overrides: {
                customSettingsData: customSettingsData,
                componentLayout: componentLayout,
                imageWidth: imageWidth
            }
        });

        // render the mustache template applying the model
        try {
            renderedHTML = this.componentAPI.getMustache().render(template, model);
        } catch (e) {
            console.log('renderComponent: failed to expand Mustache template', e);
        }

        // add the renderHTML to the page
        return this.addToPage(renderedHTML);
    }
};

const NavigationMenu = class {
    constructor({ SCSComponentAPI, structureMap, rootId, currentNodeId }) {
        this.componentAPI = SCSComponentAPI;
        this.structureMap = structureMap;
        this.rootId = rootId;
        this.currentNodeId = currentNodeId;

        // initialize the navigation menu
        this.navMenu = [];
    }

    createNavMenu() {
        const structureMap = this.structureMap,
            rootId = this.rootId;


        // start with Home link...
        this.createNavItem(rootId);

        // top level pages...
        (structureMap[rootId].children || []).forEach(nodeId => {
            // skip hidden node...
            if (!this.isNodeHidden(nodeId)) {
                if (!this.allNodeChildrenAreHidden(nodeId)) {
                    // add top level node with childeren...
                    this.createSubNavItem(nodeId);
                } else {
                    // add top level node without childeren...
                    this.createNavItem(nodeId);
                }
            }
        });

        return this.navMenu;
    }

    createNavItem(id) {
        var linkData = this.componentAPI.createPageLink(id) || {};

        this.navMenu.push({
            name: this.structureMap[id].name,
            target: linkData.target,
            href: linkData.href
        });
    }

    createSubNavItem(id) {
        const linkData = this.componentAPI.createPageLink(id) || {},
            menuItem = this.structureMap[id],
            submenus = [],
            subNodes = menuItem.children || [];

        subNodes.forEach((childId) => {
            if (!this.isNodeHidden(childId)) {
                // add item in the sub-level navigation menu...
                const childlinkData = this.componentAPI.createPageLink(childId) || {};
                submenus.push({
                    name: this.structureMap[childId].name,
                    target: childlinkData.target,
                    href: childlinkData.href
                });
            }
        });

        // add in this node
        this.navMenu.push({
            name: menuItem.name,
            target: linkData.target,
            href: linkData.href,
            hasSubmenu: submenus.length > 0,
            submenus
        });
    }

    allNodeChildrenAreHidden(id) {
        const subnodes = (this.structureMap[id].children || []);

        const visibleNode = subnodes.find(subNodeId => {
            return !this.isNodeHidden(subNodeId);
        });

        return typeof visibleNode !== 'undefined';
    }


    isNodeHidden(id) {
        const navNode = (this.structureMap[id] || {});

        return (navNode.hideInNavigation === true);
    }
};

export { BaseComponent };