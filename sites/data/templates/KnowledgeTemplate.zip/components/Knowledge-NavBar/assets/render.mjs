/**
 * Confidential and Proprietary for Oracle Corporation
 *
 * This computer program contains valuable, confidential, and
 * proprietary information. Disclosure, use, or reproduction
 * without the written authorization of Oracle is prohibited.
 *
 * Copyright (c) 2021, Oracle and/or its affiliates.
 */
import { BaseComponent } from './baseComponent.mjs';

export default class extends BaseComponent {
	// Content Layout constructor 
	constructor(params) {
		super(params);

		this.sitesSDK = params.SitesSDK;

		// add in the event listeners
		this.addEventListeners();
	}

	// add in the listeners for the triggers/actions and whenever the settings values change
	// in this case, we want to re-render the component on the screen
	addEventListeners() {
		// listen for settings update
		this.sitesSDK.subscribe(this.sitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, (props) => {
			if (props.property === 'customSettingsData') {
				this.renderComponent({
					customSettingsData: props.value
				});
			} else if (props.property === 'componentLayout') {
				// Note: Not used in this component, included only as an example
				this.renderComponent({
					componentLayout: props.value,
					customSettingsData: this.sitesSDK.getProperty('customSettingsData')
				});
			}
		});

		// listen for actions
		// Note: Not used in this component, included only as an example
		this.sitesSDK.subscribe(this.sitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, (args) => {
			console.log(this.sitesSDK.MESSAGE_TYPES.EXECUTE_ACTION);

			// get action and payload
			const payload = Array.isArray(args.payload) ? args.payload : [],
				action = args.action;

			// handle 'setImageWidth' actions
			if (action && action.actionName === 'setImageWidth') {
				payload.forEach((data) => {
					if (data.name === 'imageWidth') {
						this.renderComponent({
							imageWidth: data.value,
							customSettingsData: this.sitesSDK.getProperty('customSettingsData')
						});
					}
				});
			}
		});
	}

	addClickHandlers(container) {
		// when the image is clicked
		// Note: Not used in this component, included only as an example
		const img = document.getElementById('image' + this.id);

		if (img) {
			img.addEventListener('click', (event) => {
				this.sitesSDK.publish(this.sitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
					'triggerName': 'imageClicked', // 'imageClicked' matches value in appinfo.json
					'triggerPayload': {
						'payloadData': 'some data here' // customize with data you want pass
					}
				});
			});
		}
	}

	// override any functions that require browser specific code
	addToPage(componentHTML) {
		// insert the expanded HTML into the passed in container.
		if (componentHTML) {
			this.container.innerHTML = componentHTML;
		}

		// add in the click handlers
		this.addClickHandlers(this.container);
	}

	// the hydrate method is called when a component has been compiled into the page at runtime 
	// this gives the opportunity to add any event handlers to the HTML that has been inserted into the page
	hydrate(container) {
		this.container = container;
		this.addClickHandlers(container);
	}

	// the render method is called to render the component dynamically onto the page 
	render(container) {
		this.container = container;
		return this.renderComponent({
			customSettingsData: this.sitesSDK.getProperty('customSettingsData')
		});
	}
}