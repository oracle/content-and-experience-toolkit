/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
var fs = require('fs'),
	path = require('path'),
	mustache = require('mustache'),
	marked = require('marked');

function dateToMDY(date) {
	var dateObj = new Date(date);

	var options = {
		year: 'numeric',
		month: 'long',
		day: 'numeric'
	};
	var formattedDate = dateObj.toLocaleDateString('en-US', options);

	return formattedDate;
}

// Helper function to parse markdown text.
function parseMarkdown(mdText) {
	if (mdText && /^<!---mde-->\n\r/i.test(mdText)) {
		mdText = mdText.replace("<!---mde-->\n\r", "");
		mdText = marked(mdText);
	}

	return mdText;
}

// Helper function to make an additional Content REST API call to retrieve all items referenced in the data by their ID.
function getRefItems(contentClient, ids) {
	// Calling getItems() with no ‘ids’ returns all items.
	// If no items are requested, just return a resolved Promise.
	if (ids.length === 0) {
		return Promise.resolve({});
	} else {
		return contentClient.getItems({
			"ids": ids
		});
	}
}

var ContentLayout = function (params) {
	this.contentClient = params.contentClient;
	this.contentItemData = params.contentItemData || {};
	this.scsData = params.scsData;
};

ContentLayout.prototype = {
	contentVersion: '>=1.0.0 <2.0.0',
	compile: function (parentObj) {
		var template,
			contentClient = this.contentClient,
			fields = this.contentItemData.fields,
			content = {
				blogImageRenditionURL: contentClient.getRenditionURL({
					'id': fields['starter-blog-post_header_image'].id
				}),
				blogSummary: fields['starter-blog-post_summary'],
				blogTitle: fields['starter-blog-post_title'],
				blogContent: fields['starter-blog-post_content'],
				blogFormattedDate: dateToMDY(this.contentItemData.updatedDate.value)
			},
			contentType,
			secureContent = false;

		if (this.scsData) {
			content.scsData = this.scsData;
			contentType = content.scsData.showPublishedContent === true ? 'published' : 'draft';
			secureContent = content.scsData.secureContent;
		}

		return getRefItems(contentClient, [fields['starter-blog-post_author'].id]).then(function (results) {
			// get the blog author
			var author = results && results.items && results.items[0] || [];
			author.fields = contentClient.getInfo().contentVersion === 'v1' ? author.data : author.fields;

			content.author_id = author.id;
			content.blogAuthor = author.fields['starter-blog-author_name'];
			content.blogAuthorAvatar = contentClient.getRenditionURL({
				'id': author.fields['starter-blog-author_avatar'].id
			});
			content.blogAuthorBio = parseMarkdown(author.fields['starter-blog-author_bio']);

			// Get the download media files
			var referedids = [];
			for (var i = 0; i < fields["starter-blog-post_download_media"].length; i++) {
				referedids.push(fields["starter-blog-post_download_media"][i].id);
			}

			// render the content
			try {
				// add in style - possible to add to <head> but inline for simplicity
				var templateStyle = fs.readFileSync(path.join(__dirname, 'design.css'), 'utf8');
				content.style = '<style>' + templateStyle + '</style>';


				var templateHtml = fs.readFileSync(path.join(__dirname, 'layout.html'), 'utf8');
				compiledContent = mustache.render(templateHtml, content);
			} catch (e) {
				console.error(e.stack);
			}

			return Promise.resolve({
				content: compiledContent,
				hydrate: false 
			});
		}).catch(function (error) {
			console.log('failed to compile content layout: Starter-Blog-Post-Header');
			console.log(error);
			throw new Error(error);
		});
	}
};

module.exports = ContentLayout;