/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
var commonCompiler = require('./common-compile.js');

var PageCompiler = function () {};
 
PageCompiler.prototype.compile = function (args) {
    return commonCompiler.compile(args).then(function(commonPage) {
        var compiledPage = commonPage;

        // do any additional work specific to this page
     
		// return the compiled page
		return Promise.resolve(compiledPage);
    });
};
 
module.exports = new PageCompiler();