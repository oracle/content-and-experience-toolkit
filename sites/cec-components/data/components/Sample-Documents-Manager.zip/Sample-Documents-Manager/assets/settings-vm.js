/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global SitesSDK,define*/
/*jslint plusplus: true */
define(['jquery', 'knockout', 'CommonResources', 'app-utils', 'settings-dependencies'], function ($, ko, strings, appUtils) {
	'use strict';

	ko.bindingHandlers.scsScrollbar = {
		init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
			$('.scrollbar-inner').scrollbar();
		}
	};

	var defaultFolder = window.location.hostname === 'localhost' ? 'home' : '',
		defaultFolderName = window.location.hostname === 'localhost' ? 'Home' : '';
	var settingsViewModel,
		MyViewModel = function () {
			var self = this;

			self.strings = strings;
			self.initialized = ko.observable(false);
			self.saveData = false;

			// By default, no folder is selected. Watermark is displayed.
			self.folderGuid = ko.observable('');
			
			self.linkid = ko.observable('');

			// By default, user doesn't have any role. When folder is available, check again. 
			self.userHasNoRole = ko.observable(true);

			// Index of the hybrid link asset.
			self.hybridLinkIndex = ko.observable(0);
			self.isHomeFolder = ko.computed(function () {
				return self.folderGuid() === 'home';
			});

			self.folderLinks = ko.observableArray([]);

			self.errorMessage = ko.observable('');

			// Link permissions
			self.linkPerm = ko.observable('downloader');
			self.linkPermValues = ko.observableArray([
				{
					value: 'member',
					label: strings.APP_PROJECT_LIBRARY_FOLDER_MEMBER
				},
				{
					value: 'viewer',
					label: strings.APP_DOCSMGR_LINK_VIEWER
				},
				{
					value: 'downloader',
					label: strings.APP_DOCSMGR_LINK_DOWNLOADER
				},
				{
					value: 'contributor',
					label: strings.APP_DOCSMGR_LINK_CONTRIBUTOR
				}
			]);

			self.linkPermValue = ko.computed({
				read: function () {
					return [self.linkPerm()];
				},
				write: function (value) {
					self.linkPerm(value[0]);
					self.showConvoPane(self.linkPerm() === 'member');
				},
				owner: self
			});

			// Layout
			self.layout = ko.observable('compact');
			self.layoutValues = ko.observableArray([
				{
					value: 'compact',
					label: strings.APP_DOCSMGR_LAYOUT_COMPACT
				},
				{
					value: 'list',
					label: strings.APP_DOCSMGR_LAYOUT_LIST
				},
				{
					value: 'grid',
					label: strings.APP_DOCSMGR_LAYOUT_GRID
				}
			]);

			// Convert layout observable to array observable for oj-select
			self.layoutValue = ko.computed({
				read: function () {
					return [self.layout()];
				},
				write: function (value) {
					self.layout(value[0]);
				},
				owner: self
			});

			// Color Scheme
			self.color = ko.observable('light');
			self.colorValues = ko.observableArray([
				{
					value: 'light',
					label: strings.APP_DOCSMGR_COLOR_SCHEME_LIGHT
				},
				{
					value: 'translight',
					label: strings.APP_DOCSMGR_COLOR_SCHEME_TRANS_LIGHT
				},
				{
					value: 'dark',
					label: strings.APP_DOCSMGR_COLOR_SCHEME_DARK
				},
				{
					value: 'transdark',
					label: strings.APP_DOCSMGR_COLOR_SCHEME_TRANS_DARK
				}
			]);

			// Convert color observable to array observable for oj-select
			self.colorValue = ko.computed({
				read: function () {
					return [self.color()];
				},
				write: function (value) {
					self.color(value[0]);
				},
				owner: self
			});

			//Sort
			self.sortBy = ko.observable('nameasc');
			self.sortByValues = ko.observableArray([
				{
					value: 'nameasc',
					label: strings.APP_DOCSMGR_SORT_NAME
				},
				{
					value: 'updated',
					label: strings.APP_DOCSMGR_SORT_UPDATED
				}
			]);

			// Convert sortBy observable to array observable for oj-select
			self.sortByValue = ko.computed({
				read: function () {
					return [self.sortBy()];
				},
				write: function (value) {
					self.sortBy(value[0]);
				},
				owner: self
			});

			// Zoom option
			self.viewerZoom = ko.observable('all');
			self.viewerZoomValues = ko.observableArray([
				{
					value: 'all',
					label: strings.APP_DOCSMGR_VIEWER_ALL
				},
				{
					value: 'hzs',
					label: strings.APP_DOCSMGR_VIEWER_ZOOM_IN_OUT
				},
				{
					value: 'hzc',
					label: strings.APP_DOCSMGR_VIEWER_NONE
				}
			]);

			// Convert viewerZoom observable to array observable for oj-select
			self.viewerZoomValue = ko.computed({
				read: function () {
					return [self.viewerZoom()];
				},
				write: function (value) {
					self.viewerZoom(value[0]);
				},
				owner: self
			});

			// Fit to page option
			self.viewerFitMode = ko.observable('sfp');
			self.viewerFitValues = ko.observableArray([
				{
					value: 'sfp',
					label: strings.APP_DOCSMGR_VIEWER_FIT_TO_PAGE
				},
				{
					value: 'sfw',
					label: strings.APP_DOCSMGR_VIEWER_FIT_TO_WIDTH
				},
				{
					value: 'sos',
					label: strings.APP_DOCSMGR_VIEWER_FIT_ORIGINAL
				}
			]);

			// Convert viewerFitMode observable to array observable for oj-select
			self.viewerFitValue = ko.computed({
				read: function () {
					return [self.viewerFitMode()];
				},
				write: function (value) {
					self.viewerFitMode(value[0]);
				},
				owner: self
			});

			self.folderGuid.subscribe(function (newValue) {
				if (self.userHasNoRole()) {
					// If the user doesn't have any role on the selected folder,
					// check if the user has role on the newly selected folder.
					$.ajax({
						'type': 'GET',
						'dataType': 'json',
						'url': '/documents/web?IdcService=FLD_BROWSE&item=fFolderGUID:' + self.folderGuid().split('/')[1],
						'success': function (data) {
							if (data.LocalData.dRoleName) {
								self.userHasNoRole(false);
							}
						},
						'error': function (xhr, status, err) {
							//alert('status=' + status + ' err=' + err);
						}
					});
				}
			});

			self.isUpgrade = ko.computed(function () {
				if (self.linkid() !== '') {
					//legacy public link case
					return true;
				} else {
					// member or hybrid link case
					return false;
				}
			});

			self.allowSetConvoPane = ko.computed(function () {
				return self.folderGuid() && self.linkPerm() === 'member';
			});

			// handle initialization of the viewModel
			self.init = function (customData) {

				self.config = {
					folderGuid: customData.hasOwnProperty('folderGuid') ? customData.folderGuid : defaultFolder,
					folderName: customData.hasOwnProperty('folderName') ? customData.folderName : defaultFolderName,
					linkid: customData.hasOwnProperty('linkid') ? customData.linkid : '',
					hybridLinkIndex: customData.hasOwnProperty('hybridLinkIndex') ? customData.hybridLinkIndex : 0,
					linkPerm: customData.hasOwnProperty('linkPerm') ? customData.linkPerm : 'downloader',
					showConvoPane: customData.hasOwnProperty('showConvoPane') ? customData.showConvoPane : true,
					sortBy: customData.hasOwnProperty('sortBy') ? customData.sortBy : 'nameasc',
					layout: customData.hasOwnProperty('layout') ? customData.layout : 'compact',
					color: customData.hasOwnProperty('color') ? customData.color : 'light',
					enableViewer: customData.hasOwnProperty('enableViewer') ? customData.enableViewer : true,
					showDownload: customData.hasOwnProperty('showDownload') ? customData.showDownload : true,
					showUpload: customData.hasOwnProperty('showUpload') ? customData.showUpload : true,
					showShare: customData.hasOwnProperty('showShare') ? customData.showShare : true,
					showCopy: customData.hasOwnProperty('showCopy') ? customData.showCopy : true,
					showMove: customData.hasOwnProperty('showMove') ? customData.showMove : true,
					showDelete: customData.hasOwnProperty('showDelete') ? customData.showDelete : true,
					showEdit: customData.hasOwnProperty('showEdit') ? customData.showEdit : true,
					viewerZoom: customData.hasOwnProperty('viewerZoom') ? customData.viewerZoom : 'all',
					viewerFitMode: customData.hasOwnProperty('viewerFitMode') ? customData.viewerFitMode : 'sfp',
					viewerEmbedded: customData.hasOwnProperty('viewerEmbedded') ? customData.viewerEmbedded : true,
					viewerThumbnail: customData.hasOwnProperty('viewerThumbnail') ? customData.viewerThumbnail : true,
					viewerVideo: customData.hasOwnProperty('viewerVideo') ? customData.viewerVideo : true,
					autowiring: customData.hasOwnProperty('autowiring') ? customData.autowiring : true
				};

				self.autowiring = ko.observable(self.config.autowiring);
				self.folderGuid(self.config.folderGuid);
				self.folderName = ko.observable(self.config.folderName);
				self.hybridLinkIndex(self.config.hybridLinkIndex);

				self.linkid(self.config.linkid);
				self.linkPerm(self.hybridLinkIndex() === 0 && !self.linkid() ? 'member' : self.config.linkPerm);
				self.showConvoPane = ko.observable(self.linkPerm() !== 'member' ? false : self.config.showConvoPane);
				self.layout(self.config.layout);
				self.color(self.config.color);
				self.sortBy(self.config.sortBy);
				// Options
				self.enableViewer = ko.observable(self.config.enableViewer);
				self.showDownload = ko.observable(self.config.showDownload);
				self.showUpload = ko.observable(self.config.showUpload);
				self.showShare = ko.observable(self.config.showShare);
				self.showCopy = ko.observable(self.config.showCopy);
				self.showMove = ko.observable(self.config.showMove);
				self.showDelete = ko.observable(self.config.showDelete);
				self.showEdit = ko.observable(self.config.showEdit);

				//
				// Viewer options
				//
				self.viewerEmbedded = ko.observable(self.config.viewerEmbedded);
				self.viewerThumbnail = ko.observable(self.config.viewerThumbnail);
				self.viewerVideo = ko.observable(self.config.viewerVideo);
				self.viewerZoom(self.config.viewerZoom);
				self.viewerFitMode(self.config.viewerFitMode);

				// Get the siteInfo. It is required to create hybrid link later
				SitesSDK.getSiteProperty('siteInfo', function (propertyData) {
					self.siteInfo = {};
					self.siteInfo.siteGUID = propertyData.siteInfo.siteGUID;
					self.siteInfo.idcToken = propertyData.siteInfo.idcToken;
					self.siteInfo.pageId = propertyData.siteInfo.pageId;
					self.siteInfo.siteVariantGUID = propertyData.siteInfo.siteVariantGUID;
				});

				// requery / create  hybrid link when link permission changes
				self.linkPerm.subscribe(function (newValue) {
					// When link permission changes, recreate the hybrid link
					self.createHybridLink();
				});


				self.save = ko.computed(function () {
					//save
					var saveconfig = {
						'folderGuid': self.folderGuid(),
						'linkid': self.linkid(),
						'hybridLinkIndex': self.hybridLinkIndex(),
						'folderName': self.folderName(),
						'layout': self.layout(),
						'color': self.color(),
						'sortBy': self.sortBy(),
						'enableViewer': self.enableViewer(),
						'showDownload': self.showDownload(),
						'showUpload': self.showUpload(),
						'showShare': self.showShare(),
						'showCopy': self.showCopy(),
						'showMove': self.showMove(),
						'showDelete': self.showDelete(),
						'showEdit': self.showEdit(),
						'showConvoPane': self.showConvoPane(),
						'viewerZoom': self.viewerZoom(),
						'viewerFitMode': self.viewerFitMode(),
						'viewerEmbedded': self.viewerEmbedded(),
						'viewerThumbnail': self.viewerThumbnail(),
						'viewerVideo': self.viewerVideo(),
						'autowiring': self.autowiring()
					};


					if (self.linkPerm() === 'member') {
						saveconfig.linkPerm = self.linkPerm();
					} else {
						if (self.config.hybridLinkIndex === self.hybridLinkIndex()) {
							saveconfig.linkPerm = self.config.linkPerm;
						} else {
							// Hybrid link index changed, it means hybrid link was created successfully.
							// Save the permission
							saveconfig.linkPerm = self.linkPerm();

							// Re-initalize the values
							self.config.hybridLinkIndex = self.hybridLinkIndex();
							self.config.linkPerm = self.linkPerm();
						}
					}

					//dispatch config to app
					if (self.saveData) {
						// Save the assets and settings
						// Assets are managed by the framework and
						// settings are managed by the apps.
						SitesSDK.setProperty('componentAssets', self.assets);
						SitesSDK.setProperty('customSettingsData', saveconfig);
					}
				});

				// now viewModel has been initialized
				self.initialized(true);
				self.saveData = true;
			};

			SitesSDK.getProperty('componentAssets', function (assets) {
				// Assets should be obtained before customSettings.
				self.assets = assets;
				if (assets.length > 0) {
					// console.log("Hybrid link to be read is (source): " + assets[0].source);
				}
				// get the customSettings Data and init the viewModel
				SitesSDK.getProperty('customSettingsData', self.init);
			});


			// Callback when a file is selected
			self.selectFolder = function (data) {
				if (data) {
					data.forEach(function (file) {
						self.folderGuid('folder/' + file.id);
						// unescape the file.name
						var textArea = document.createElement('textarea');
						textArea.innerHTML = file.name;
						self.folderName(textArea.value);

						// use downloader by default
						self.linkPerm('downloader');

						// selection changed, create hybrid link.
						self.createHybridLink();
					});
				}
			};

			// bring up a file picker to select the folder
			self.showFilePicker = function () {
				// select folders
				SitesSDK.filePicker({
					'multiSelect': false,
					'foldersOnly': true,
					'category': 'documents',
					'location': self.folderGuid().replace('folder/', ''),
					'showReset': true
				}, function (folder) {
					self.selectFolder(folder);
				});
			};


		}; //end of view model

	MyViewModel.prototype.createHybridLink = function () {
		var self = this,
			linkRole = self.linkPerm(),
			msg;

		if (linkRole !== 'member' && self.folderGuid() && self.folderGuid().indexOf('/') >= 0) {

			// Clear the error message
			self.errorMessage('');

			// Create the hybrid link
			appUtils.createHybridLink(self.siteInfo.siteGUID, self.siteInfo.pageId, self.siteInfo.siteVariantGUID, self.folderGuid().split('/')[1], self.siteInfo.idcToken, function (data) {
				// console.log("Hybrid link is created : " + data.LocalData.dLinkID);
				var uniqueId = Math.floor(Math.random() * 10000);
				if (uniqueId === self.config.hybridLinkIndex) {
					// Random number created is the same as the previous one
					// Fix it
					uniqueId = uniqueId + 1;
				}
				var sourceURL = '/documents/embed/link/' + data.LocalData.dLinkID + '/folder/' + self.folderGuid().split('/')[1];
				// Hybrid link is created, now store it as an asset for the framework to manage it.
				// source attribute holds the hybrid link
				self.assets = [{
					id: uniqueId,
					title: self.folderName(),
					source: sourceURL,
					description: 'Hybrid link from Documents Manager',
					roleName: linkRole,
					fileName: self.folderName()
				}];
				// When there are more than one asset needs to be managed, index will be useful.
				self.hybridLinkIndex(uniqueId);
			}, function (err) {
				// console.log("Error happened during hybrid link creation : " + err);
				// Handle the permission errors.
				if (linkRole === 'viewer') {
					msg = self.strings.APP_DOCSMGR_HYBRID_LINK_ERR_VIEWER;
				} else if (linkRole === 'downloader') {
					msg = self.strings.APP_DOCSMGR_HYBRID_LINK_ERR_DOWNLOADER;
				} else {
					msg = self.strings.APP_DOCSMGR_HYBRID_LINK_ERR_CONTRIBUTOR;
				}

				// the new permission is not allowed, switch back to the previous value

				if (linkRole === 'contributor') {
					// contributor not allowed, try with downloader
					self.linkPerm('downloader');
				} else if (linkRole === 'downloader') {
					// downloader is not allowed, try with viewer
					self.linkPerm('viewer');
				} else if (linkRole === 'viewer') {
					// Hybrid link was created by someone else.
					// This user doesn't have viewer access.
					// Do not update link permission further.
				}

				// show error message
				self.errorMessage(msg);

			}, linkRole);
		}
	};

	MyViewModel.prototype.getLinkWarningMessage = function () {
		var self = this;

		if (!self.hybridLinkIndex() && self.linkid() && self.folderGuid()) {
			// Hybrid link index is 0, folderGuid is not empty and linkis not empty
			// This is public link case
			return self.strings.APP_DOCSMGR_LEGACY_LINK_WARNING;
		} else {
			return '';
		}

	};

	settingsViewModel = new MyViewModel();

	// Return the module
	return settingsViewModel;
});
