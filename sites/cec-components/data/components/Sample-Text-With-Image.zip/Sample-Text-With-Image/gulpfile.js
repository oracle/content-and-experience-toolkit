/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global console, __dirname */
var gulp = require('gulp'),
	replace = require('gulp-replace'),
	requirejs = require('requirejs'),
	path = require('path');

var folders = __dirname.split(path.sep),
	componentName = folders[folders.length-1];

var requirejsOptimizeConfig = {
	baseUrl: 'assets',
	mainConfigFile: 'assets/render.js',
	name: 'render',
	out: '../../../build/components/' + componentName + '/assets/render.js',
	optimizeCss: 'standard.keepLines.keepWhitespace',
	optimize: "uglify",
	paths: {
		// Exclude jquery and knockout, it will be loaded by sites
		jquery: 'empty:',
		knockout: 'empty:',
		css: '../../../../libs/require-css/css.min',
		'css-builder': '../../../../libs/require-css/css-builder',
		'normalize': '../../../../libs/require-css/normalize',
		text: '../../../../libs/requirejs-text/text'
	},
	// Exclude all these modules from bundling. They will be loaded by Sites
	exclude: ['css', 'text', 'css-builder', 'normalize'],
};

gulp.task('default', function() {
	"use strict";
	return requirejs.optimize(requirejsOptimizeConfig, function(buildResponse) {
		console.log('Optimized the following files:');
		console.log(buildResponse);

		gulp.src(requirejsOptimizeConfig.out)
			// Note: If you copy this file to different component,
			// fix the dependency names accordingly
			// Remove the module name 'render', so that Sites recognizes it as the top level module
			.pipe(replace('define("render",', 'define('))
			// Replace the relative paths in the module name with a simple name, so requirejs can load it from same file
			.pipe(replace('css!./styles/design', 'design'))
			.pipe(replace('css!styles/design', 'design'))
			.pipe(replace('text!./template.html', 'text!template.html'))
			.pipe(replace('./data-defaults', 'data-defaults'))
			.pipe(gulp.dest(requirejsOptimizeConfig.out.replace('/render.js', '')));
	}, function(err) {
		// Exit with non zero status if there is an error
		console.log('Error optimizing...');
		console.log(err);
		process.exit(1);
	});
});
