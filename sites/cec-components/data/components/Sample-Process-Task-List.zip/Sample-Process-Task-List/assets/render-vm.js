/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,requirejs,SitesPCSUtils*/
(function () {
	var taskListInitializedFlag = false;

	// Define a Knockout ViewModel for your template
	var PCSTaskListViewModel = function () {
		// save reference
		var self = this;

		//	Attributes on PCSTaskListViewModel	//
		//	===============================		//	
		//										//	
		// whether current mode is edit mode
		self.isRendering = ko.observable(false);
		SitesSDK.getProperty('viewMode', function (viewMode) {
			self.isRendering(viewMode !== 'edit');
		});

		self.taskListLabel = 'Task List';
		// no connection message 
		self.noConnectionMsg = ko.observable('No Process Cloud Service connection');
		self.pcsServerURL = ko.observable('');
		self.pcsServerURLErr = ko.observable(false);
		self.isAuthed = ko.observable(false);
		self.noAuthMsg = ko.observable('The task list component can only be viewed on a secure site by users with the Documents Cloud Service User role.');
		self.isPCSModuleLoaded = ko.observable(true);
		self.noPCSModuleMsg = ko.observable('A newer version of Process Cloud Service is required to use the task list component.');

		// handle initialization
		self.customSettingsDataInitialized = ko.observable(false);

		//	Methods on PCSTaskListViewModel //
		//	===============================	//	
		//									//		

		self.initialized = ko.computed(function () {
			return self.customSettingsDataInitialized();
		}, self);

		// check if it is a logged in session
		self.checkAuth = function (callback) {
			var url = '/documents/web?IdcService=GET_USER_INFO';
			if (self.isRendering() === false) {
				// in builder
				callback(true);
			} else {
				$.ajax({
					'type': 'GET',
					'dataType': 'json',
					'url': url,
					'success': function (data) {
						console.log('startform: authorized');
						callback(data.LocalData.StatusCode === '0');
					},
					'error': function (xhr, status, err) {
						console.log('tasklist: unauthorized, status: ' + status + ' error: ' + err);
						callback(false);
					}
				});
			}
		};


		self.init = function (customData) {
			self.checkAuth(function (authed) {
				self.isAuthed(authed);
				if (authed) {
					self.updateCustomSettingsData(customData);
				}
				self.customSettingsDataInitialized(true);

				//listen to the following value changes to adjust render height
				ko.computed(function () {
					var authed = self.isAuthed(),
						serverErr = self.pcsServerURLErr();

					// unauthorized message
					if (authed === false) {
						SitesSDK.setProperty('height');
					}
				});
			});
		};

		self.getToken = function (serverURL, callback) {
			var token;

			SitesPCSUtils.getAuthToken({
				'serverURL': serverURL,
				'successCallback': function (data) {
					token = data;
					callback(token);
				},
				'errorCallback': function (xhr, status, err) {
					if (xhr && xhr.status === 200) {
						token = xhr.responseText;
					} else {
						console.error('getToken: xhr: ' + JSON.stringify(xhr) + ' status: ' + status + ' error: ' + err);
					}
					callback();
				}
			});
		};

		self.initializeTaskList = function (serverURL, authToken, designCss) {
			var CSS_URL_PATH = "/ic/pub/components/css",
				JS_URL_PATH = "/ic/pub/components/js",
				PCS_VERSION = '2.0',
				baseUrl = serverURL + JS_URL_PATH;

			// set up the PCS require config environment
			require([baseUrl + '/libs/pcs/config/pcs-require-config.js'], function (pcsRequireConfig) {
				pcsRequireConfig.configPaths(baseUrl, PCS_VERSION, true);

				// require in the PCS start form and its CSS as well as the Oracle JET alta CSS from CDN
				var pcsRequireModules = [
					'jquery',
					'pcs/pcs.tasklist',
					'ojs/ojvalidation-datetime',
					'css!' + serverURL + CSS_URL_PATH + '/libs/pcs/v' + PCS_VERSION + '/alta/pcs-tasklist-min.css',
					'css!https://static.oracle.com/cdn/jet/v5.0.0/default/css/alta/oj-alta-min.css'
				];

				// add in the design.css if supplied
				if (designCss) {
					pcsRequireModules.push('css!' + designCss);
				}

				require(pcsRequireModules, function ($, tasklist) {
					console.log("PCS: " + serverURL + " " + authToken);

					$.pcsConnection = {
						serverURL: serverURL,
						authInfo: authToken
					};

					self.loadList();

				});
			}, function (err) {
				// PCS module is not loaded
				if (err.requireModules && err.requireModules.indexOf('pcs/pcs.tasklist') >= 0) {
					self.isPCSModuleLoaded(false);
				}
			});

		};

		self.loadList = function () {

			var tasklist = $('#tasklist');
			//                            var taskListDiv = $("#tasklist");

			//if the plugin was already used  clean it up
			if (tasklist && tasklist.data() && !$.isEmptyObject(tasklist.data())) {
				tasklist.tasklist('destroy');
			}

			ko.cleanNode(tasklist['0']);

			var div = tasklist.parent();
			div.html('<div id="tasklist"></div>');

			var tasklistDiv = $("#tasklist"),
				fromuserstr = "",
				users = self.config.users;

			//parsing all the selected fromusers' id to form one string parameter
			if (users && Array.isArray(users) && users.length > 0) {
				fromuserstr += users[0].id;
				for (var i = 1, len = users.length; i < len; i++) {
					fromuserstr += ",";
					fromuserstr += users[i].id;
				}
			}
			//generate the tasklistFilter input with all the filter options set in the settings
			var filteroptions = "{" + "\"status\":\"" + self.config.status + "\"" + ",\"assignees\":\"" + self.config.assignee + "\"" + ",\"applications\":\"" + self.config.application + "\"" + ",\"fromUser\":\"" + fromuserstr + "\"" + ",\"keyword\":\"" + self.config.keyword + "\"" + ",\"fromDueDate\":\"" + self.config.fromdate + "\"" + ",\"toDueDate\":\"" + self.config.todate + "\"" +
				"}";

			$("#tasklist").tasklist({
				hideTaskDetails: (!self.config.showDetails),
				pageSize: self.config.pageSize,
				hideSearch: (!self.config.showSearch),
				hideFilter: (!self.config.showFilter),
				hideSelectAll: (!self.config.showSelectAll),
				tasklistFilter: filteroptions
			});

			//TODO: Catch other events
			tasklistDiv.on('tasklist:taskSelect', function (event, data, action) {
				console.log('Task list is selected :' + data);
				setTimeout(function () {
					//document.getElementById("tasklist").style.display = 'none';

					var triggerPayload = data;

					SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
						'triggerName': 'raisePCSTaskSelectedTrigger',
						'triggerPayload': triggerPayload,
						'actions': ['PCSTaskSelected']
					});

				}, 200);

			});

			tasklistDiv.on('tasklist:loaded', function (event, data, action) {
				var height = $('#tasklist').outerHeight(true) + 30;
				console.log("PCS Task List: Loaded... height=" + height);
				SitesSDK.setProperty('height', height);
			});

			tasklistDiv.on('taskSearch:loaded', function (event, data, action) {
				var searchheight = $('#advSearchDialog').outerHeight(true) + 30,
					height = $('#tasklist').outerHeight(true) + 30;
				// console.log('tasklist height: ' + height + ' search dialog height: ' + searchheight);
				if (height < searchheight) {
					SitesSDK.setProperty('height', searchheight);
				}
			});

			SitesSDK.setProperty('height', $('#tasklist').outerHeight(true) + 100);

		};



		//
		// Handle property changes
		//
		self.updateCustomSettingsData = function (customData) {

			self.config = {
				pageSize: customData.hasOwnProperty('pageSize') ? customData.pageSize : 10,
				showDetails: customData.hasOwnProperty('showDetails') ? customData.showDetails : false,
				showSearch: customData.hasOwnProperty('showSearch') ? customData.showSearch : false,
				showFilter: customData.hasOwnProperty('showFilter') ? customData.showFilter : false,
				showSelectAll: customData.hasOwnProperty('showSelectAll') ? customData.showSelectAll : false,
				status: customData.hasOwnProperty('status') ? customData.status : 'ASSIGNED',
				assignee: customData.hasOwnProperty('assignee') ? customData.assignee : 'MY_AND_GROUP_ALL',
				application: customData.hasOwnProperty('application') ? customData.application : '',
				keyword: customData.hasOwnProperty('keyword') ? customData.keyword : '',
				fromdate: customData.hasOwnProperty('fromdate') ? customData.fromdate : '',
				todate: customData.hasOwnProperty('todate') ? customData.todate : '',
				users: customData.hasOwnProperty('users') ? customData.users : ''
			};

			self.getPCSServerInfo(function (pcsServerInfo) {
				if (pcsServerInfo.uri) {
					self.pcsServerURL(pcsServerInfo.uri);

					if (!taskListInitializedFlag) {

						self.getToken(pcsServerInfo.uri, function (authToken) {
							if (authToken && authToken === 'err') {
								self.pcsServerURLErr(true);
								SitesSDK.setProperty('height');
							}
							authToken = authToken ? authToken : "Basic " + btoa('bpmqaadmin' + ":" + 'welcome1');
							// get the design css
							SitesSDK.getSiteProperty('themeDesign', function (data) {
								var designCss = '';
								if (data.themeDesign && typeof data.themeDesign === 'string') {
									designCss = data.themeDesign;
								}
								self.initializeTaskList(pcsServerInfo.uri, authToken, designCss);
								taskListInitializedFlag = true;
							});

						});
					} else {
						self.loadList();
					}
				} else {
					self.pcsServerURLErr(true);
					SitesSDK.setProperty('height');
				}
			}, function (err) {
				// Error getting the PCS connection. Set the height for the watermark.
				self.pcsServerURL('err');
				console.log(err);
				SitesSDK.setProperty('height');
			});

		};

		self.updateSettings = $.proxy(function (message) {
			var settings = message.detail ? message.detail.message : message;

			if (settings.property === 'customSettingsData') {
				self.init(settings.value);

			}
		}, self);

		//
		// Execute Actions
		//
		self.executeAction = function (args) {
			var self = this;
			var action = args.detail.message.action;
			console.log('Refreshing the PCS Task list');

			if (action && (action.actionName === 'scsPCSTaskDetailsApproved' || action.actionName === 'scsPCSTaskDetailsRejected' || action.actionName === 'scsPCSTaskDetailsSubmitted')) {
				self.getPCSServerInfo(function (pcsServerInfo) {
					if (pcsServerInfo.uri) {
						if (!taskListInitializedFlag) {
							self.getToken(pcsServerInfo.uri, function (authToken) {
								if (authToken && authToken === 'err') {
									self.pcsServerURLErr(true);
									SitesSDK.setProperty('height');
								}
								authToken = authToken ? authToken : "Basic " + btoa('bpmqaadmin' + ":" + 'welcome1');
								// get the design css
								SitesSDK.getSiteProperty('themeDesign', function (data) {
									var designCss = '';
									if (data.themeDesign && typeof data.themeDesign === 'string') {
										designCss = data.themeDesign;
									}
									self.initializeTaskList(pcsServerInfo.uri, authToken, designCss);
									taskListInitializedFlag = true;
								});

							});
						} else {
							self.loadList();
						}

						taskListInitializedFlag = true;
					} else {
						self.pcsServerURLErr(true);
						SitesSDK.setProperty('height');
					}
				});
			}
		};

		//	Logic on PCSTaskListViewModel 	//
		//	===============================	//	
		//									//		


		//
		// Initialize the customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.init);

		//
		//  Listen for changes to the settings data.
		//      e.g.: When the Settings Panel changes the data
		//
		SitesSDK.subscribe('SETTINGS_UPDATED', self.updateSettings);

		//
		// Sites SDK Triggers and Actions listeners
		//
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeAction, self));


	}; // End of PCSTaskListViewModel

	PCSTaskListViewModel.prototype.getPCSServerInfoFromDocs = function (onSuccess, onError) {
		var self = this,
			docsConfigUrl = '/documents/web?IdcService=AF_GET_APP_INFO_SIMPLE&dAppName=PCS',
			appInfo,
			i,
			enabled = '',
			pcsServerInfo = {};

		// get server url from docs Admin 
		$.ajax({
			'type': 'GET',
			'dataType': 'json',
			'url': docsConfigUrl,
			'success': function (data) {
				// console.log('docsConfigUrl=' + docsConfigUrl + ' data=' + JSON.stringify(data));
				appInfo = data.ResultSets.AFApplicationInfo;
				if (appInfo) {
					for (i = 0; i < appInfo.fields.length; i++) {
						if (appInfo.fields[i].name === 'dAppEndPoint') {
							pcsServerInfo.uri = appInfo.rows[appInfo.currentRow][i];
						} else if (appInfo.fields[i].name === 'dIsAppEnabled') {
							enabled = appInfo.rows[appInfo.currentRow][i];
						}
						if (pcsServerInfo.uri && enabled) {
							break;
						}
					}
					if (enabled !== '1') {
						pcsServerInfo.uri = '';
					}
				}
				if (pcsServerInfo.uri) {
					self.isECPCS = pcsServerInfo.uri.indexOf('/ic/') >= 0;

					// Fix the URI
					var start;
					if (pcsServerInfo.uri.indexOf('//') >= 0) {
						start = pcsServerInfo.uri.indexOf('//') + 2;
					}
					if (pcsServerInfo.uri.indexOf('/', start) > 0) {
						// remove everything after /
						pcsServerInfo.uri = pcsServerInfo.uri.slice(0, pcsServerInfo.uri.indexOf('/', start));
					}
				} else {
					console.log('getPCSServerInfoFromDocs: url=' + docsConfigUrl + ' no PCS configured');
					if (typeof onError === 'function') {
						onError();
					}
				}

				console.log("PCS Server (from docs admin) is : " + pcsServerInfo.uri + " isEC: " + self.isECPCS);
				if (typeof onSuccess === 'function') {
					onSuccess(pcsServerInfo);
				}
			},
			'error': function (xhr, status, err) {
				console.log('getPCSServerInfoFromDocs: url=' + docsConfigUrl + ' status: ' + status + ' error: ' + err);
				if (typeof onError === 'function') {
					onError();
				}
			}
		});
	};

	PCSTaskListViewModel.prototype.getPCSServerInfo = function (onSuccess, onError) {
		var self = this;

		self.getPCSServerInfoFromDocs(onSuccess, function () {
			$.ajax({
				'type': 'GET',
				'url': '/pxysvc/api/1.0/endpoint',
				'contentType': 'application/json; charset=utf-8',
				'dataType': 'json',
				'success': function (data) {
					if (typeof onSuccess === 'function') {

						var pcsServerInfo = {};
						if (data.length > 0) {
							var i;
							for (i = 0; i < data.length; i++) {

								// Path name should be 'pcs' and keyword should contain 'pcs'
								if (data[i].pathName === 'pcs' && data[i].keywords) {
									var keywords = data[i].keywords.split();
									var j;
									for (j = 0; j < keywords.length; j++) {
										if (keywords[j] === 'pcs') {
											pcsServerInfo.uri = data[i].targetUri;
											break;
										}
									}

									if (pcsServerInfo.uri) {
										// Fix the URI
										var start;
										if (pcsServerInfo.uri.indexOf('//') >= 0) {
											start = pcsServerInfo.uri.indexOf('//') + 2;
										}
										if (pcsServerInfo.uri.indexOf('/', start) > 0) {
											// remove everything after /
											pcsServerInfo.uri = pcsServerInfo.uri.slice(0, pcsServerInfo.uri.indexOf('/', start));
										}
										// Found the PCS URI - break
										break;
									}
								}
							}
						}
						console.log("PCS Server (from proxy) is : " + pcsServerInfo.uri);
						onSuccess(pcsServerInfo);
					}
				},
				'error': function (xhr, status, err) {
					if (typeof onError === 'function') {
						onError(err);
					}
				}
			});
		});

	};

	//-----------------------------------------------
	// Get render Sites SDK parameters, e.g, viewMode
	//-----------------------------------------------
	PCSTaskListViewModel.prototype.getQueryParameters = function (url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	};



	var taskListViewModel = new PCSTaskListViewModel();
	// initialize knockout binding
	ko.applyBindings({
		'templateViewModel': taskListViewModel
	});


})();