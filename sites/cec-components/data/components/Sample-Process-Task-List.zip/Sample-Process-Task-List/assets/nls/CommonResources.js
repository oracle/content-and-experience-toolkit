/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define({
	"root": {
	// pcs-task-list
	"APP_PCS_TASK_LIST_DISPLAY_NAME": "Task List",
	"APP_PCS_TASK_LIST_DESCRIPTION": "Task List",
	"APP_PCS_TASK_LIST_DISPLAY_OPTIONS": "Display Options",
	"APP_PCS_TASK_LIST_PAGE_SIZE": "Page Size",
	"APP_PCS_TASK_LIST_SHOW_DETAILS": "Show Details",
	"APP_PCS_TASK_LIST_SHOW_SEARCH": "Show Search",
	"APP_PCS_TASK_LIST_SHOW_FILTER": "Show Filter",
	"APP_PCS_TASK_LIST_SHOW_SELECT_ALL": "Show Select All",
	"APP_PCS_TASK_LIST_SEARCH_KEYWORD": "Search keywords",
	"APP_PCS_TASK_LIST_STATUS": "Status",
	"APP_PCS_TASK_LIST_ASSIGNEE": "Assignee",
	"APP_PCS_TASK_LIST_FROMUSER": "From user",
	"APP_PCS_TASK_LIST_DUEDATE": "Due date",
	"APP_PCS_TASK_LIST_APPLICATION": "Application",
	"APP_PCS_TASK_LIST_SEARCH_USER_PLACEHOLDER": "Search for identities",
	
	//pcs-task-list filter options in settings
	"APP_PCS_TASK_LIST_STATUS_ASSIGNED": "Assigned",
	"APP_PCS_TASK_LIST_STATUS_INFO_REQUESTED": "Info Requested",
	"APP_PCS_TASK_LIST_STATUS_WITHDRAWN": "Withdrawn",
	"APP_PCS_TASK_LIST_STATUS_SUSPENDED": "Suspended",
	"APP_PCS_TASK_LIST_STATUS_ALERTED": "Alerted",
	"APP_PCS_TASK_LIST_STATUS_ERRORED": "Errored",
	"APP_PCS_TASK_LIST_STATUS_EXPIRED": "Expired",
	"APP_PCS_TASK_LIST_STATUS_COMPLETED": "Completed",
	"APP_PCS_TASK_LIST_ASSIGNEE_MY": "My Tasks",
	"APP_PCS_TASK_LIST_ASSIGNEE_MY_AND_GROUP": "Me And My Group",
	"APP_PCS_TASK_LIST_ASSIGNEE_MY_AND_GROUP_ALL": "Me And My Group All",
	"APP_PCS_TASK_LIST_ASSIGNEE_CREATOR": "Started By Me",
	"APP_PCS_TASK_LIST_ASSIGNEE_REPORTEES": "Reports to Me",
	"APP_PCS_TASK_LIST_ASSIGNEE_REVIEWER": "Reviewed by Me",
	"APP_PCS_TASK_LIST_DUEDAY_ON": "On",
	"APP_PCS_TASK_LIST_DUEDAY_BEFORE": "Before",
	"APP_PCS_TASK_LIST_DUEDAY_AFTER": "After",
	"APP_PCS_TASK_LIST_DUEDAY_BETWEEN": "Between",
	"APP_PCS_TASK_LIST_FROM_DATE": "from date",
	"APP_PCS_TASK_LIST_TO_DATE": "to date"
}
});
