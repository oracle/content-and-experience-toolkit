/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global $ */
var SitesPCSUtils = (function () {
	var componentVersion = 'v1.3';

	var paths = {
		'pcsMsg': 'libs/pcs/' + componentVersion + '/resources',
		'rendererMsg': 'libs/pcs/' + componentVersion + '/rendererMsg',
		'pcs': 'libs/pcs/' + componentVersion + '/min'
	};

	// Attempt to get the OAUTH token when setup with same IDM
	// 
	// We need to make ajax call for the token and handle html response. 
	// Handling html involves programmatically parsing the html and submitting the form in the html.
	//
	// parameters: args
	//    args.serverURL - URL to the VBCS/PCS server, e.g.:  https://sbgdataoicdevic-sbgdatacloudservice.uscom-central-1.oraclecloud.com
	//    args.successCallback - function to call on successfully retrieving the token
	//    args.errorCallback - function to call when failed to get the token
	//
	var authToken;
	var getAuthToken = function (args) {
		// dummy function if callbacks not supplied
		var dummyCallback = function () {};

		// extract the args and create the server URL
		var serverURL = (args.serverURL || '/').split('/ic/')[0], // handle server URLs that contain '/ic/' context
			successCallback = args.successCallback || dummyCallback,
			errorCallback = args.errorCallback || dummyCallback,
			tokenURL = serverURL + (args.tokenPath || '/ic/process/workspace/auth/token');

		// try to get the token normally
		$.ajax({
			'type': 'GET',
			'url': tokenURL,
			'dataType': 'text',
			'xhrFields': {
				'withCredentials': true
			},
			'success': function (resp, status, xhr) {
				var ct = xhr.getResponseHeader("content-type") || "";

				// if the response was an HTML Form....
				if (ct.indexOf('html') > -1) {
					// not logged in - got a form from the re-direct

					// parse the form and submit it
					var parser = new DOMParser(),
						htmlDoc = parser.parseFromString(resp, "text/html"),
						forms = htmlDoc.getElementsByTagName("form");
					if (forms.length === 1) {
						var f = forms[0];
						$.post(f.action, $(f).serialize(), function (data) {
							// retry getting the token now form has ben submitted
							$.ajax({
								'type': 'GET',
								'url': tokenURL,
								'dataType': 'text',
								'xhrFields': {
									'withCredentials': true
								},
								'success': function (token) {
									// cache the token
									authToken = token;

									// return the token
									successCallback(authToken);
								}
							}).fail(errorCallback);
						}).fail(errorCallback);
					}
				} else {
					// already logged in

					// cache the the token
					authToken = resp;

					// return the token
					successCallback(authToken);
				}
			}
		}).fail(errorCallback);
	};

	return {
		'paths': paths,
		'getAuthToken': getAuthToken
	};

})();
