/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs */
requirejs.config({
	'baseUrl': '.',

	paths: {

		'knockout': '../../../../libs/knockout/build/output/knockout-latest',
		'jquery': '../../../../libs/jquery/dist/jquery',
		// Oracle JET dependencies
		'ojs':                '../../../../libs/oraclejet/dist/js/libs/oj/min',
		'ojL10n':             '../../../../libs/oraclejet/dist/js/libs/oj/ojL10n',
		'ojtranslations':     '../../../../libs/oraclejet/dist/js/libs/oj/resources',
		'ojalta-css':         '../../../../libs/oraclejet/dist/css/alta/oj-alta-min',
		'ojalta-css-notag':   '../../../../libs/oraclejet/dist/css/alta/oj-alta-notag-min',
		'jquery-ui':          '../../../../libs/jquery-ui/ui',
		'jquery-ui-css':      '../../../../libs/jquery-ui/themes/ui-lightness/jquery-ui.min',
		'css':                '../../../../libs/require-css/css.min',
		'customElements':     '../../../../libs/custom-elements/custom-elements.min',
		'promise':            '../../../../libs/es6-promise/dist/es6-promise.min',
		'hammerjs':           '../../../../libs/hammerjs/hammer.min',
		'scrollbar':          '../../../../libs/jquery.scrollbar/jquery.scrollbar.min',
		'scrollbar-css':      '../../../../libs/jquery.scrollbar/jquery.scrollbar'
	},
	shim: {
		"jquery-ui": {
			"export": "$",
			deps: ['jquery']
		}
	},
	config: {
		ojL10n: {
			// APPS.languageCodes
		}
	},
	map: {
		'*': {
			// https://github.com/rniemeyer/knockout-sortable/issues/175
			'jquery-ui/sortable': 'jquery-ui/widgets/sortable',
			'jquery-ui/draggable': 'jquery-ui/widgets/draggable',

			'css': '../../../../libs/require-css/css.min',
			'jqueryui-amd': 'jquery-ui'
		}
	},
	waitSeconds: 0
});

requirejs(['jquery', 'knockout', './settings-vm'], function($, ko, vm) {
	'use strict';
	 ko.applyBindings(vm);
});
