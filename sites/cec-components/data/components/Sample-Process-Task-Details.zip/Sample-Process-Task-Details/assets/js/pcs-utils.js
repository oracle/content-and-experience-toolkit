/* global $ */
var SitesPCSUtils = (function () {
	var componentVersion = 'v1.3';

	var paths = {
		'pcsMsg': 'libs/pcs/' + componentVersion + '/resources',
		'rendererMsg': 'libs/pcs/' + componentVersion + '/rendererMsg',
		'pcs': 'libs/pcs/' + componentVersion + '/min'
	};

	// For Bug#28845616, we need to initialize access to PCS before trying to make REST calls
	// This is required until CloudGate supports CORS requests, which are blocking the cross-domain REST requests in the PODS
	// This function inserts an iframe to a PCS secured resource, which subsequently calls us back when it is loaded. 
	// Once the iframe is loaded, the SSO cookies are all setup to get past the CloudGate/WTSS/IDCS CORS blocking issue. 
	var pcsInitializationDeferred;
	var initializePCSConnection = function (serverURL) {
		var resourceURL = serverURL + '/ic/process/workspace/internal/cors-iframe-bootstrap.html'; // URL defined as part of fix for bug#28845616
		if (!pcsInitializationDeferred) {
			pcsInitializationDeferred = new $.Deferred();
			var deferredResolved = false;

			// create a listener to wait on the PCS initialization message
			var handleMessage = function (event) {
				// handle only PCS events
				if (event.origin === serverURL) {
					// confirm the message
					try {
						var message = JSON.parse(event.data);
						if (message && message.resourceInitialization) {
							// if haven't resolved the deferred object yet, resolve it here
							if (!deferredResolved) {
								// note that we've resolved the deferred object
								deferredResolved = true;

								// expected message, resolve with the status
								pcsInitializationDeferred.resolve(message.resourceInitialization.status || 'initialized');
							}
						} else {
							// not expected initialization message, ignore
						}
					} catch (e) {
						// not expected initialization message, ignore
					}
				}
			};
			window.addEventListener('message', handleMessage, false);

			// create an iframe for the PCS resource to return the initialization messsage
			var pcsIframe = $('<iframe src="' + resourceURL + '" style="width:0px;height:0px;display:none">');
			$('body').append(pcsIframe);

			// Resolve the deferred object if we don't get the initialization message message within 10 seconds
			// This should never happen but we do want to get a final result/error here.  
			setTimeout(function () {
				// if haven't resolved within 10s, log the message and resolve
				if (!deferredResolved) {
					pcsInitializationDeferred.resolve('not initialized');
				}
			}, 10000);
		}

		// return the deferred object
		return pcsInitializationDeferred;
	};

	// Attempt to get the OAUTH token when setup with same IDM
	// See: https://confluence.oraclecorp.com/confluence/display/~suman.g.ganta@oracle.com/Seamless+identity+propagation+with+IDCS
	// 
	// IDCS Setup
	//   An IDCS App had been setup for two more service instances which allows seamless SSO between these two service instances. 
	//   Note that both service instances have different host names in the urls, hence they do not share authentication cookies.
	//
	// Login sequence
	//     Login to sites https://sbgcontentclouddev2-sbgdatacloudservice.uscom-east-1.oraclecloud.com/documents
	//     This takes you to IDCS login page https://idcs-bddbf34ba3b94c81bc156c3bc5892632.identity.oraclecloud.com/ui/v1/signin
	//     Get OIC access token from https://sbgdataoicdevic-sbgdatacloudservice.uscom-central-1.oraclecloud.com/ic/process/workspace/token
	// 
	//     This does a 302 to https://idcs-bddbf34ba3b94c81bc156c3bc5892632.identity.oraclecloud.com/oauth2/v1/authorize?response_mode=form_post
	// 	   The response of the above is a html with a form (which is auto submittable)
	// 
	// So, we need to make ajax call for the token and handle html response. 
	// Handling html involves programmatically parsing the html and submitting the form in the html.
	//
	// parameters: args
	//    args.serverURL - URL to the VBCS/PCS server, e.g.:  https://sbgdataoicdevic-sbgdatacloudservice.uscom-central-1.oraclecloud.com
	//    args.successCallback - function to call on successfully retrieving the token
	//    args.errorCallback - function to call when failed to get the token
	//
	var authToken;
	var getAuthToken = function (args) {
		// dummy function if callbacks not supplied
		var dummyCallback = function () {};

		// extract the args and create the server URL
		var serverURL = (args.serverURL || '/').split('/ic/')[0], // handle server URLs that contain '/ic/' context
			successCallback = args.successCallback || dummyCallback,
			errorCallback = args.errorCallback || dummyCallback,
			tokenURL = serverURL + (args.tokenPath || '/ic/process/workspace/auth/token');

		// initialize the PCS connection before trying to get the token
		initializePCSConnection(serverURL).then(function () {
			// try to get the token normally
			$.ajax({
				'type': 'GET',
				'url': tokenURL,
				'dataType': 'text',
				'xhrFields': {
					'withCredentials': true
				},
				'success': function (resp, status, xhr) {
					var ct = xhr.getResponseHeader("content-type") || "";

					// if the response was an HTML Form....
					if (ct.indexOf('html') > -1) {
						// not logged in - got a form from the re-direct

						// parse the form and submit it
						var parser = new DOMParser(),
							htmlDoc = parser.parseFromString(resp, "text/html"),
							forms = htmlDoc.getElementsByTagName("form");
						if (forms.length === 1) {
							var f = forms[0];
							$.post(f.action, $(f).serialize(), function (data) {
								// retry getting the token now form has ben submitted
								$.ajax({
									'type': 'GET',
									'url': tokenURL,
									'dataType': 'text',
									'xhrFields': {
										'withCredentials': true
									},
									'success': function (token) {
										// cache the token
										authToken = token;

										// return the token
										successCallback(authToken);
									}
								}).fail(errorCallback);
							}).fail(errorCallback);
						}
					} else {
						// already logged in

						// cache the the token
						authToken = resp;

						// return the token
						successCallback(authToken);
					}
				}
			}).fail(errorCallback);
		});
	};

	return {
		'paths': paths,
		'getAuthToken': getAuthToken
	};

})();