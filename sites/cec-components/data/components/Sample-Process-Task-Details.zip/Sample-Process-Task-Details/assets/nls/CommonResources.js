/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
define({
	"root": {
   // pcs-task-details
	"APP_PCS_TASK_DETAILS_DISPLAY_NAME": "Task Details",
	"APP_PCS_TASK_DETAILS_DESCRIPTION": "Task Details",
	"APP_PCS_TASK_DETAILS_TASK_NUMBER": "Task Number",
	"APP_PCS_TASK_DETAILS_DISPLAY_OPTIONS": "Display Options",
	"APP_PCS_TASK_DETAILS_SHOW_ACTIONS": "Show Actions",
	"APP_PCS_TASK_DETAILS_SHOW_SAVE": "Show Save",
	"APP_PCS_TASK_DETAILS_SHOW_CLOSE": "Show Close",
	"APP_PCS_TASK_DETAILS_SHOW_ATTACHMENT": "Show Attachment",
	"APP_PCS_TASK_DETAILS_SHOW_COMMENTS": "Show Comments",
	"APP_PCS_TASK_DETAILS_SHOW_HISTORY": "Show History",
	"APP_PCS_TASK_DETAILS_SHOW_MORE_INFO": "Show More Information",
	"APP_PCS_TASK_DETAILS_SHOW_LINKS": "Show Links",
	"APP_PCS_TASK_DETAILS_NEW_VERSION_MSG": "A newer version of Process Cloud Service is required to use the task details component.",
	"APP_PCS_TASK_DETAILS_TRIGGER_SUBMIT_NAME": "Task details submitted",
	"APP_PCS_TASK_DETAILS_TRIGGER_APPROVE_NAME": "Task approved",
	"APP_PCS_TASK_DETAILS_TRIGGER_REJECT_NAME": "Task rejected",
	"APP_PCS_TASK_DETAILS_TRIGGER_SAVE_NAME": "Task saved",
	"APP_PCS_TASK_DETAILS_TRIGGER_COMMENT_ADD_NAME": "Task comment added",
	"APP_PCS_TASK_DETAILS_TRIGGER_PAYLOAD_TASK_NUMBER": "Task Number",
	"APP_PCS_TASK_DETAILS_TRIGGER_PAYLOAD_COMMENT": "Comment",
	"APP_PCS_TASK_DETAILS_ACTION_SHOW": "Display task details",
	"APP_PCS_TASK_DETAILS_ACTION_PAYLOAD_TASK_NUMBER": "Task Number"
}
});
