/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,define,alert*/
/*jslint plusplus: true */
define(['jquery', 'knockout', 'CommonResources', 'app-utils'], function ($, ko, strings, appUtils) {
	'use strict';
	var devcsServer = window.location.port === '8085',
		defaultFolder = window.location.port === '8085' ? 'home' : '',
		idcFolderItemsUri = devcsServer ? '/documents/web?IdcService=FLD_BROWSE_PERSONAL&IsJson=1&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]' : '/documents/web?IdcService=FLD_BROWSE&IsJson=1&items=fFolderGUID:[folder]&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]',
		templateViewModel,
		MyViewModel = function () {
			var self = this,
				getAppTriggersListener;

			// create the observables
			self.queryResult = ko.observableArray([]);
			self.folderName = ko.observable('');
			self.hybridLinkID = '';
			self.hybridFolderID = '';
			self.selectedSubFolderId = ko.observable('');
			self.noFolderSelected = ko.observable(false);
			self.showPfname = ko.observable(true);
			self.setHeight = false;

			self.noFolderMsg = ko.observable(strings.APP_FOLDERLIST_NO_FOLDER_TO_DISPLAY);
			self.folderListLabel = ko.observable(strings.APP_FOLDERLIST_DISPLAY_NAME);
			self.appParams = self.getQueryParameters(window.location.href);
			self.isRendering = ko.observable(false);

			SitesSDK.getProperty('viewMode', function(viewMode) {
				self.isRendering(viewMode!== 'edit');
			});

			// Calculation for watermark
			// will reset after query
			self.hasVisualData = ko.observable(true);

			// load the theme css
			ko.computed(function () {
				SitesSDK.getSiteProperty('themeDesign', function (data) {
					// check if we got an themeDesign back
					if (data.themeDesign && typeof data.themeDesign === 'string') {
						if (data.themeDesign !== '') {
							// theme is loaded so dynamically inject theme
							SitesSDK.Utils.addSiteThemeDesign(data.themeDesign);
						}
					}
				});
			});

			// fetch custom settings data and initialize
			self.init = function (customData) {
				self.config = {
					folderGuid: customData.hasOwnProperty('folderGuid') ? customData.folderGuid.replace('folder/', '') : '',
					publiclink: customData.hasOwnProperty('publiclink') ? customData.publiclink : '',
					folderAccess: customData.hasOwnProperty('folderAccess') ? customData.folderAccess : 'downloader',
					showConvoPane: customData.hasOwnProperty('showConvoPane') ? customData.showConvoPane : true,
					sortBy: customData.hasOwnProperty('sortBy') ? customData.sortBy : 'nameasc',
					pfname: customData.hasOwnProperty('pfname') ? customData.pfname : true,
					shownum: customData.hasOwnProperty('shownum') ? customData.shownum : '50',
					showNumOption: customData.hasOwnProperty('showNumOption') ? customData.showNumOption : 'all',
					defaultSelection: customData.hasOwnProperty('defaultSelection') ? customData.defaultSelection : ''
				};

				self.folderAccess = self.hybridLinkID !== '' && self.hybridFolderID !== '' ? self.config.folderAccess : 'member';
				self.showConvoPane = self.folderAccess !== 'member' ? false : self.config.showConvoPane;
				
				self.selectedSubFolderId(self.config.defaultSelection);

				self.noFolderSelected(false);

				self.fetchData();

				self.showPfname(self.config.pfname);

				//listen to the following value changes to adjust render height
				ko.computed(function () {

					if (self.noFolderSelected()) {
						// When no folder selected, adjust height to not show the application in preview or just the watermark in edit
						SitesSDK.setProperty('height');
					} else {
						//In other cases, we only reset height when init function is finished and there's any settings changed afterwards.
						if (self.setHeight) {
							SitesSDK.setProperty('height');
						}
					}

				});

				self.setHeight = true;

			};

			// get the  hybridlink data and customSettings Data, then init the viewModel
			SitesSDK.getProperty('componentAssets', function (assets) {

				//alert("assets length==" + assets.length);
				//get hybrid link id and folder id
				if (assets.length > 0) {
					var source = assets[0].source,
						linkId,
						folderId;
					linkId = source.indexOf('/link/') > 0 ? source.substring(source.indexOf('/link/') + 6) : '';
					folderId = source.indexOf('/folder/') > 0 ? source.substring(source.indexOf('/folder/') + 8) : '';
					if (linkId.indexOf('/') > 0) {
						linkId = linkId.substring(0, linkId.indexOf('/'));
					}
					if (folderId.indexOf('/') > 0) {
						folderId = folderId.substring(0, folderId.indexOf('/'));
					}
					self.hybridLinkID = linkId;
					self.hybridFolderID = folderId;
				}
				SitesSDK.getProperty('customSettingsData', self.init);
			});



			//
			// Sites SDK Triggers and Actions listeners
			//

			// TRIGGERS meta-data listener
			getAppTriggersListener = function (args) {
				var triggers = [
					{
						'triggerName': 'scsFolderViewerFolderSelectedTrigger',
						'triggerDescription': strings.APP_FOLDERLIST_TRIGGER_FOLDER_SELECTED,
						'triggerPayload': [
							{
								'name': 'id',
								'displayName': strings.APP_FOLDERLIST_TRIGGER_FOLDER_ID
							},
							{
								'name': 'link',
								'displayName': strings.APP_FOLDERLIST_TRIGGER_FOLDER_LINK
							},
							{
								'name': 'name',
								'displayName': strings.APP_FOLDERLIST_TRIGGER_FOLDER_NAME
							},
							{
								'name': 'description',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_DESCRIPTION
							},
							{
								'name': 'mimeType',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_MIME_TYPE
							},
							{
								'name': 'size',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_SIZE
							},
							{
								'name': 'author',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_AUTHOR
							},
							{
								'name': 'createdTime',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_CREATED_TIME
							},
							{
								'name': 'modifiedTime',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_MODIFIED_TIME
							}]
					}];
				return triggers;
			};

			// Folder Selected Trigger
			self.raiseFolderSelectedTrigger = function (triggerPayload) {

				// Update the selected subfolder id
				self.selectedSubFolderId(triggerPayload.id);

				// Raise the folder selected trigger and don't specify any actions
				// This is used to execute any Actions registered against this trigger in the page
				SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
					'triggerName': 'scsFolderViewerFolderSelectedTrigger', // use first registered trigger name
					'triggerPayload': triggerPayload
				});


				// Raise the trigger and call named actions
				// This is used to communicate directly with any apps regardless of any page wiring
				SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
					'triggerName': 'raiseFolderSelectedTrigger', // define custom trigger name
					'triggerPayload': triggerPayload,
					'actions': ['scsViewFolder']
				});
			};


			//-----------------------------------------------
			// Define the event listeners
			//-----------------------------------------------

			// listen for TRIGGERS meta-data request and send trigger metadata to host-site
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getAppTriggersListener);

			//listen for settings update
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.handleUpdatedSettings, self));

		};




	MyViewModel.prototype.refresh = function () {

		var self = this,
			server = '',
			linkId,
			folderId,
			orderbyCol = 'fItemName',
			orderby = 'Asc',
			docWebUri,
			uri,
			seededData = [],
			idx,
			sortAsc = true,
			sortCol = 'name',
			limit,
			total,
			i;
		//
		// hybrid link case
		//
		if (self.folderAccess !== 'member' && self.hybridLinkID !== '' && self.hybridFolderID !== '') {

			//console.log('refresh: hybrid link access');
			
			linkId = self.hybridLinkID;
			folderId = self.hybridFolderID;

			if (self.config.sortBy === 'namedesc') {
				orderby = 'Desc';
			} else if (self.config.sortBy === 'lastupdateasc') {
				orderbyCol = 'fLastModifiedDate';
			} else if (self.config.sortBy === 'lastupdatedesc') {
				orderbyCol = 'fLastModifiedDate';
				orderby = 'Desc';
			}

			docWebUri = '/documents/link/web' +
				'?dLinkID=' + linkId +
				'&item=fFolderGUID:' + folderId +
				'&IdcService=' + 'FLD_BROWSE' +
				'&doCombinedBrowse=1' +
				'&combinedCount=' + '999' +
				'&combinedStartRow=0' +
				'&combinedSortField=' + orderbyCol +
				'&combinedSortOrder=' + orderby;

			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docWebUri,
				'success': function (data) {
					self.parseWebData(server, linkId, folderId, data);
					self.hasVisualData(self.queryResult().length > 0);
					self.hasVisualData.valueHasMutated();
				},
				'error': function (xhr, status, err) {
					// alert("Error");
					self.hasVisualData(false);
					self.hasVisualData.valueHasMutated();
				}
			});

			//alert("using hybrid link");

			return;
		}


		//
		// public link case
		//
		if (self.config.publiclink !== '') {
			server = self.config.publiclink.indexOf('/documents/') > 0 ? self.config.publiclink.substring(0, self.config.publiclink.indexOf('/documents/')) : '';
			linkId = self.config.publiclink.indexOf('/link/') > 0 ? self.config.publiclink.substring(self.config.publiclink.indexOf('/link/') + 6) : '';
			folderId = self.config.publiclink.indexOf('/folder/') > 0 ? self.config.publiclink.substring(self.config.publiclink.indexOf('/folder/') + 8) : '';
			if (linkId.indexOf('/') > 0) {
				linkId = linkId.substring(0, linkId.indexOf('/'));
			}
			if (folderId.indexOf('/') > 0) {
				folderId = folderId.substring(0, folderId.indexOf('/'));
			}
			if (server === '') {
				server = 'https://documents.us.oracle.com';
			}

			if (self.config.sortBy === 'namedesc') {
				orderby = 'Desc';
			} else if (self.config.sortBy === 'lastupdateasc') {
				orderbyCol = 'fLastModifiedDate';
			} else if (self.config.sortBy === 'lastupdatedesc') {
				orderbyCol = 'fLastModifiedDate';
				orderby = 'Desc';
			}

			docWebUri = '/documents/link/web' +
				'?dLinkID=' + linkId +
				'&item=fFolderGUID:' + folderId +
				'&IdcService=' + 'FLD_BROWSE' +
				'&doCombinedBrowse=1' +
				'&combinedCount=' + '999' +
				'&combinedStartRow=0' +
				'&combinedSortField=' + orderbyCol +
				'&combinedSortOrder=' + orderby;

			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docWebUri,
				'success': function (data) {
					self.parseWebData(server, linkId, folderId, data);
					self.hasVisualData(self.queryResult().length > 0);
					self.hasVisualData.valueHasMutated();
				},
				'error': function (xhr, status, err) {
					// alert("Error");
					self.hasVisualData(false);
					self.hasVisualData.valueHasMutated();
				}
			});


			return;
		}

		//
		// docs server case
		//

		if (self.config.folderGuid === '') {
			self.noFolderSelected(true);
			self.noFolderSelected.valueHasMutated();
			self.hasVisualData(false);
			self.hasVisualData.valueHasMutated();
			return;
		}
		//console.log('refresh: member access');

		folderId = self.config.folderGuid;
		
		// Sorting option
		orderbyCol = 'fItemName';
		orderby = self.config.sortBy === 'nameasc' ? 'Asc' : 'Desc';

		uri = idcFolderItemsUri.replace('[folder]', self.config.folderGuid);
		uri = uri.replace('[sortfield]', orderbyCol);
		uri = uri.replace('[sortorder]', orderby);

		// the query result includes both folders and files, we use a big limit to query and filter later
		$.ajax({
			'type': 'GET',
			'dataType': 'json',
			'url': uri,
			'success': function (data) {
				self.parseWebData('', '', folderId, data);
				self.hasVisualData(self.queryResult().length > 0);
				self.hasVisualData.valueHasMutated();
			},
			'error': function (xhr, status, err) {
				// alert('status=' + status + ' err=' + err);
				self.hasVisualData(false);
				self.hasVisualData.valueHasMutated();
			}
		});
	};

	MyViewModel.prototype.getFolder = function () {

		var self = this,
			i;

		// the folder name will be set in get folder content query
	};

	MyViewModel.prototype.parseWebData = function (server, linkId, folderId, webData) {
		var self = this,
			i,
			fFolderGUIDIdx,
			fFolderNameIdx,
			fFolderDescriptionIdx,
			fLastModifierFullNameIdx,
			fCreateDateIdx,
			fLastModifiedDateIdx,
			fields,
			total = 0,
			updatedArray = [],
			results,
			idx,
			ymd,
			dateStr,
			titleStr;

		if (!devcsServer && !webData.ResultSets.FolderInfo) {
			// REST failed
			// check webData.StatusCode and webData.StatusMessage
			return;
		}
		
		//When it's hybrid link case, add this check to always make sure the return data 
		//folder id is the same as current hybridFolderID. This is because
		//when settings get updated and the render get triggered refresh mutiple times
		//and call init mutiple times,it seems sometimes there's a delay the earlier FLD_BROWSE
		//that with the old hybridlink data from self.refresh returns in the end and causing
		//the render to render old folder selection data.
		if (self.hybridFolderID !== '' && folderId !== self.hybridFolderID) {
			return;
		}

		// get the folder info
		if (!devcsServer) {
			for (i = 0; i < webData.ResultSets.FolderInfo.fields.length; i++) {
				if (webData.ResultSets.FolderInfo.fields[i].name === 'fFolderName') {
					self.folderName(webData.ResultSets.FolderInfo.rows[webData.ResultSets.FolderInfo.currentRow][i]);
					break;
				}
			}
		} else {
			self.folderName('Home');
		}

		// get the folder list

		fields = webData.ResultSets.ChildFolders.fields;
		for (i = 0; i < fields.length; i++) {
			if (fields[i].name === 'fFolderGUID') {
				fFolderGUIDIdx = i;
			} else if (fields[i].name === 'fFolderName') {
				fFolderNameIdx = i;
			} else if (fields[i].name === 'fFolderDescription') {
				fFolderDescriptionIdx = i;
			} else if (fields[i].name === 'fLastModifierFullName') {
				fLastModifierFullNameIdx = i;
			} else if (fields[i].name === 'fCreateDate') {
				fCreateDateIdx = i;
			} else if (fields[i].name === 'fLastModifiedDate') {
				fLastModifiedDateIdx = i;
			}
		}

		results = webData.ResultSets.ChildFolders.rows;

		for (idx = 0; idx < results.length; idx++) {
			ymd = results[idx][fLastModifiedDateIdx].substr(0, 10).split('-');
			dateStr = ymd[1] + '/' + ymd[2] + '/' + ymd[0];
			titleStr = results[idx][fFolderNameIdx];
			updatedArray.push({
				'id': results[idx][fFolderGUIDIdx],
				'name': results[idx][fFolderNameIdx],
				'title': titleStr.substring(0, titleStr.lastIndexOf('.')),
				'description': results[idx][fFolderDescriptionIdx],
				'author': results[idx][fLastModifierFullNameIdx],
				'showConvoPane': self.showConvoPane,
				'createdTime': results[idx][fCreateDateIdx],
				'modifiedTime': results[idx][fLastModifiedDateIdx],
				'link': linkId === '' ? ('/documents/folder/' + results[idx][fFolderGUIDIdx]) : (server + '/documents/link/' + linkId + '/folder/' + results[idx][fFolderGUIDIdx]),
				'lastModifiedMsg': appUtils.applyParameters(strings.APP_FOLDERFILE_LAST_MODIFIED, {
					'0': dateStr,
					'1': results[idx][fLastModifierFullNameIdx]
				})
			});
			total = total + 1;
			if (self.config.showNumOption !== 'all' && total === self.config.shownum) {
				break;
			}
		}

		self.queryResult(updatedArray);
	};

	MyViewModel.prototype.compare = function (a, b, isSortAsc) {
		if (a === b) {
			return 0;
		} else if (isSortAsc === true) {
			return a < b ? -1 : 1;
		} else {
			return a < b ? 1 : -1;
		}
	};

	MyViewModel.prototype.sortFunction = function (sortColumn, isSortAsc) {
		var self = this;

		self.queryResult.sort(function (a, b) {
			return self.compare(a[sortColumn], b[sortColumn], isSortAsc);
		});
	};

	MyViewModel.prototype.refreshClickHandler = function (event) {
		var self = this;

		self.refresh();
	};


	MyViewModel.prototype.getHeight = function () {
		var height = $(document).height();
		return height;
	};

	MyViewModel.prototype.afterRender = function (elements) {
		//SitesSDK.setProperty('height', templateViewModel.getHeight());
	};

	MyViewModel.prototype.fetchData = function () {
		var self = this;
		if (self.config.pfname === true) {
			self.getFolder();
		}
		self.refresh();
	};

	//-----------------------------------------------
	// Binding handler to deal with changes to number of items
	//-----------------------------------------------
	ko.bindingHandlers.scsFolderListafterListUpdate = {
		update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
			// add a dependency to items so get called when they change
			var items = ko.utils.unwrapObservable(valueAccessor());

			// set the height of the component
			SitesSDK.setProperty('height');
		}
	};


	//-----------------------------------------------
	// Get render Sites SDK parameters, e.g, viewMode
	//-----------------------------------------------
	MyViewModel.prototype.getQueryParameters = function (url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	};

	// handle changedSettings event from settings panel
	MyViewModel.prototype.handleUpdatedSettings = function (event) {

		//get the event payload
		var self = this,
			payload;
		if (typeof event.detail.message === 'object') {
			payload = event.detail.message;
		} else if (typeof event.detail.message === 'string') {
			try {
				payload = JSON.parse(event.detail.message);
			} catch (err) {
				payload = {};
			}
		} else {
			payload = {};
		}
		if (payload.property) {
			if (payload.property === 'customSettingsData') {
				//console.log('Updated customSettingsData !!!' + JSON.stringify(payload,null,2));
				//apply update
				SitesSDK.getProperty('componentAssets', function (assets) {
					if (assets.length > 0) {
						var source = assets[0].source,
							linkId,
							folderId;
						linkId = source.indexOf('/link/') > 0 ? source.substring(source.indexOf('/link/') + 6) : '';
						folderId = source.indexOf('/folder/') > 0 ? source.substring(source.indexOf('/folder/') + 8) : '';
						if (linkId.indexOf('/') > 0) {
							linkId = linkId.substring(0, linkId.indexOf('/'));
						}
						if (folderId.indexOf('/') > 0) {
							folderId = folderId.substring(0, folderId.indexOf('/'));
						}
						self.hybridLinkID = linkId;
						self.hybridFolderID = folderId;
					}

					self.init(payload.value);
				});

			}
		}

	};

	//-----------------------------------------------
	// Create the view model and initialize knockout
	//-----------------------------------------------
	templateViewModel = new MyViewModel();

	// Return the module
	return {
		'templateViewModel': templateViewModel,
		'afterRender': templateViewModel.afterRender
	};
});
