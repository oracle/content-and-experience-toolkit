// require in all JET dependencies
/* globals define */
define(['knockout', 'jquery', 'ojs/ojcore', 'ojs/ojdatetimepicker'], function (ko, $, oj) {
	'use strict';

	var JetCode = function () {};

	JetCode.prototype.init = function (viewModel) {
		// extend viewModel with any JET specific functionality

	};

	// add in any JET code
	return new JetCode();
});
