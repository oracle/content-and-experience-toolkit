/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*global ko,$,SitesSDK,define,console,alert*/
/*jslint plusplus: true */
define(['jquery', 'knockout', 'CommonResources', 'app-utils'], function ($, ko, strings, appUtils) {
	'use strict';
	var devcsServer = window.location.port === '8085',
		defaultFolder = window.location.port === '8085' ? 'home' : '',
		idcFolderItemsUri = devcsServer ? '/documents/web?IdcService=FLD_BROWSE_PERSONAL&IsJson=1&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]' : '/documents/web?IdcService=FLD_BROWSE&IsJson=1&items=fFolderGUID:[folder]&doCombinedBrowse=1&combinedCount=999&combinedStartRow=0&combinedSortField=[sortfield]&combinedSortOrder=[sortorder]',
		defaultSubFolderIdx = 0,
		uaLC = (window.navigator.userAgent).toLowerCase(),
		isIOS = uaLC.indexOf('iphone') !== -1 || uaLC.indexOf('ipad') !== -1 || uaLC.indexOf('ipod') !== -1,
		isAndroid = uaLC.indexOf('android') !== -1,
		templateViewModel,
		docsHost = location.host,
		devcsServer = window.location.port === '8085',
		defaultFolder = window.location.port === '8085' ? 'home' : '',
		MyViewModel = function () {
			var self = this,
				copyAppCustomDataListener,
				pasteAppCustomDataListener,
				getAppTriggersListener,
				getAppActionsListener,
				executeActionListener,
				tmpArray;

			// get the documents host
			tmpArray = docsHost.split('.');
			if (tmpArray.length > 1 && tmpArray[1].indexOf('sites') >= 0) {
				tmpArray[1] = tmpArray[1].replace('sites', 'documents');
				docsHost = tmpArray.join('.');
			}
			
			// create the observables
			self.queryResult = ko.observableArray([]);
			self.folderName = ko.observable('');
			self.hybridLinkID = '';
			self.hybridFolderID = '';
			self.noFolderSelected = ko.observable(false);
			self.showPfname = ko.observable(true);
			self.setHeight = false;
			self.noFileMsg = ko.observable(strings.APP_FILELIST_NO_FILES_TO_DISPLAY);
			self.docListLabel = ko.observable(strings.APP_FILELIST_DISPLAY_NAME);
			self.appParams = self.getQueryParameters(window.location.href);
			self.isRendering = ko.observable(false);
			self.downloadAlt = ko.observable("Download");

			SitesSDK.getProperty('viewMode', function(viewMode) {
				self.isRendering(viewMode!== 'edit');
			});

			// Calculation for watermark
			// will reset after query
			self.hasVisualData = ko.observable(true);

			self.dataSize = ko.computed(function () {
				return self.queryResult().length;
			});

			self.allowDownload = ko.observable(!isIOS && !isAndroid);

			// load the theme css
			ko.computed(function () {
				SitesSDK.getSiteProperty('themeDesign', function (data) {
					// check if we got an themeDesign back
					if (data.themeDesign && typeof data.themeDesign === 'string') {
						if (data.themeDesign !== '') {
							// theme is loaded so dynamically inject theme
							SitesSDK.Utils.addSiteThemeDesign(data.themeDesign);
						}
					}
				});
			});


			// fetch custom settings data and initialize
			self.init = function (customData) {
				self.config = {
					folderGuid: customData.hasOwnProperty('folderGuid') ? customData.folderGuid.replace('folder/', '') : defaultFolder,
					publiclink: customData.hasOwnProperty('publiclink') ? customData.publiclink : '',
					folderAccess: customData.hasOwnProperty('folderAccess') ? customData.folderAccess : 'downloader',
					showConvoPane: customData.hasOwnProperty('showConvoPane') ? customData.showConvoPane : true,
					sortBy: customData.hasOwnProperty('sortBy') ? customData.sortBy : '',
					desc: customData.hasOwnProperty('desc') ? customData.desc : true,
					lastUpdated: customData.hasOwnProperty('lastUpdated') ? customData.lastUpdated : false,
					fsize: customData.hasOwnProperty('fsize') ? customData.fsize : false,
					fimg: customData.hasOwnProperty('fimg') ? customData.fimg : false,
					download: customData.hasOwnProperty('download') ? customData.download : true,
					separator: customData.hasOwnProperty('separator') ? customData.separator : true,
					pfname: customData.hasOwnProperty('pfname') ? customData.pfname : true,
					fautowiring: customData.hasOwnProperty('fautowiring') ? customData.fautowiring : true,
					fstrigger: customData.hasOwnProperty('fstrigger') ? customData.fstrigger : false,
					shownum: customData.hasOwnProperty('shownum') ? customData.shownum : '50',
					showNumOption: customData.hasOwnProperty('showNumOption') ? customData.showNumOption : 'all'
				};

				self.noFolderSelected(false);

				self.folderAccess = self.hybridLinkID !== '' && self.hybridFolderID !== '' ? self.config.folderAccess : 'member';
				self.showConvoPane = self.folderAccess !== 'member' ? false : self.config.showConvoPane;

				// initialize the component
				self.fetchData();

				self.showPfname(self.config.pfname);

				//listen to the following value changes to adjust render height
				ko.computed(function () {
					var showPfname = self.showPfname(),
						folderName = self.folderName(),
						hasVisualData = self.hasVisualData();

					if (self.noFolderSelected()) {
						//When no folder selected, adjust height to not show the application in preview or just the watermark in edit
						SitesSDK.setProperty('height');
					} else {
						//In other cases, we only reset height when init function is finished and there's any settings changed afterwards.
						if (self.setHeight) {
							SitesSDK.setProperty('height');
						}
					}

				});

				self.setHeight = true;
			};

			// get the  hybridlink data and customSettings Data, then init the viewModel
			SitesSDK.getProperty('componentAssets', function (assets) {

				//alert("assets length==" + assets.length);
				//get hybrid link id and folder id
				if (assets.length > 0) {
					var source = assets[0].source,
						linkId,
						folderId;
					linkId = source.indexOf('/link/') > 0 ? source.substring(source.indexOf('/link/') + 6) : '';
					folderId = source.indexOf('/folder/') > 0 ? source.substring(source.indexOf('/folder/') + 8) : '';
					if (linkId.indexOf('/') > 0) {
						linkId = linkId.substring(0, linkId.indexOf('/'));
					}
					if (folderId.indexOf('/') > 0) {
						folderId = folderId.substring(0, folderId.indexOf('/'));
					}
					self.hybridLinkID = linkId;
					self.hybridFolderID = folderId;
				}
				SitesSDK.getProperty('customSettingsData', self.init);
			});

			// console.log('ua=' + uaLC + 'isIOS=' + isIOS + ' isAndroid=' + isAndroid);

			//
			// Sites SDK Triggers and Actions listeners
			//
			//-----------------------------------------------
			// Define the event listeners
			//-----------------------------------------------

			// Handle Copy Style (save customSettingsData to the clipboard)
			copyAppCustomDataListener = function (args) {
				// Pack up the items we want to copy to the clipboard during Copy Style
				var data = {
					sortBy: self.config.sortBy,
					desc: self.config.desc,
					lastUpdated: self.config.lastUpdated,
					fsize: self.config.fsize,
					fimg: self.config.fimg,
					download: self.config.download,
					separator: self.config.separator,
					pfname: self.config.pfname,
					shownum: self.config.shownum,
					fautowiring: self.config.fautowiring,
					fstrigger: self.config.fstrigger,
					showNumOption: self.config.showNumOption
				};

				return data;
			};

			// Handle Paste Style (apply customSettingsData from the clipboard)
			pasteAppCustomDataListener = function (args) {
				// Unpack the items we are interested in during Paste Style
				var data = args.detail.message.data,
					saveconfig = {
						sortBy: data.sortBy,
						desc: data.desc,
						lastUpdated: data.lastUpdated,
						fsize: data.fsize,
						fimg: data.fimg,
						download: data.download,
						separator: data.separator,
						pfname: data.pfname,
						fautowiring: data.fautowiring,
						fstrigger: data.fstrigger,
						shownum: data.shownum,
						showNumOption: data.showNumOption
					};

				// TODO: apply the new config to 'self'
			};

			// TRIGGERS meta-data listener
			getAppTriggersListener = function (args) {
				var triggers = [
					{
						'triggerName': 'scsFileViewerFileSelectedTrigger',
						'triggerDescription': strings.APP_FILELIST_TRIGGER_FILE_SELECTED,
						'triggerPayload': [
							{
								'name': 'payload',
								'displayName': strings.APP_FILELIST_TRIGGER_FILE_OBJECT
							},
							{
								'name': 'id',
								'displayName': strings.APP_FILELIST_TRIGGER_FILE_ID
							},
							{
								'name': 'link',
								'displayName': strings.APP_FILELIST_TRIGGER_FILE_LINK
							},
							{
								'name': 'previewlink',
								'displayName': strings.APP_FILELIST_TRIGGER_FILE_PREVIEW_LINK
							},
							{
								'name': 'name',
								'displayName': strings.APP_FILELIST_TRIGGER_FILE_NAME
							},
							{
								'name': 'title',
								'displayName': strings.APP_FILELIST_TRIGGER_TITLE
							},
							{
								'name': 'description',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_DESCRIPTION
							},
							{
								'name': 'mimeType',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_MIME_TYPE
							},
							{
								'name': 'size',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_SIZE
							},
							{
								'name': 'author',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_AUTHOR
							},
							{
								'name': 'createdTime',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_CREATED_TIME
							},
							{
								'name': 'modifiedTime',
								'displayName': strings.APP_FOLDERFILE_TRIGGER_MODIFIED_TIME
							}
						]
					}];
				return triggers;
			};

			// ACTIONS meta-data listener
			getAppActionsListener = function (args) {
				var actions = [
					{
						'actionName': 'scsFolderViewerViewFolderDetails',
						'actionDescription': strings.APP_FILELIST_ACTION_DISPLAY_FILES,
						'actionPayload': [{
							'name': 'folderId',
							'description': strings.APP_FILELIST_ACTION_DISPLAY_FOLDERID_OR_URL,
							'type': {
								'ojComponent': {
									'component': 'ojInputText'
								}
							},
							'value': ''
						}]
					}];
				return actions;
			};

			// Execute Action listener
			executeActionListener = function (args) {
				var payload = args.detail.message.payload,
					action = args.detail.message.action,
					actionName = action && action.actionName,
					triggerName = action && action.triggerName,
					payloadValue,
					folderId = '',
					folderLink = '',
					useLink,
					linkId = '',
					i;

				if (self.config.fautowiring === false && actionName === 'scsViewFolder') {
					// no auto wiring
					return;
				}

				//console.log('file-list: action=' + actionName + ' trigger=' + triggerName + ' payload=' + JSON.stringify(payload));
				if ((actionName === 'scsFolderViewerViewFolderDetails' || (actionName === 'scsViewFolder')) && payload) {

					// handle array based payload
					payloadValue = $.isArray(payload) ? (payload[0].value || {}) : payload;

					if (typeof payloadValue === 'string') {
						// payloadValue contains the folder id or URL.
						if (payloadValue.indexOf('/folder/') > 0) {
							folderLink = payloadValue;
							// payloadValue is an URL. Extract the Folder Id.
							payloadValue = payloadValue.substr(payloadValue.indexOf('/folder/') + 8);
							if (payloadValue.indexOf('/') > 0) {
								payloadValue = payloadValue.slice(0, payloadValue.indexOf('/'));
							}
						}
						folderId = payloadValue;
					} else {
						// payload is an folder object
						folderId = payloadValue.id;
						folderLink = payloadValue.link;
						if (payload.showConvoPane !== undefined) {
							self.showConvoPane = payload.showConvoPane;
						}
					}

					useLink = (folderLink !== '' && folderLink.indexOf('/link/') > 0);
					if (useLink) {
						linkId = folderLink.substring(folderLink.indexOf('/link/') + 6);
						if (linkId.indexOf('/') > 0) {
							linkId = linkId.substring(0, linkId.indexOf('/'));
						}
					}


					// Server - update the folderGuid and refresh
					self.config.folderGuid = folderId;
					self.config.publiclink = useLink ? folderLink : '';
					if (linkId) {
						self.hybridLinkID = linkId;
						self.hybridFolderID = folderId;
					} else {
						self.hybridLinkID = '';
						self.hybridFolderID = '';
					}

					self.refresh();
				}
			};

			// listen for COPY_CUSTOM_DATA request
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.COPY_CUSTOM_DATA, copyAppCustomDataListener);

			// listen for PASTE_CUSTOM_DATA request
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.PASTE_CUSTOM_DATA, pasteAppCustomDataListener);

			// listen for TRIGGERS meta-data request and send trigger metadata to host-site
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_TRIGGERS, getAppTriggersListener);

			// listen for ACTIONS meta-data request and send actions metadata to host-site
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.GET_ACTIONS, getAppActionsListener);

			// listen for the EXECUTE ACTION request to handle custom actions
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(executeActionListener, self));

			//listen for settings update
			SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.handleUpdatedSettings, self));
		};

	// Folder Selected Trigger
	MyViewModel.prototype.raiseFileSelectedTrigger = function (triggerPayload) {
		// Raise the file selected trigger and don't specify any actions
		// This is used to execute any Actions registered against this trigger in the page
		SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
			'triggerName': 'scsFileViewerFileSelectedTrigger', // use first registered trigger name
			'triggerPayload': triggerPayload
		});
	};

	MyViewModel.prototype.refresh = function () {

		var self = this,
			server,
			linkId,
			folderId,
			orderbyCol = 'fItemName',
			orderby = 'Asc',
			docWebUri,
			seededData = [],
			results,
			i,
			idx,
			ymd,
			dateStr,
			sortAsc = true,
			sortCol = 'name',
			limit,
			total,
			uri;

		self.allowDownload(!isIOS && !isAndroid);

		//
		// hybrid link case
		//
		if (self.folderAccess !== 'member' && self.hybridLinkID !== '' && self.hybridFolderID !== '') {

			//console.log('refresh: hybrid link access');

			linkId = self.hybridLinkID;
			folderId = self.hybridFolderID;

			if (self.config.sortBy === 'namedesc') {
				orderby = 'Desc';
			} else if (self.config.sortBy === 'lastupdateasc') {
				orderbyCol = 'fLastModifiedDate';
			} else if (self.config.sortBy === 'lastupdatedesc') {
				orderbyCol = 'fLastModifiedDate';
				orderby = 'Desc';
			}

			docWebUri = '/documents/link/web' +
				'?dLinkID=' + linkId +
				'&item=fFolderGUID:' + folderId +
				'&IdcService=' + 'FLD_BROWSE' +
				'&doCombinedBrowse=1' +
				'&combinedCount=' + '999' +
				'&combinedStartRow=0' +
				'&combinedSortField=' + orderbyCol +
				'&combinedSortOrder=' + orderby;


			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docWebUri,
				'success': function (data) {
					self.parseWebData('', linkId, folderId, data);
					self.hasVisualData(self.queryResult().length > 0);
					self.hasVisualData.valueHasMutated();
				},
				'error': function (xhr, status, err) {
					// alert("Error");
					self.hasVisualData(false);
					self.hasVisualData.valueHasMutated();
				}
			});


			//alert("using hybrid link");

			return;
		}

		//
		// public link case
		//
		if (self.config.publiclink !== '') {
			server = self.config.publiclink.indexOf('/documents/') > 0 ? self.config.publiclink.substring(0, self.config.publiclink.indexOf('/documents/')) : '';
			linkId = self.config.publiclink.indexOf('/link/') > 0 ? self.config.publiclink.substring(self.config.publiclink.indexOf('/link/') + 6) : '';
			folderId = self.config.publiclink.indexOf('/folder/') > 0 ? self.config.publiclink.substring(self.config.publiclink.indexOf('/folder/') + 8) : '';
			if (linkId.indexOf('/') > 0) {
				linkId = linkId.substring(0, linkId.indexOf('/'));
			}
			if (folderId.indexOf('/') > 0) {
				folderId = folderId.substring(0, folderId.indexOf('/'));
			}
			if (server === '') {
				server = 'https://documents.us.oracle.com';
			}

			if (self.config.sortBy === 'namedesc') {
				orderby = 'Desc';
			} else if (self.config.sortBy === 'lastupdateasc') {
				orderbyCol = 'fLastModifiedDate';
			} else if (self.config.sortBy === 'lastupdatedesc') {
				orderbyCol = 'fLastModifiedDate';
				orderby = 'Desc';
			}

			docWebUri = '/documents/link/web' +
				'?dLinkID=' + linkId +
				'&item=fFolderGUID:' + folderId +
				'&IdcService=' + 'FLD_BROWSE' +
				'&doCombinedBrowse=1' +
				'&combinedCount=' + '999' +
				'&combinedStartRow=0' +
				'&combinedSortField=' + orderbyCol +
				'&combinedSortOrder=' + orderby;


			$.ajax({
				'type': 'GET',
				'dataType': 'json',
				'url': docWebUri,
				'success': function (data) {
					self.parseWebData(server, linkId, folderId, data);
					self.hasVisualData(self.queryResult().length > 0);
					self.hasVisualData.valueHasMutated();
				},
				'error': function (xhr, status, err) {
					// alert("Error");
					self.hasVisualData(false);
					self.hasVisualData.valueHasMutated();
				}
			});


			return;
		}


		// console.log('file-list refresh: folder member case');
		//
		// server data case
		//
		if (self.config.folderGuid === '') {
			self.noFolderSelected(true);
			self.noFolderSelected.valueHasMutated();
			self.hasVisualData(false);
			self.hasVisualData.valueHasMutated();
			return;
		}

		folderId = self.config.folderGuid;

		// Sorting option
		if (self.config.sortBy === 'namedesc') {
			orderby = 'Desc';
		} else if (self.config.sortBy === 'lastupdateasc') {
			orderbyCol = 'fLastModifiedDate';
		} else if (self.config.sortBy === 'lastupdatedesc') {
			orderbyCol = 'fLastModifiedDate';
			orderby = 'Desc';
		}
		
		uri = idcFolderItemsUri.replace('[folder]', self.config.folderGuid);
		uri = uri.replace('[sortfield]', orderbyCol);
		uri = uri.replace('[sortorder]', orderby);

		// the query result includes both folders and files, we use a big limit to query and filter later
		$.ajax({
			'type': 'GET',
			'dataType': 'json',
			'url': uri,
			'success': function (data) {
				self.parseWebData('', '', folderId, data);
				self.hasVisualData(self.queryResult().length > 0);
				self.hasVisualData.valueHasMutated();
			},
			'error': function (xhr, status, err) {
				// alert('status=' + status + ' err=' + err);
				// TODO show proper message
				self.hasVisualData(false);
				self.hasVisualData.valueHasMutated();
			}
		});

	};

	MyViewModel.prototype.getFolder = function () {

		var self = this,
			i;

		if (self.config.publiclink !== '') {
			// the folder name will be set in refresh()
			return;
		}

		// the folder name will be set in refresh()
	};

	MyViewModel.prototype.parseWebData = function (server, linkId, folderId, webData) {
		var self = this,
			i,
			idx,
			dRoleName,
			fFileGUIDIdx,
			fFileNameIdx,
			fFileDescriptionIdx,
			dFileSizeIdx,
			fLastModifierFullNameIdx,
			fCreateDateIdx,
			fLastModifiedDateIdx,
			dFormatIdx,
			fields,
			total = 0,
			updatedArray = [],
			results,
			ymd,
			dateStr,
			titleStr,
			link,
			thumbnailLink,
			previewLink,
			fullUrl;

		if (!devcsServer && !webData.ResultSets.FolderInfo) {
			// REST failed
			// check webData.StatusCode and webData.StatusMessage
			return;
		}

		//When it's hybrid link case, add this check to always make sure the return data 
		//folder id is the same as current hybridFolderID. This is because
		//when settings get updated and the render get triggered refresh mutiple times
		//and call init mutiple times,it seems sometimes there's a delay the earlier FLD_BROWSE
		//that with the old hybridlink data from self.refresh returns in the end and causing
		//the render to render old folder selection data.
		if (self.hybridFolderID !== '' && folderId !== self.hybridFolderID) {
			return;
		}

		// get the folder name
		if (!devcsServer) {
			for (i = 0; i < webData.ResultSets.FolderInfo.fields.length; i++) {
				if (webData.ResultSets.FolderInfo.fields[i].name === 'fFolderName') {
					self.folderName(webData.ResultSets.FolderInfo.rows[webData.ResultSets.FolderInfo.currentRow][i]);
					break;
				}
			}
		} else {
			self.folderName('Home');
		}

		// get the link permission
		dRoleName = webData.LocalData.dRoleName;
		if (linkId !== '' && self.allowDownload()) {
			self.allowDownload(dRoleName === 'downloader');
		}

		// get the file list
		fields = webData.ResultSets.ChildFiles.fields;
		for (i = 0; i < fields.length; i++) {
			if (fields[i].name === 'fFileGUID') {
				fFileGUIDIdx = i;
			} else if (fields[i].name === 'fFileName') {
				fFileNameIdx = i;
			} else if (fields[i].name === 'fFileDescription') {
				fFileDescriptionIdx = i;
			} else if (fields[i].name === 'dFileSize') {
				dFileSizeIdx = i;
			} else if (fields[i].name === 'fLastModifierFullName') {
				fLastModifierFullNameIdx = i;
			} else if (fields[i].name === 'fCreateDate') {
				fCreateDateIdx = i;
			} else if (fields[i].name === 'fLastModifiedDate') {
				fLastModifiedDateIdx = i;
			} else if (fields[i].name === 'dFormat') {
				dFormatIdx = i;
			}
		}

		results = webData.ResultSets.ChildFiles.rows;

		fullUrl = location.protocol + '//' + docsHost;

		for (idx = 0; idx < results.length; idx++) {
			ymd = results[idx][fLastModifiedDateIdx].substr(0, 10).split('-');
			dateStr = ymd[1] + '/' + ymd[2] + '/' + ymd[0];
			titleStr = results[idx][fFileNameIdx];
			link = '';
			thumbnailLink = '';
			previewLink = '';
			if (linkId !== '') {
				link = fullUrl + '/documents/link/' + linkId + '/file/' + results[idx][fFileGUIDIdx];
				thumbnailLink = fullUrl + '/documents/link/web?dLinkID=' + linkId + '&IdcService=GET_THUMBNAIL&item=fFileGUID:' + results[idx][fFileGUIDIdx];
				previewLink = fullUrl + '/documents/link/' + linkId + '/fileview/' + results[idx][fFileGUIDIdx];
			} else {
				link = fullUrl + '/documents/file/' + results[idx][fFileGUIDIdx];
				thumbnailLink = fullUrl + '/documents/web?IdcService=GET_THUMBNAIL&item=fFileGUID:' + results[idx][fFileGUIDIdx];
				previewLink = fullUrl + '/documents/fileview/' + results[idx][fFileGUIDIdx];
			}
			updatedArray.push({
				'id': results[idx][fFileGUIDIdx],
				'name': results[idx][fFileNameIdx],
				'title': titleStr.substring(0, titleStr.lastIndexOf('.')),
				'description': results[idx][fFileDescriptionIdx],
				'mimeType': results[idx][dFormatIdx],
				'size': results[idx][dFileSizeIdx],
				'author': results[idx][fLastModifierFullNameIdx],
				'showConvoPane': self.showConvoPane,
				'createdTime': results[idx][fCreateDateIdx],
				'modifiedTime': results[idx][fLastModifiedDateIdx],
				'link': link,
				'previewlink': previewLink,
				'thumbnailUrl': thumbnailLink,
				'lastModifiedMsg': appUtils.applyParameters(strings.APP_FOLDERFILE_LAST_MODIFIED, {
					'0': dateStr,
					'1': results[idx][fLastModifierFullNameIdx]
				}),
				'sizeMsg': Math.round(results[idx][dFileSizeIdx] / 1000) + 'KB',
				'payload': {
					'id': results[idx][fFileGUIDIdx],
					'name': results[idx][fFileNameIdx],
					'title': titleStr.substring(0, titleStr.lastIndexOf('.')),
					'description': results[idx][fFileDescriptionIdx],
					'link': link,
					'showConvoPane': self.showConvoPane
				}
			});
			total = total + 1;
			if (self.config.showNumOption !== 'all' && total === self.config.shownum) {
				break;
			}
		}

		self.queryResult(updatedArray);
	};

	MyViewModel.prototype.compare = function (a, b, isSortAsc) {
		if (a === b) {
			return 0;
		} else if (isSortAsc === true) {
			return a < b ? -1 : 1;
		} else {
			return a < b ? 1 : -1;
		}
	};

	MyViewModel.prototype.sortFunction = function (sortColumn, isSortAsc) {
		var self = this;

		self.queryResult.sort(function (a, b) {
			return self.compare(a[sortColumn], b[sortColumn], isSortAsc);
		});
	};


	MyViewModel.prototype.refreshClickHandler = function (event) {
		var self = this;

		self.refresh();
	};

	MyViewModel.prototype.getHeight = function () {
		/*
		var body = document.body,
			html = document.documentElement;
		var height = Math.max(body.scrollHeight, body.offsetHeight,
			html.clientHeight, html.scrollHeight, html.offsetHeight);
		*/
		var height = $(document).height();
		return height;
	};

	MyViewModel.prototype.afterRender = function (elements) {
		//var height = templateViewModel.getHeight();
		//SitesSDK.setProperty('height', height);
	};

	MyViewModel.prototype.fetchData = function () {
		var self = this;
		if (self.config.pfname === true) {
			self.getFolder();
		}
		self.refresh();
	};

	//-----------------------------------------------
	// Get render Sites SDK parameters, e.g, viewMode
	//-----------------------------------------------
	MyViewModel.prototype.getQueryParameters = function (url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	};

	//-----------------------------------------------
	// Binding handler to deal with changes to number of items
	//-----------------------------------------------
	ko.bindingHandlers.scsFileListafterListUpdate = {
		update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
			// add a dependency to items so get called when they change
			var items = ko.utils.unwrapObservable(valueAccessor());
			SitesSDK.setProperty('height');
		}
	};

	// handle changedSettings event from settings panel
	MyViewModel.prototype.handleUpdatedSettings = function (event) {

		//get the event payload
		var self = this,
			payload;
		if (typeof event.detail.message === 'object') {
			payload = event.detail.message;
		} else if (typeof event.detail.message === 'string') {
			try {
				payload = JSON.parse(event.detail.message);
			} catch (err) {
				payload = {};
			}
		} else {
			payload = {};
		}
		console.log('handleUpdatedSettings: payload=' + JSON.stringify(payload));
		if (payload.property) {
			if (payload.property === 'customSettingsData') {
				//apply update
				SitesSDK.getProperty('componentAssets', function (assets) {
					if (assets.length > 0) {
						var source = assets[0].source,
							linkId,
							folderId;
						linkId = source.indexOf('/link/') > 0 ? source.substring(source.indexOf('/link/') + 6) : '';
						folderId = source.indexOf('/folder/') > 0 ? source.substring(source.indexOf('/folder/') + 8) : '';
						if (linkId.indexOf('/') > 0) {
							linkId = linkId.substring(0, linkId.indexOf('/'));
						}
						if (folderId.indexOf('/') > 0) {
							folderId = folderId.substring(0, folderId.indexOf('/'));
						}
						self.hybridLinkID = linkId;
						self.hybridFolderID = folderId;
					}

					self.init(payload.value);
				});
			}
		}

	};


	//-----------------------------------------------
	// Create the view model and initialize knockout
	//-----------------------------------------------
	templateViewModel = new MyViewModel();

	// Return the module
	return {
		'templateViewModel': templateViewModel,
		'afterRender': templateViewModel.afterRender
	};
});
