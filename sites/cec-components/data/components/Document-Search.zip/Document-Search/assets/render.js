/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define,console*/
define(['require', 'knockout', 'jquery', 'css!./styles/design.css', 'text!./comptemplate.html'], function (require, ko, $, css, comptemplate) {
	'use strict';

	var doSearch = function (proxyEndpoint, queryString) {
		var searchPromise = new Promise(function (resolve, reject) {
			var url = '/pxysvc/proxy/' + proxyEndpoint + '?fulltext=' + queryString;
			$.ajax({
				type: 'GET',
				dataType: 'json',
				url: url,
				success: function (data) {
					resolve(data);
				},
				error: function (xhr, status, err) {
					console.log(' - request failed: url:' + url + ' status: ' + status + ' error: ' + err);
					resolve({
						err: 'err'
					});
				}
			});
		});
		return searchPromise;
	};
	var replaceAll = function (str, search, replacement) {
		var re = new RegExp(search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
		return str.replace(re, replacement || '');
	};

	var getDocTitle = function (filename) {
		var title = filename;
		if (title.indexOf('.') > 0) {
			title = title.substring(0, title.lastIndexOf('.'));
		}
		title = replaceAll(title, '.', ' ');
		title = replaceAll(title, '-', ' ');
		title = replaceAll(title, '_', ' ');
		return title;
	};
	var getFileExtension = function (filename) {
		var ext = '';
		if (filename.indexOf('.') > 0) {
			ext = filename.substring(filename.lastIndexOf('.') + 1);
		}
		return ext;
	};

	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var DocumentSearchViewNodel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK;

		// store the args
		self.mode = args.viewMode;
		self.id = args.id;

		// create the observables
		self.initialized = ko.observable(false);
		self.folderLinkId = ko.observable();
		self.docSearchProxy = ko.observable();
		self.files = ko.observableArray([]);

		// Get the search from the url if it exists
		self.queryString = '';

		var params = (new URL(document.location)).searchParams;
		var defaultStr = params && params.get('default');
		if (defaultStr) {
			if (defaultStr.lastIndexOf('*') === defaultStr.length - 1) {
				defaultStr = defaultStr.substring(0, defaultStr.length - 1);
			}
			// Display the search string in the search field
			self.queryString = defaultStr;
		}

		// click binding
		self.documentClicked = function (data, event) {
			console.log('document clicked: ' + (data ? data.url : ''));
			self.raiseTrigger("documentClicked", data.url); // matches appinfo.json
		};

		//
		// Raise the given trigger.
		//
		self.raiseTrigger = function (triggerName, fileUrl) {
			SitesSDK.publish(SitesSDK.MESSAGE_TYPES.TRIGGER_ACTIONS, {
				'triggerName': triggerName,
				'triggerPayload': {
					'fileURL': fileUrl
				}
			});
		};


		// execute action handler
		self.executeActionsListener = function (args) {
			// get action and payload
			var payload = args.payload,
				action = args.action;
		};

		// 
		// Handle property changes
		//
		self.updateCustomSettingsData = $.proxy(function (customData) {}, self);
		self.updateCustomSettingsData = $.proxy(function (customData) {
			var folderLinkId = customData && customData.folderLinkId || '';
			var docSearchProxy = customData && customData.docSearchProxy || '';
			console.log('DocumentSearch: folder link ID: ' + folderLinkId + ' proxy: ' + docSearchProxy);
			self.folderLinkId(folderLinkId);
			self.docSearchProxy(docSearchProxy);
			if (self.queryString && folderLinkId && docSearchProxy) {
				// Search
				var searchPromise = doSearch(docSearchProxy, self.queryString);
				var files = [];
				searchPromise.then(function (result) {
					if (result && result.items && result.items.length > 0) {
						for(var i = 0; i < result.items.length; i++) {
							var item = result.items[i];
							var url = '';
							if (item.type === 'file') {
								url = '/documents/link/' + folderLinkId + '/file/' + item.id;
								var title = getDocTitle(item.name);
								var ext = getFileExtension(item.name);
								var icon = 'document.png';
								if (ext) {
									if (ext.toLowerCase() === 'pdf') {
										icon = 'pdf.png';
									} else if (ext.toLowerCase() === 'docx' || ext.toLowerCase() === 'doc') {
										icon = 'doc.png';
									} else if (ext.toLowerCase() === 'pptx' || ext.toLowerCase() === 'ppt') {
										icon = 'ppt.png';
									} else if (ext.toLowerCase() === 'xlsx' || ext.toLowerCase() === 'xls') {
										icon = 'xls.png';
									} else if (ext.toLowerCase() === 'txt') {
										icon = 'txt.png';
									}
								}
								console.log('name=' + item.name + ' ext=' + ext + ' title=' + title);
								var assetURL = require.toUrl('.');
								files.push({
									id: item.id,
									name: item.name,
									title: title,
									icon: assetURL + '/images/' + icon,
									url: url,
									metadata: item.name
								});
							}
						}
					}
					self.files(files);
					self.initialized(true);
				});
			} else {
				self.initialized(true);
			}
		}, self);

		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};

		// listen for the EXECUTE ACTION request to handle custom actions
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.EXECUTE_ACTION, $.proxy(self.executeActionsListener, self));
		// listen for settings update
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, $.proxy(self.updateSettings, self));

		//
		// Initialize customSettingsData values
		//
		SitesSDK.getProperty('customSettingsData', self.updateCustomSettingsData);
	};


	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var DocumentSearchImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	DocumentSearchImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	DocumentSearchImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new DocumentSearchViewNodel(args);
	};
	// create the template based on the initial values
	DocumentSearchImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			comptemplate +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	DocumentSearchImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);

		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var DocumentSearchFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new DocumentSearchImpl(args));
		}
	};
	return DocumentSearchFactory;
});