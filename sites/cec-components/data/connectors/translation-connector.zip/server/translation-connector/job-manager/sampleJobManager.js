/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */
var translationProvider = require('../provider/translationProvider').factory.create(),
    persistenceStore = require('./persistenceStore').factory.create(),
    fileImporter = require('./sampleFileImporter'),
    fileTranslator = require('./sampleFileTranslator'),
    fileDownloader = require('./sampleFileDownloader');


/**
 * Manage the translation of a job within the translation connector. <br/>
 * Once the job has been created and the zip file imported, the job-manager takes over the actual translation of the zip file. <br/>
 * The steps invovled are: <br/>
 * <ul>
 * <li>Import all files into the LSP:  status updated to "TRANSLATING" (% complete set at 0%)</li>
 * <li>Request files are translated into the target languages</li>
 * <li>Poll until complete: status updated to "DOWNLOADING" (% complete updated also added during polling - stops at 99%)</li>
 * <li>Download files: status updated to "TRANSLATED"  (% complete updated to 100%)</li>
 * <li>If any steps error: status is updated to "FAILED"</li>
 * </ul>
 * @constructor
 * @alias SampleJobManager
 */
var SampleJobManager = function () {
    // on startup - run through and re-enable all non-TRANSLATED jobs
    this.restartJobs();
};

/**
 * Restart any jobs that were previously running. <br/>
 * This function gets called when the translation connector starts up. Any jobs that were previously running and in a state to re-start are kicked off again. <br/>
 * This is a background tasks and the jobs will run until the status is updated to "TRANSLATED" or "FAILED"
 */
SampleJobManager.prototype.restartJobs = function () {
    var self = this;

    // get all the the existing jobs
    persistenceStore.getAllJobs().then(function (allJobConfigs) {
        // get all the jobs that need to be re-started
        allJobConfigs.filter(function (jobConfig) {
            // If the job is not finished (i.e.: TRANSLATED), we need to re-start it
            // If the job has 'FAILED' then we don't restart it, they need to re-submit the job and start again
            // In order to restart, the status must be at least "IMPORTING" (i.e.: not "CREATED") so we have the zip file to work from
            return ['TRANSLATED', 'FAILED', 'CREATED'].indexOf(jobConfig.status) === -1;
        }).map(function (jobConfig) {
            // ok, we have a running job that we need to re-start, kick it off again
            console.log('restarting...:' + jobConfig.properties.id + ' from: ' + jobConfig.status);
            self.translateJob(jobConfig);
        });
    });
};

/**
 * @typedef {Object} JobConfig
 * @memberof SampleJobManager
 * @property {string} name Name of the connector job. 
 * @property {string} workflowId Identifier of the Langauge Service Provider worklow to use to translate this job
 * @property {string} authToken Bearer token to use to connect to the Language Service Provider.  Since the job-manager works in the background and restarts jobs, it needs access to this token. 
 * @property {('CREATED'|'IMPORTING'|'TRANSLATING'|'DOWNLOADING'|'TRANSLATED')} status The status of the job.
 * @property {string} statusMessage Any message included with the status update. 
 * @property {number} progress Percentage progress through the transation of the job.
 * @property {object} properties Language Service Provider properties.
 * @property {string} properties.id Identifier of the job in the connector.
 * @property {string} properties.projectId Identifier of the project in the Langauge Service Provider.
 * @property {string} translatedZipFile Name of the zip file containing all the translations for the job.
 */

/**
 * @typedef {Object} file
 * @memberof SampleJobManager
 * @property {string} name The name of the resource to translate from the job.json file.
 * @property {string} id The reference identifier for this resource in the job.json file.
 * @property {string} path The name of the file on the file system.
 */

/**
 * @typedef {Object} JobDetails
 * @memberof SampleJobManager
 * @property {object} assets Assets resources to translate
 * @property {object} assets.jobJSON The job.json object for assets.
 * @property {SampleJobManager.file[]} assets.files The array of files that need to be translated
 * @property {object} site Site resources to translate
 * @property {object} site.jobJSON The job.json object for site resources.
 * @property {SampleJobManager.file[]} site.files The array of files that need to be translated
 * @property {string} sourceLanguage The source langauge for the job. 
 * @property {String[]} targetLanguages Array of target languages the resources will be tranlated into.
 */


/**
 * Translate a job whose zip file has been imported into the persistence store. <br/>
 * This first checks the current state of the job and executes any further steps required. 
 * <ul>
 * <li>Import all files into the LSP:  status updated to "TRANSLATING" (% complete set at 0%)</li>
 * <li>Request files are translated into the target languages</li>
 * <li>Poll until complete: status updated to "DOWNLOADING" (% complete updated also added during polling - stops at 99%)</li>
 * <li>Download files: status updated to "TRANSLATED"  (% complete updated to 100%)</li>
 * <li>If any steps error: status is updated to "FAILED"</li>
 * </ul>
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 */
SampleJobManager.prototype.translateJob = function (jobConfig) {
    var self = this;

    // get the job details
    self.getJobDetails(jobConfig).then(function (jobDetails) {
        var jobSteps = [];

        // allow re-starting of a job.  
        // Only execute steps not already executed based on the job status
        switch (['CREATED', 'IMPORTING', 'TRANSLATING', 'DOWNLOADING', 'TRANSLATED'].indexOf(jobConfig.status)) {
            case 0: // CREATED
                console.log('sampleJobManager.translatJob(): unable to start job - ' + jobConfig.name + ' zip file not available');
                return;
            case 1: // IMPORTING
                // import all the files into LSP server
                jobSteps.push(function () {
                    return fileImporter.importFiles(jobConfig, jobDetails);
                });
                // update status to TRANSLATING
                jobSteps.push(function () {
                    return self.updateStatus(jobConfig, "TRANSLATING");
                });
            case 2: // TRANSLATING
                // tell the LSP provider to translate the files into the requested locales
                jobSteps.push(function () {
                    return fileTranslator.translateFiles(jobConfig, jobDetails);
                });
                // wait until the LSP provider project is 100% complete
                jobSteps.push(function () {
                    return self.pollStatus(jobConfig, jobDetails);
                });
                // update status to DOWNLOADING
                jobSteps.push(function () {
                    return self.updateStatus(jobConfig, "DOWNLOADING");
                });
            case 3: // DOWNLOADING
                // download the translated files
                jobSteps.push(function () {
                    return fileDownloader.downloadFiles(jobConfig, jobDetails);
                });
                // now create the zip for the translated files
                jobSteps.push(function () {
                    return self.createZip(jobConfig, jobDetails);
                });
                // update progress to 100%
                jobSteps.push(function () {
                    return self.updateProgress(jobConfig, "100");
                });
                // update status to TRANSLATED
                jobSteps.push(function () {
                    return self.updateStatus(jobConfig, "TRANSLATED");
                });
            case 4: // TRANSLATED
                // already translated, we're done
                break;
            default:
                // unable to restart this job
                console.log('sampleJobManager.translatJob(): unable to restart job - ' + jobConfig.name + ' from status - ' + jobConfig.status);
                return;
        }

        // now run through all the steps identified
        // chain the promises in the array so that they execute as: return p1.then(return p2.then(return p3.then(...)));
        var doTranslateJob = jobSteps.reduce(function (previousPromise, nextPromise) {
                return previousPromise.then(function () {
                    // wait for the previous promise to complete and then return a new promise for the next 
                    return nextPromise();
                });
            },
            // Start with a previousPromise value that is a resolved promise 
            Promise.resolve());

        // once all steps have completed, job is translated
        doTranslateJob.then(function () {
            console.log('sampleJobManager.translatJob(): Completed translation of job - ' + jobConfig.name);
        }).catch(function (e) {
            console.log('SampleJobManager.translateJob(): failed to translate job - ' + jobConfig.name);
            var cyclicEntry = [];
            console.log(JSON.stringify(e, function (key, val) {
                if (val !== null && typeof val === "object") {
                    if (cyclicEntry.indexOf(val) >= 0) {
                        return;
                    }
                    cyclicEntry.push(val);
                }
                return val;
            }));

            // update the job status to 'FAILED' so we don't try and re-do this job, they need to re-submit it
            self.updateStatus(jobConfig, "FAILED");
        });
    }).catch(function (error) {
        console.log('sampleJobManager.translateJob(): failed to get job details for - ' + jobConfig.name);
        return;
    });
};

/**
 * Get the job details from the job.json file included in the source zip file<br/>
 * The folder structure differs between job types - the job types are: <br/>
 * An "ASSETS" job type: 
 * <ul>
 *   <li>job.json</li>
 *   <li>root</li>
 * </ul>
 * Or a "SITE" job type: 
 * <ul>
 *   <li> assets
 *     <ul>
 *       <li>job.json</li>
 *       <li>root</li>
 *     </ul>
 *   </li>
 *   <li> site
 *     <ul>
 *       <li>job.json</li>
 *       <li>root</li>
 *     </ul>
 *   </li>
 * </ul>
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @returns {Promise.<SampleJobManager.JobDetails>} A promise that contains the details of the combined job.json files
 */
SampleJobManager.prototype.getJobDetails = function (jobConfig) {
    return new Promise(function (resolve, reject) {
        var jobId = jobConfig.properties.id;
        persistenceStore.getSourceJobJSON({
            jobId: jobId
        }).then(function (jobFiles) {
            var jobDetails = {
                    type: jobFiles.type
                },
                assetJobJSON,
                siteJobJSON;

            // include the asset files
            if (jobFiles.assetsJSON) {
                try {
                    assetJobJSON = JSON.parse(jobFiles.assetsJSON);
                    jobDetails.assets = {
                        jobJSON: assetJobJSON,
                        files: []
                    };

                    // list all the asset files (including the file name)
                    (assetJobJSON.contentItems || []).forEach(function (contentItem) {
                        jobDetails.assets.files.push({
                            name: contentItem.name,
                            id: contentItem.id,
                            path: contentItem.id + '-' + contentItem.name + '.json'
                        });
                    });
                } catch (e) {
                    console.log('sampleJobManager.getJobDetails(): failed to parse asset job.json file for - ' + jobId);
                    reject(e);
                }
            }

            // include the site files
            if (jobFiles.siteJSON) {
                try {
                    siteJobJSON = JSON.parse(jobFiles.siteJSON);
                    jobDetails.site = {
                        jobJSON: siteJobJSON,
                        files: []
                    };

                    // add in the pages
                    (siteJobJSON.pages || []).forEach(function (pageItem) {
                        jobDetails.site.files.push({
                            name: pageItem.name,
                            id: pageItem.id,
                            path: pageItem.name
                        });
                    });

                    // add in the structure/siteinfo
                    jobDetails.site.files.push({
                        name: 'structure.json',
                        id: 'structure',
                        path: 'structure.json'
                    });
                    jobDetails.site.files.push({
                        name: 'siteinfo.json',
                        id: 'siteinfo',
                        path: 'siteinfo.json'
                    });
                } catch (e) {
                    console.log('sampleJobManager.getJobDetails(): failed to parse asset job.json file for - ' + jobId);
                    reject(e);
                }
            }

            // get the source & target langauges
            jobDetails.sourceLanguage = (assetJobJSON || siteJobJSON).sourceLanguage;
            jobDetails.targetLanguages = (assetJobJSON || siteJobJSON).targetLanguages;

            resolve(jobDetails);
        }).catch(function (error) {
            console.log('sampleJobManager.getJobDetails(): unable to get job.json files for job - ' + jobId);
            reject(error);
        });
    });
};

/**
 * Update the job status in the job metadata.
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @property {('CREATED'|'IMPORTING'|'TRANSLATING'|'DOWNLOADING'|'TRANSLATED')} status The new status of the job.
 * @property {string} statusMessage Any message to include with the status update. 
 * @returns {Promise.<SampleJobManager.JobConfig>} A promise that contains the details of the updated job metadata
 */
SampleJobManager.prototype.updateStatus = function (jobConfig, status, statusMessage) {
    // get the current job metadata
    return persistenceStore.getJob({
        jobId: jobConfig.properties.id
    }).then(function (jobMetadata) {
        // update the status value in the job metadata
        jobMetadata.status = status;
        jobMetadata.statusMessage = statusMessage;
        return persistenceStore.updateJob(jobMetadata);
    });
};

/**
 * Update the job progress in the job metadata.
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @property {number} progress New percentage progress value. 
 * @returns {Promise.<SampleJobManager.JobConfig>} A promise that contains the details of the updated job metadata
 */
SampleJobManager.prototype.updateProgress = function (jobConfig, progress) {
    return persistenceStore.getJob({
        jobId: jobConfig.properties.id
    }).then(function (jobMetadata) {
        // update the progress
        jobMetadata.progress = jobConfig.progress = progress;

        return persistenceStore.updateJob(jobMetadata);
    });
};

/**
 * Background task to poll the Language Service Provider and wait for the job to be 100% complete.
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @param {SampleJobManager.JobDetails} jobDetails - The details of the combined job.json files.
 * @returns {Promise} A promise that resolves when polling gets to 100%.
 */
SampleJobManager.prototype.pollStatus = function (jobConfig, jobDetails) {
    var self = this;

    return new Promise(function (resolve, reject) {

        pollServer = function () {
            // get the current status for the job
            translationProvider.getProjectStatus(jobConfig.authToken, jobConfig.properties.projectId).then(function (projectStatus) {
                // if projectStatus complete...
                if (projectStatus.properties.progress.toString() === "100") {
                    // update status to "DOWNLOADING"
                    self.updateStatus(jobConfig, "DOWNLOADING", "Downloading translated files").then(function () {
                        self.updateProgress(jobConfig, "95").then(function (jobMetadata) {
                            // resolve 
                            resolve();
                        }).catch(function (error) {
                            console.log('sampleJobManager.pollStatus(): failed to update progress for job - ' + jobConfig.properties.id);
                            reject(error);
                        });
                    }).catch(function (error) {
                        console.log('sampleJobManager.pollStatus(): failed to update status for job - ' + jobConfig.properties.id);
                        reject(error);
                    });
                } else {
                    // limit progress to between 5% and 95% for importing files & downloading translations
                    progress = Math.min(5, Math.max(projectStatus.properties.progress, 95));
                    self.updateProgress(jobConfig, progress).then(function (jobMetadata) {
                        // wait and poll again
                        setTimeout(function () {
                            pollServer();
                        }, 5000);
                    });
                }
            }).catch(function (e) {
                // failed to get project status - this may be fatal, would need to confirm project exists
                // update status to "FAILED"
                self.updateStatus(jobConfig, "FAILED", "Failed to get status for project - " + jobConfig.properties.projectId);
                reject();
            });
        };

        // kick off the polling for this job
        pollServer();
    });
};

/**
 * Create a zip file of all the downloaded translations.
 * @param {SampleJobManager.JobConfig} jobConfig - The configuration of the connector job to run. This information is held as metadata in the connector for the job. 
 * @param {SampleJobManager.JobDetails} jobDetails - The details of the combined job.json files.
 * @returns {Promise.<SampleJobManager.JobConfig>} A promise that contains the job metadata updated with the location of the tranlation zip file.
 */
SampleJobManager.prototype.createZip = function (jobConfig, jobDetails) {
    return persistenceStore.createTranslationZip({
        jobId: jobConfig.properties.id
    });
};


// Export the mock translator
module.exports = new SampleJobManager();