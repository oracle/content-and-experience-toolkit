/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals app, module, __dirname */
/* jshint esversion: 6 */
/**
 */

/**
 * Map "/connector/rest/api*" URL requests to the corresponding function in {@link SampleConnector}
 * @constructor
 * @alias SampleConnectorRouter
 */


var express = require('express'),
	connector = require('./sampleConnector.js'),
	router = express.Router();

//
// GET requests
//
router.get('/connector/rest/api', (req, res) => {
	connector.getApiVersions(req, res);
});
router.get('/connector/rest/api/v1/server', (req, res) => {
	connector.getServer(req, res);
});
router.get('/connector/rest/api/v1/job/:id/translation', (req, res) => {
	connector.getTranslation(req, res);
});
router.get('/connector/rest/api/v1/job/:id', (req, res) => {
	connector.getJob(req, res);
});
router.get('/connector/rest/api/v1/job', (req, res) => {
	connector.getJobs(req, res);
});

// handle unsuported GET requests
router.get('/*', (req, res) => {
	console.log('*** Sample Connector GET: ' + req.url);
	res.writeHead(404, "Unsupported API");
	res.end();
});

//
// POST requests
//
router.post('/connector/rest/api/v1/authorization/basicAuthorization', (req, res) => {
	connector.validateBasicAuthorization(req, res);
});
router.post('/connector/rest/api/v1/job', (req, res) => {
	connector.createJob(req, res);
});
router.post('/connector/rest/api/v1/job/:id/translate', (req, res) => {
	connector.translateJob(req, res);
});

// handle unsuported POST requests
router.post('/*', (req, res) => {
	console.log('*** Sample Connector Server POST: ' + req.url);
	res.writeHead(404, "Unsupported API");
	res.end();
});

//
// DELETE requests 
//
router.delete('/connector/rest/api/v1/job/:id', (req, res) => {
	connector.deleteJob(req, res);
});

// Export the router
module.exports = router;