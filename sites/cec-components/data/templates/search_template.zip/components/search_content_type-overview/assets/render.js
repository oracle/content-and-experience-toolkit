/* globals define,console */
define([
	"require",
	"jquery",
	"mustache",
	"text!./layout.html",
	"css!./design.css"
], function (require, $, Mustache, templateHtml, css) {
	"use strict";

	// Content Layout constructor function.
	function ContentLayout(params) {
		this.contentItemData = params.contentItemData || {};
		this.scsData = params.scsData;
		this.contentClient = params.contentClient;
	}

	// Helper function to format a date field by locale.
	function dateToMDY(date) {
		if (!date) {
			return "";
		}

		var dateObj = new Date(date);

		var options = {
			year: "numeric",
			month: "long",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		};
		var formattedDate = dateObj.toLocaleDateString("en-US", options);

		return formattedDate;
	}

	function getQueryParameters(url) {
		var anchorEle = document.createElement('a'),
			//query parameters
			parameters = {},
			queries,
			i,
			split;

		// set the URL in the anchor, which will also parse it
		anchorEle.href = url;
		// anchorEle.search returns ?x=y&a=b... part of the url string
		queries = anchorEle.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i += 1) {
			split = queries[i].split('=');
			parameters[split[0]] = decodeURIComponent(split[1]);
		}

		return parameters;
	}

	function replaceAll(str, search, replacement) {
		var re = new RegExp(search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'ig');
		return str.replace(re, replacement || '');
	}


	// Content Layout definition.
	ContentLayout.prototype = {
		// Specify the versions of the Content REST API that are supported by the this Content Layout.
		// The value for contentVersion follows Semantic Versioning syntax.
		// This allows applications that use the content layout to pass the data through in the expected format.
		contentVersion: ">=1.0.0 <2.0.0",

		// Main rendering function:
		// - Updates the data to handle any required additional requests and support both v1.0 and v1.1 Content REST APIs
		// - Expand the Mustache template with the updated data 
		// - Appends the expanded template HTML to the parentObj DOM element
		render: function (parentObj) {
			var template,
				content = $.extend({}, this.contentItemData),
				contentClient = this.contentClient,
				contentType,
				secureContent = false;

			// If used with CECS Sites, Sites will pass in context information via the scsData property.
			if (this.scsData) {
				content = $.extend(content, {
					"scsData": this.scsData
				});
				contentType = content.scsData.showPublishedContent === true ? "published" : "draft";
				secureContent = content.scsData.secureContent;
			}

			// Support both v1.0 and v1.1 Content REST API response formats.
			// User-defined fields are passed through the 'data' property in v1.0 and 'fields' property in v1.1.
			var data = !contentClient.getInfo().contentVersion || contentClient.getInfo().contentVersion === "v1" ? content.data : content.fields;

			// Massage the data so that the 'fields' property is always there.
			// The corresponding layout.html template only checks for the ‘fields’ property. 
			if (!contentClient.getInfo().contentVersion || contentClient.getInfo().contentVersion === "v1") {
				content["fields"] = content.data;
			}

			//
			// Handle fields specific to this content type.
			//

			var moreItems;
			content.fields.pageFullURL = SCSRenderAPI.getSitePrefix() + content.fields.pageurl;
			var assetURL = require.toUrl('.');
			content.fields.pageicon = assetURL + '/page.png';
			content.fields.matchingString = '';
			var params = getQueryParameters(window.location.href);
			var searchString = params && params.default;
			// console.log('Searching for ' + searchString);
			var keywords = content.fields.keywords;
			if (searchString && keywords && keywords.length > 0) {
				searchString = searchString.toLowerCase();
				searchString = searchString.replace('*', '');
				var pageName = content.fields.pagename;
				// console.log('page: ' + pageName);
				var originalStr = '';
				var matchingStr = '';
				for (var i = 0; i < keywords.length; i++) {
					originalStr = keywords[i];
					var idx = originalStr.toLowerCase().indexOf(searchString);
					if (idx >= 0) {
						matchingStr = originalStr.toLowerCase();
						if (idx > 200) {
							matchingStr = matchingStr.substring(100);
							originalStr = originalStr.substring(100);
							idx = matchingStr.indexOf(searchString);
						}
						var sepIdx;
						// find the beginning 
						sepIdx = matchingStr.lastIndexOf('.', idx) || 
							matchingStr.lastIndexOf(',', idx) || 
							matchingStr.lastIndexOf(' ', idx);
						if (sepIdx >= 0) {
							matchingStr = matchingStr.substring(sepIdx + 1);
							originalStr = originalStr.substring(sepIdx + 1);
						}

						if (matchingStr.length > 300) {
							matchingStr = matchingStr.substring(0, 300);
							originalStr = originalStr.substring(0, 300);
						}
						// find the end
						sepIdx = matchingStr.lastIndexOf('.') || matchingStr.lastIndexOf(',') || matchingStr.lastIndexOf(' ');
						if (sepIdx > 0) {
							matchingStr = matchingStr.substring(0, sepIdx + 1);
							originalStr = originalStr.substring(0, sepIdx + 1);
						}

						break;
					}
				}
				if (matchingStr) {
					matchingStr = replaceAll(originalStr, searchString, '<b>' + searchString + '</b>');
					// console.log(' => ' + matchingStr);
					content.fields.matchingString = matchingStr;
				}
			}

			try {
				// Use Mustache to expand the HTML template with the data.
				template = Mustache.render(templateHtml, content);

				// Insert the expanded template into the passed in container.
				if (template) {
					$(parentObj).append(template);
				}
			} catch (e) {
				console.error(e.stack);
			}
		}
	};

	return ContentLayout;
});