/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* global requirejs, SCSRenderAPI */
(function () {

	'use strict';

	// main entry point into the JET app
	// This sets up the JET require.js configuration and then runs the JET code on the page
	var runApp = function () {

		// Identify the Theme URL for theme assets and the JET CDN version & URL
		var renderAPI = SCSRenderAPI,
			themeURLprefix = renderAPI.getThemeUrlPrefix(),
			JETVersion = 'v6.0.0',
			CDNPrefix = 'https://static.oracle.com/cdn/jet/' + JETVersion;

		// Define the Require.js config entries to:
		// - include access to JS files from the theme
		// - include JET from CDN
		var JETConfig = {
				paths: {
					'context': 'JET' + JETVersion,

					// app specific end points
					'themeAssets': themeURLprefix + '/assets',
					'appController': themeURLprefix + '/assets/js/appController',

					// JET & dependencies
					'ojs': CDNPrefix + '/default/js/debug',
					'ojL10n': CDNPrefix + '/default/js/ojL10n',
					'ojtranslations': CDNPrefix + '/default/js/resources',
					'signals': CDNPrefix + '/3rdparty/js-signals/signals.min',
					'ojdnd': CDNPrefix + '/3rdparty/dnd-polyfill/dnd-polyfill-1.0.0.min',
					'customElements': CDNPrefix + '/3rdparty/webcomponents/custom-elements.min',
					'hammerjs': CDNPrefix + '/3rdparty/hammer/hammer-2.0.8.min',
					'proj4js': CDNPrefix + '/3rdparty/proj4js/dist/proj4',
					'jqueryui-amd': CDNPrefix + '/3rdparty/jquery/jqueryui-amd-1.12.1.min'
				}
			},
			AltaCSS = CDNPrefix + '/default/css/alta/oj-alta-min.css'; // This is the main css file for the default Alta theme

		// create a JET require config context
		var jetRequireCtx = requirejs.config(JETConfig);

		// require in all the dependencies and run the JET code
		var requireModules = ['require',
			'knockout',
			'jquery',
			'appController',
			'ojs/ojcore',
			'text!themeAssets' + '/offCanvasTemplate.html',
			'text!themeAssets' + '/headerTemplate.html',
			'text!themeAssets' + '/footerTemplate.html',
			'ojs/ojknockout',
			'ojs/ojmodule',
			'ojs/ojnavigationlist',
			'ojs/ojbutton',
			'ojs/ojtoolbar',
			'css!' + AltaCSS
		];

		jetRequireCtx(requireModules, function (require, ko, $, app, oj, offCanvasTemplate, headerTemplate, footerTemplate) {
			var init = function () {
				// add in the header and footer templates
				var jetTemplates = [{
						'id': 'oracleJetTemplateOffCanvas',
						'value': offCanvasTemplate
					},
					{
						'id': 'oracleJetTemplateHeader',
						'value': headerTemplate
					},
					{
						'id': 'oracleJetTemplateFooter',
						'value': footerTemplate
					}
				];

				// insert the JET templates
				jetTemplates.forEach(function (template) {
					var $templateDiv = $('#' + template.id);

					if ($templateDiv.length === 1) {
						$templateDiv.append(template.value);
					} else {
						console.log('Unable to find template ID: ' + template.id);
					}
				});



				// NB: "Sites Cloud Service" scs-slots within the page will also want to call Knockout applyBindings() so only
				// apply the knockout bindings to your JET elements in the page layout
				// The corollary of this is that you can't have "Sites Cloud Service" scs-slots within JET DOM container elements
				var jetElementIDs = [
					'demoAppDrawer',
					'oracleJetTemplateHeader',
					'oracleJetTemplateFooter',
					'oracleJetPageHeader'
				];

				// apply bindings to the specific JET elements within the page layout
				jetElementIDs.forEach(function (elementID) {
					var domElement = document.getElementById(elementID);
					if (domElement) {
						ko.applyBindings(app, domElement);
					} else {
						console.log('Unable to apply bindings to element: ' + elementID);
					}
				});

				// Since we're pulling in the Alta CSS dynamically, only fade in the body once it's loaded to avoid FOUC.
				// This can be changed to statically add the CSS to the template and remove this step
				$('body').fadeTo('fast', 100);
			};

			// If running in a hybrid (e.g. Cordova) environment, we need to wait for the deviceready 
			// event before executing any code that might interact with Cordova APIs or plugins.
			if ($(document.body).hasClass('oj-hybrid')) {
				document.addEventListener("deviceready", init);
			} else {
				init();
			}
		});
	};



	// Listen for when the renderer is about to start rendering the page and then run the JET app.
	// This allows the "Sites Cloud Service" renderer code to setup all it's dependencies, including require.js, before adding the JET configuration. 
	var START_RENDERING_EVENT = 'scsrenderstart';
	if (document.addEventListener) {
		document.addEventListener(START_RENDERING_EVENT, runApp, false);
	} else if (document.attachEvent) {
		document.documentElement.scsrenderstart = 0;
		document.documentElement.attachEvent('onpropertychange', function (event) {
			if (event && (event.propertyName === START_RENDERING_EVENT)) {
				runApp();
			}
		});
	}
}());
