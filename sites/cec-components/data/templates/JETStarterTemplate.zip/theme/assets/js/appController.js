/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/*
 * Your application specific code will go here
 */
define(['require', 'ojs/ojcore', 'knockout', 'jquery', 'ojs/ojrouter', 'ojs/ojknockout', 'ojs/ojarraytabledatasource',
		'ojs/ojoffcanvas'
	],
	function (require, oj, ko, $) {
		function ControllerViewModel() {
			var self = this;

			// get the Sites Cloud Service variables for the site/page
			var renderAPI = window.SCSRenderAPI,
				siteStructure = window.SCS,
				siteName = renderAPI.getSiteProperty('siteName'),
				siteRootPrefix = renderAPI.getSiteProperty('siteRootPrefix');

			// Theme URLs
			self.themeURLprefix = renderAPI.getThemeUrlPrefix();
			self.cssURLprefix = self.themeURLprefix + '/assets/css';
			self.cssImagesURLprefix = self.cssURLprefix + '/images';

			// current Page
			self.currentPageId = siteStructure.navigationCurr;
			self.currentPage = {
				'attr': 'Page Not Found'
			};

			// create unique IDs for vertical/horizontal current selection
			self.vertSelect = 'vert::' + self.currentPageId;
			self.horzSelect = 'horz::' + self.currentPageId;

			// Site Cloud Service Site Name used in Branding Area
			self.appTitle = siteName;

			// Built-in messages
			self.copyright = 'Copyright &copy; 2014, ' + (new Date()).getFullYear() + ' Oracle and/or its affiliates All rights reserved.';

			//
			// Setup navigation and menus
			//

			// these are built-in navigation icon classes, which can be used in the off-canvas view
			var navIcons = [
					'oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24',
					'oj-navigationlist-item-icon demo-icon-font-24 demo-fire-icon-24',
					'oj-navigationlist-item-icon demo-icon-font-24 demo-people-icon-24',
					'oj-navigationlist-item-icon demo-icon-font-24 demo-info-icon-24'
				],
				pageIndex = 0;


			// global links, pages with these names will be displayed in the footer
			var globalLinkNames = [
				'About Us',
				'Contact Us',
				'Legal Notices',
				'Terms Of Use',
				'Privacy Policy'
			];
			self.globalLinks = [];

			// create a node to render the navigation item onto the page
			function createNodeData(navNode) {
				var linkData = renderAPI.getPageLinkData(navNode.id) || {};

				return {
					'id': navNode.id,
					'attr': {
						'name': navNode.name,
						'id': navNode.id,
						'isDefault': navNode.id === siteStructure.navigationRoot,
						'iconClass':  '', // navIcons[pageIndex % navIcons.length],
						'href': linkData.href,
						'target': linkData.target
					}
				};
			}

			// add all the nodes from the site structure
			function addNode(id, navNodes) {
				var nodeData = {};
				if (id >= 0) {
					var navNode = siteStructure.structureMap[id];

					// add in as global links if name matches
					if (globalLinkNames.indexOf(navNode.name) !== -1) {
						var globalMenuItem = createNodeData(navNode);
						self.globalLinks.push(createNodeData(navNode));
						if (id === self.currentPageId) {
							self.currentPage = globalMenuItem;
						}
					}

					// only add in the node if it's not marked as "hide in navigation"
					if (navNode && ((typeof navNode.hideInNavigation !== 'boolean') || (navNode.hideInNavigation === false))) {
						pageIndex++;

						// create the node from the navigation data
						nodeData = createNodeData(navNode);

						// assign to the currentPage if id matches
						if (id === self.currentPageId) {
							self.currentPage = nodeData;
						}

						// add in any child nodes
						if (navNode.children.length > 0) {
							nodeData.children = [];
							for (var c = 0; c < navNode.children.length; c++) {
								var childNode = addNode(navNode.children[c]);
								if (childNode.id) {
									nodeData.children.push(childNode);
									nodeData.attr.hasChildren = true;
								}
							}
						}
					}
				}
				return nodeData;
			}

			// display all the top-level nodes
			var allNodes = addNode(siteStructure.navigationRoot);
			self.navData = allNodes.children || [];

			// store the top-level node for the logo/title support
			self.appURL = allNodes.attr.href;

			// for this use-case, add in the copied rootNode as a topLevelNode
			// copy the root node but remove the children
			var rootNode = $.extend({}, allNodes);
			rootNode.children = undefined;
			self.navData.unshift(rootNode);

			// 
			// setup the navigation list data source
			//
			self.navDataSource = new oj.ArrayTableDataSource(self.navData, {
				idAttribute: 'id'
			});

			//
			// Setup the Footer menu for all top-level menu items w/children
			//
			self.topLvlNodesWithChildren = self.navData.filter(function (node) {
				return node.children && node.children.length > 0;
			});

			// choose style for child nodes
			var footerFlexClasses = [
				'oj-lg-12 oj-md-12 oj-sm-12 oj-flex-item',
				'oj-lg-6 oj-md-6 oj-sm-6 oj-flex-item',
				'oj-lg-4 oj-md-4 oj-sm-6 oj-flex-item',
				'oj-lg-3 oj-md-3 oj-sm-6 oj-flex-item'
			];
			if (self.topLvlNodesWithChildren) {
				var classNode = self.topLvlNodesWithChildren.length > footerFlexClasses.length ? footerFlexClasses.length : self.topLvlNodesWithChildren.length;
				self.footerFlexClass = footerFlexClasses[classNode - 1];
			}


			//
			// Setup Media Queries for repsonsive header and navigation
			//
			var smQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
			self.smScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
			var mdQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP);
			self.mdScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(mdQuery);
			self.mdScreen.subscribe(function () {
				oj.OffcanvasUtils.close(self.appDrawer);
			});

			//
			// Setup off-canvas AppDrawer
			//
			self.drawerParams = {
				displayMode: 'push',
				selector: '#navDrawer',
				content: '#pageContent'
			};
			// Called by navigation drawer toggle button and after selection of nav drawer item
			self.toggleDrawer = function () {
				return oj.OffcanvasUtils.toggle(self.drawerParams);
			};
			// Add a close listener so we can move focus back to the toggle button when the drawer closes
			$("#navDrawer").on("ojclose", function () {
				$('#drawerToggleButton').focus();
			});

			self.appDrawer = {
				"edge": "start",
				"displayMode": "push",
				"selector": "#demoAppDrawer",
				"content": '#globalBody',
				"selection": "selectedItem"
			};
			self.toggleAppDrawer = function () {
				return oj.OffcanvasUtils.toggle(self.appDrawer);
			};

			// Button used for toggling off screen data.
			var offScreenDataButton = {
				"label": "offscreen-toggle",
				"iconClass": "oj-web-applayout-offcanvas-icon",
				"url": "#"
			};
			self.offScreenButtonIconClass = offScreenDataButton.iconClass;
			self.offScreenButtonLabel = offScreenDataButton.label;
		}

		return new ControllerViewModel();
	}
);
