/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
/* globals define, requirejs */
define(['knockout', 'jquery', 'text!./render.html'], function (ko, $, template) {
	'use strict';

	// create a custom Knockout binding handler to convert CCA events into SCS Triggers
	ko.bindingHandlers.registerCCADemoCardEvents = {
		init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
			var eventName = 'selectCard'; // name of the CCA Event
			viewModel.ccaDemoCardEventListener = element.addEventListener(eventName, function (e) {
				// raise the SCS trigger 
				viewModel.raiseTrigger(eventName, e.detail || {});
			}, true);
		}
	};

	// ----------------------------------------------
	// Define a Knockout ViewModel for your template
	// ----------------------------------------------
	var SampleComponentViewModel = function (args) {
		var self = this,
			SitesSDK = args.SitesSDK,
			prop;

		// store the values passed in
		self.id = args.id;
		self.componentCatalogName = args.componentCatalogName;
		self.mode = args.viewMode || 'view';
		self.divId = 'composite-component' + args.id;
		self.cardId = 'composite-component' + args.id + 'card';

		// don't render anything until ready
		self.initialized = ko.observable(false);

		// assume we can load CCA
		self.canLoadCCA = ko.observable(true);
		self.showCCAErrorMessage = ko.computed(function () {
			// only show error message in edit mode
			return (!self.canLoadCCA() && self.mode === 'edit');
		});

		// create the observables for the parameters
		self.employee = {
			'name': ko.observable(''),
			'avatar': ko.observable(''),
			'title': ko.observable(''),
			'work': ko.observable(9999999999),
			'email': ko.observable(''),
			'backgroundImage': ko.observable('')
		};
		self.employee.computedWork = ko.pureComputed(function () {
			var returnNumber;
			try {
				returnNumber = parseInt(ko.unwrap(self.employee.work()));
			} catch (e) {
			}

			return (isNaN(returnNumber) || !returnNumber) ? self.employeeConfig.work.defaultValue : returnNumber; 
		});


		// Handle property changes from the Settings panel
		self.updateCustomSettingsData = function (customData) {
			var imagesURLPrefix = self.assetsURL + '/composites/demo-card/images/';
			customData = customData || {};

			// handle any settings changes
			self.employee.name(customData.name);
			self.employee.avatar(customData.avatar ? imagesURLPrefix + customData.avatar : '');
			self.employee.title(customData.title);
			self.employee.work(customData.work);
			self.employee.email(customData.email);
			self.employee.backgroundImage(customData.backgroundImage ? imagesURLPrefix + customData.backgroundImage : '');
		};

		// Register your updateSettings listener to recieve SETTINGS_UPDATED events
		self.updateSettings = function (settings) {
			if (settings.property === 'customSettingsData') {
				self.updateCustomSettingsData(settings.value);
			}
		};
		SitesSDK.subscribe(SitesSDK.MESSAGE_TYPES.SETTINGS_UPDATED, self.updateSettings);

		// raise requested trigger to execute associated actions
		self.raiseTrigger = function (triggerName, triggerPayload) {
			SitesSDK.publish('TRIGGER_ACTIONS', {
				'triggerName': triggerName,
				'triggerPayload': triggerPayload
			});
		};


		// Convert SCS Actions into CCA methods
		self.executeMyAction = function (args) {
			if (args.action && args.action.actionName === 'flipCards') {
				var card = $('#' + self.cardId)[0];
				card.flipCard({}, {
					"type": "click"
				});
			}
		};
		SitesSDK.subscribe('EXECUTE_ACTION', self.executeMyAction);


		// initialize the component
		SitesSDK.getProperties(['assetsURL', 'customSettingsData'], function (properties) {
			// require in the CCA component to register the CCA HTML element
			// If the page isn't configured to run JET, this will fail
			var loaderRequirePath = 'scs-components-path/' + self.componentCatalogName + '/assets/composites/demo-card/loader';
			require([loaderRequirePath], function () {
					// store the assetsURL for accessing resources
					self.assetsURL = properties.assetsURL;

					// initialize the component with the custom settings data
					self.updateCustomSettingsData(properties.customSettingsData);

					// note that we can now render the component
					self.canLoadCCA(true);
					self.initialized(true);
				},
				function () {
					// undef function is only on the global requirejs object
					// undef the compositeLoader so it will be loaded again
					requirejs.undef(loaderRequirePath);

					// note that we couldn't load it
					self.canLoadCCA(false);
				});
		});
	};


	// ----------------------------------------------
	// Create a knockout based component implemention
	// ----------------------------------------------
	var SampleComponentImpl = function (args) {
		// Initialze the custom component
		this.init(args);
	};
	// initialize all the values within the component from the given argument values
	SampleComponentImpl.prototype.init = function (args) {
		this.createViewModel(args);
		this.createTemplate(args);
		this.setupCallbacks();
	};
	// create the viewModel from the initial values
	SampleComponentImpl.prototype.createViewModel = function (args) {
		// create the viewModel
		this.viewModel = new SampleComponentViewModel(args);
	};
	// create the template based on the initial values
	SampleComponentImpl.prototype.createTemplate = function (args) {
		// create a unique ID for the div to add, this will be passed to the callback
		this.contentId = args.id + '_content_' + args.viewMode;
		// create a hidden custom component template that can be added to the DOM
		this.template = '<div id="' + this.contentId + '">' +
			template +
			'</div>';
	};
	//
	// SDK Callbacks
	// setup the callbacks expected by the SDK API
	//
	SampleComponentImpl.prototype.setupCallbacks = function () {
		//
		// callback - render: add the component into the page
		//
		this.render = $.proxy(function (container) {
			var $container = $(container);
			// add the custom component template to the DOM
			$container.append(this.template);
			// apply the bindings
			ko.applyBindings(this.viewModel, $('#' + this.contentId)[0]);
		}, this);
		//
		// callback - dispose: cleanup after component when it is removed from the page
		//
		this.dispose = $.proxy(function () {
			// nothing required for this sample since knockout disposal will automatically clean up the node
		}, this);
	};
	// ----------------------------------------------
	// Create the factory object for your component
	// ----------------------------------------------
	var sampleComponentFactory = {
		createComponent: function (args, callback) {
			// return a new instance of the component
			return callback(new SampleComponentImpl(args));
		}
	};
	return sampleComponentFactory;
});
