/**
 * Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
 * Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
 */
// require in all JET dependencies
/* globals define */
define(['knockout', 'jquery', 'ojs/ojcore', 'ojs/ojdatetimepicker'], function (ko, $, oj) {
	'use strict';

	var JetCode = function () {};

	JetCode.prototype.init = function (viewModel) {
		// extend viewModel with any JET specific functionality

	};

	// add in any JET code
	return new JetCode();
});
